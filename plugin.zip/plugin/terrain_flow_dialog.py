import os
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QGroupBox,
    QProgressBar, QSpinBox, QDoubleSpinBox,
    QComboBox, QTextEdit, QListWidget, QListWidgetItem,
    QScrollArea, QSizePolicy, QCheckBox, QLineEdit, QSlider, QFrame
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel

from .processing.scs_runoff import SCSRunoff


class TerrainFlowPanel(QDockWidget):
    """Docked panel for TerrainFlow plugin."""

    def __init__(self, parent=None):
        super().__init__("TerrainFlow", parent)
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self._dem_path = None
        self._cell_size_m2 = None
        self._build_ui()
        self._update_channel_type_label()

    def _build_ui(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(8)

        # --------------------------------------------------------------- Session
        session_group = QGroupBox("Session")
        session_layout = QHBoxLayout(session_group)
        session_layout.setContentsMargins(4, 4, 4, 4)
        self.edit_session_name = QLineEdit("Untitled Session")
        self.edit_session_name.setPlaceholderText("Session name…")
        self.edit_session_name.setToolTip(
            "Name for this design session.\n"
            "Saved with the session file so you can identify it later."
        )
        self.btn_save_session = QPushButton("Save")
        self.btn_save_session.setToolTip(
            "Save the current session (DEM path, earthworks, CN zones, and settings)\n"
            "to a .tflow file that can be reloaded later."
        )
        self.btn_load_session = QPushButton("Load")
        self.btn_load_session.setToolTip(
            "Load a previously saved .tflow session file.\n"
            "Restores earthworks, CN zones, and analysis settings.\n"
            "Re-run baseline analysis after loading to regenerate flow results."
        )
        session_layout.addWidget(self.edit_session_name, stretch=1)
        session_layout.addWidget(self.btn_save_session)
        session_layout.addWidget(self.btn_load_session)
        layout.addWidget(session_group)

        # ---------------------------------------------------------------- Data
        data_group = QGroupBox("Data")
        data_layout = QVBoxLayout(data_group)

        data_layout.addWidget(QLabel("DEM layer (auto-applied on selection):"))
        self.combo_dem_layer = QgsMapLayerComboBox()
        self.combo_dem_layer.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.combo_dem_layer.setAllowEmptyLayer(True)
        self.combo_dem_layer.setCurrentIndex(0)
        data_layout.addWidget(self.combo_dem_layer)

        data_layout.addWidget(QLabel("Or load from file:"))
        self.btn_load_dem = QPushButton("Browse...")
        data_layout.addWidget(self.btn_load_dem)

        self.lbl_dem_status = QLabel("No DEM selected")
        self.lbl_dem_status.setWordWrap(True)
        data_layout.addWidget(self.lbl_dem_status)

        data_layout.addWidget(QLabel("Site boundary (polygon layer):"))
        self.combo_boundary_layer = QgsMapLayerComboBox()
        self.combo_boundary_layer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.combo_boundary_layer.setAllowEmptyLayer(True)
        self.combo_boundary_layer.setCurrentIndex(0)
        self.combo_boundary_layer.setToolTip(
            "Select a polygon layer for your site boundary.\n\n"
            "Contributing catchment (upstream area flowing onto the site) will be detected.\n\n"
            "When set, baseline analysis and keyline analysis are also\n"
            "masked to this boundary — cells outside (e.g. surrounding\n"
            "water on an island DEM) are ignored."
        )
        data_layout.addWidget(self.combo_boundary_layer)

        self.btn_preview_catchment = QPushButton("Preview Contributing Catchment")
        self.btn_preview_catchment.setToolTip(
            "Quickly identify which part of the DEM actually drains to your site.\n\n"
            "Traces uphill from the site boundary using slope alone: any area\n"
            "connected to the boundary by a continuous downhill path is included.\n"
            "Equivalent to drawing perpendiculars to the contours — no D8 routing\n"
            "or depression-filling required.\n\n"
            "Use this before running a full analysis on a large DEM to find out\n"
            "how much of the DEM is relevant, then clip to that area."
        )
        self.btn_preview_catchment.setEnabled(False)
        data_layout.addWidget(self.btn_preview_catchment)

        self.lbl_catchment_preview = QLabel("")
        self.lbl_catchment_preview.setWordWrap(True)
        self.lbl_catchment_preview.setVisible(False)
        data_layout.addWidget(self.lbl_catchment_preview)

        lbl_catchment_desc = QLabel(
            "The contributing catchment is the total upstream area that drains "
            "onto your site — all land connected to the site boundary by a "
            "continuous downhill path. Use it to understand how much external "
            "runoff reaches the site and to clip the DEM before a full analysis."
        )
        lbl_catchment_desc.setWordWrap(True)
        lbl_catchment_desc.setStyleSheet("color: grey; font-size: 10px;")
        data_layout.addWidget(lbl_catchment_desc)

        self.btn_clip_dem = QPushButton("Clip DEM to Catchment (+20% buffer)")
        self.btn_clip_dem.setToolTip(
            "Clips the full-resolution DEM to the contributing catchment extent\n"
            "plus a 20% margin, then sets the clipped file as the active DEM.\n\n"
            "This can dramatically reduce memory use and processing time."
        )
        self.btn_clip_dem.setEnabled(False)
        self.btn_clip_dem.setVisible(False)
        data_layout.addWidget(self.btn_clip_dem)

        data_layout.addWidget(QLabel("Analysis area (post-analysis tools):"))
        self.combo_analysis_boundary = QgsMapLayerComboBox()
        self.combo_analysis_boundary.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.combo_analysis_boundary.setAllowEmptyLayer(True)
        self.combo_analysis_boundary.setCurrentIndex(0)
        self.combo_analysis_boundary.setToolTip(
            "Restrict Optimal Swale Contours, Contour Flow Analysis and\n"
            "Keyline Analysis to this polygon.\n\n"
            "Leave blank to use the full DEM (or the site boundary if set).\n\n"
            "Tip: auto-filled when 'Show contributing catchments' is enabled —\n"
            "set this as your site boundary and re-run for a faster analysis."
        )
        data_layout.addWidget(self.combo_analysis_boundary)

        data_layout.addWidget(QLabel("Earthworks area (polygon layer):"))
        self.combo_earthworks_area = QgsMapLayerComboBox()
        self.combo_earthworks_area.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.combo_earthworks_area.setAllowEmptyLayer(True)
        self.combo_earthworks_area.setCurrentIndex(0)
        self.combo_earthworks_area.setToolTip(
            "Optional polygon defining where earthworks can be placed.\n\n"
            "When set, drawing tools will be constrained to this area and\n"
            "Optimal Swale Contours will only be generated within it.\n\n"
            "Useful for separating the project area from sensitive zones\n"
            "(wetlands, roads, existing structures) that must not be disturbed."
        )
        data_layout.addWidget(self.combo_earthworks_area)

        layout.addWidget(data_group)

        # ------------------------------------------------------------ Rainfall
        rainfall_group = QGroupBox("Rainfall")
        rainfall_layout = QVBoxLayout(rainfall_group)

        preset_layout = QHBoxLayout()
        preset_layout.addWidget(QLabel("Storm preset:"))
        self.combo_preset = QComboBox()
        for label in SCSRunoff.STORM_PRESETS:
            self.combo_preset.addItem(label)
        self.combo_preset.currentIndexChanged.connect(self._on_preset_changed)
        preset_layout.addWidget(self.combo_preset)
        rainfall_layout.addLayout(preset_layout)

        intensity_layout = QHBoxLayout()
        intensity_layout.addWidget(QLabel("Intensity (mm/hr):"))
        self.spin_intensity = QDoubleSpinBox()
        self.spin_intensity.setRange(1, 500)
        self.spin_intensity.setValue(40)
        self.spin_intensity.setDecimals(1)
        intensity_layout.addWidget(self.spin_intensity)
        rainfall_layout.addLayout(intensity_layout)

        duration_layout = QHBoxLayout()
        duration_layout.addWidget(QLabel("Duration (hours):"))
        self.spin_duration = QDoubleSpinBox()
        self.spin_duration.setRange(0.1, 72)
        self.spin_duration.setValue(1.0)
        self.spin_duration.setDecimals(1)
        duration_layout.addWidget(self.spin_duration)
        rainfall_layout.addLayout(duration_layout)
        layout.addWidget(rainfall_group)

        # ---------------------------------------------------------- Analysis
        analysis_group = QGroupBox("Baseline Analysis")
        analysis_layout = QVBoxLayout(analysis_group)

        # Water flow threshold (ha-based)
        thresh_row = QHBoxLayout()
        thresh_row.addWidget(QLabel("Water flow threshold:"))
        self.spin_threshold_ha = QDoubleSpinBox()
        self.spin_threshold_ha.setRange(0.1, 500.0)
        self.spin_threshold_ha.setValue(1.0)
        self.spin_threshold_ha.setDecimals(1)
        self.spin_threshold_ha.setSingleStep(0.5)
        self.spin_threshold_ha.setSuffix(" ha")
        self.spin_threshold_ha.setToolTip(
            "Minimum upstream catchment area for a flow path to be shown as a channel.\n\n"
            "Lower = more channels shown.  Higher = major watercourses only.\n\n"
            "Channel types by contributing area:\n"
            "  Rills / erosion paths:   < 0.5 ha\n"
            "  Ephemeral / seasonal:    0.5 – 5 ha\n"
            "  Permanent stream:        5 – 20 ha\n"
            "  River:                   > 20 ha"
        )
        self.spin_threshold_ha.valueChanged.connect(self._update_channel_type_label)
        thresh_row.addWidget(self.spin_threshold_ha)
        analysis_layout.addLayout(thresh_row)

        self.lbl_channel_type = QLabel("")
        self.lbl_channel_type.setStyleSheet("color: #555555; font-style: italic;")
        self.lbl_channel_type.setWordWrap(True)
        analysis_layout.addWidget(self.lbl_channel_type)

        # Advanced settings toggle
        self._btn_advanced = QPushButton("▶  Advanced Settings")
        self._btn_advanced.setCheckable(True)
        self._btn_advanced.setChecked(False)
        self._btn_advanced.setFlat(True)
        self._btn_advanced.setStyleSheet("text-align: left; font-weight: bold;")
        self._btn_advanced.clicked.connect(self._toggle_advanced_settings)
        analysis_layout.addWidget(self._btn_advanced)

        # Advanced settings widget (hidden by default)
        self._widget_advanced = QWidget()
        adv_layout = QVBoxLayout(self._widget_advanced)
        adv_layout.setContentsMargins(8, 0, 0, 0)
        adv_layout.setSpacing(4)

        # CN
        cn_layout = QHBoxLayout()
        cn_layout.addWidget(QLabel("Curve Number (CN):"))
        self.spin_cn = QSpinBox()
        self.spin_cn.setRange(1, 100)
        self.spin_cn.setValue(70)
        self.spin_cn.setToolTip(
            "SCS Curve Number — soil runoff potential.\n"
            "Higher = more runoff.\n\n"
            "Typical values (Normal moisture):\n"
            "  Sand: 39  |  Sandy loam: 49\n"
            "  Loam: 61  |  Clay loam: 74  |  Clay: 80"
        )
        cn_layout.addWidget(self.spin_cn)
        adv_layout.addLayout(cn_layout)

        # Moisture condition
        moisture_layout = QHBoxLayout()
        moisture_layout.addWidget(QLabel("Moisture condition:"))
        self.combo_moisture = QComboBox()
        self.combo_moisture.addItems(["Dry", "Normal", "Wet / Saturated"])
        self.combo_moisture.setCurrentIndex(1)
        moisture_layout.addWidget(self.combo_moisture)
        adv_layout.addLayout(moisture_layout)

        # Stream mode
        mode_layout = QHBoxLayout()
        mode_layout.addWidget(QLabel("Stream mode:"))
        self.combo_threshold_mode = QComboBox()
        self.combo_threshold_mode.addItems([
            "Contributing area (ha)",
            "Runoff volume (m³)",
        ])
        self.combo_threshold_mode.setToolTip(
            "Contributing area (ha): streams defined by upstream catchment area.\n"
            "Independent of rainfall — shows the terrain's natural drainage network.\n\n"
            "Runoff volume (m³): streams defined by volume of runoff passing through.\n"
            "Rainfall- and CN-dependent — changes with storm size and soil conditions.\n"
            "Use this to see which channels only activate in larger storms."
        )
        self.combo_threshold_mode.currentIndexChanged.connect(self._on_threshold_mode_changed)
        mode_layout.addWidget(self.combo_threshold_mode)
        adv_layout.addLayout(mode_layout)

        # Volume threshold (shown when mode = runoff volume)
        self._widget_volume_threshold = QWidget()
        vol_layout = QHBoxLayout(self._widget_volume_threshold)
        vol_layout.setContentsMargins(0, 0, 0, 0)
        vol_layout.addWidget(QLabel("Threshold (m³):"))
        self.spin_volume_threshold = QDoubleSpinBox()
        self.spin_volume_threshold.setRange(0.1, 1_000_000)
        self.spin_volume_threshold.setValue(50.0)
        self.spin_volume_threshold.setDecimals(1)
        self.spin_volume_threshold.setSingleStep(10)
        self.spin_volume_threshold.setToolTip(
            "Minimum runoff volume (m³) passing through a cell for it to be\n"
            "classified as a stream. Calculated from flow accumulation × storm runoff.\n\n"
            "Lower = more channels shown in this storm.\n"
            "Higher = only the highest-flow channels shown.\n\n"
            "Unlike contributing area mode, this changes when rainfall or CN changes."
        )
        vol_layout.addWidget(self.spin_volume_threshold)
        self._widget_volume_threshold.setVisible(False)
        adv_layout.addWidget(self._widget_volume_threshold)

        # Catchments option
        self.chk_catchments = QCheckBox("Delineate catchment polygons")
        self.chk_catchments.setChecked(False)
        self.chk_catchments.setToolTip(
            "Delineate and display catchment area polygons with flow direction arrows.\n"
            "Adds processing time — disable for quick scenario comparisons."
        )
        adv_layout.addWidget(self.chk_catchments)

        self.chk_contributing_catchments = QCheckBox("Show contributing catchments (site entry)")
        self.chk_contributing_catchments.setChecked(False)
        self.chk_contributing_catchments.setToolTip(
            "After baseline analysis, merge all catchment polygons that drain into\n"
            "the site boundary and display them as a single 'Contributing Catchments' layer.\n\n"
            "Requires a site boundary to be selected.\n\n"
            "The analysis area boundary is automatically set to this layer — post-analysis\n"
            "tools (Optimal Swale Contours, Keyline Analysis etc.) will be restricted to\n"
            "the contributing area. You can also set this layer as the site boundary and\n"
            "re-run the full analysis to limit processing to just the contributing catchment."
        )
        adv_layout.addWidget(self.chk_contributing_catchments)

        # Flow routing mode
        routing_layout = QHBoxLayout()
        routing_layout.addWidget(QLabel("Flow routing:"))
        self.combo_routing = QComboBox()
        self.combo_routing.addItems([
            "D-infinity (recommended)",
            "D8 (classic)",
        ])
        self.combo_routing.setToolTip(
            "D-infinity (Tarboton 1997): distributes flow fractionally between the\n"
            "two steepest downslope cells. Produces smoother accumulation patterns\n"
            "on gentle terrain — the best upgrade to flow modelling accuracy.\n\n"
            "D8: routes all flow to a single downslope cell. Faster and more widely\n"
            "supported, but creates visible diagonal striping artefacts on flat slopes."
        )
        routing_layout.addWidget(self.combo_routing)
        adv_layout.addLayout(routing_layout)

        # ---- CN Zone mapping (collapsible sub-section) ----
        self._btn_cn_zones = QPushButton("▶  CN Zone Mapping")
        self._btn_cn_zones.setCheckable(True)
        self._btn_cn_zones.setChecked(False)
        self._btn_cn_zones.setFlat(True)
        self._btn_cn_zones.setStyleSheet("text-align: left; font-weight: bold;")
        self._btn_cn_zones.clicked.connect(self._toggle_cn_zones)
        adv_layout.addWidget(self._btn_cn_zones)

        self._widget_cn_zones = QWidget()
        cn_zone_inner = QVBoxLayout(self._widget_cn_zones)
        cn_zone_inner.setContentsMargins(8, 0, 0, 0)
        cn_zone_inner.setSpacing(4)

        cn_zone_inner.addWidget(QLabel(
            "Draw polygons and assign CN values to soil/land-use zones.\n"
            "Cells outside all zones use the default CN above."
        ))

        self.btn_draw_cn_zone = QPushButton("Draw CN Zone")
        self.btn_draw_cn_zone.setEnabled(False)
        self.btn_draw_cn_zone.setToolTip(
            "Draw a polygon on the map and assign a Curve Number to that zone.\n\n"
            "Use this to represent different soils or land-use types within the\n"
            "catchment — e.g. high CN for impervious areas, low CN for forested zones.\n\n"
            "Left-click to add vertices, right-click or double-click to finish.\n"
            "Requires a DEM to be loaded."
        )
        cn_zone_inner.addWidget(self.btn_draw_cn_zone)

        self.list_cn_zones = QListWidget()
        self.list_cn_zones.setMaximumHeight(90)
        self.list_cn_zones.setToolTip("Drawn CN zones. Select a zone and click Delete to remove it.")
        cn_zone_inner.addWidget(self.list_cn_zones)

        self.btn_delete_cn_zone = QPushButton("Delete Selected Zone")
        self.btn_delete_cn_zone.setEnabled(False)
        cn_zone_inner.addWidget(self.btn_delete_cn_zone)

        self.lbl_cn_zones_hint = QLabel("")
        self.lbl_cn_zones_hint.setWordWrap(True)
        self.lbl_cn_zones_hint.setStyleSheet("color: #555; font-style: italic; font-size: 10px;")
        cn_zone_inner.addWidget(self.lbl_cn_zones_hint)

        self._widget_cn_zones.setVisible(False)
        adv_layout.addWidget(self._widget_cn_zones)

        # ---- Resource consent thresholds (collapsible sub-section) ----
        self._btn_consent = QPushButton("▶  Resource Consent Thresholds")
        self._btn_consent.setCheckable(True)
        self._btn_consent.setChecked(False)
        self._btn_consent.setFlat(True)
        self._btn_consent.setStyleSheet("text-align: left; font-weight: bold;")
        self._btn_consent.clicked.connect(self._toggle_consent)
        adv_layout.addWidget(self._btn_consent)

        self._widget_consent = QWidget()
        consent_inner = QVBoxLayout(self._widget_consent)
        consent_inner.setContentsMargins(8, 0, 0, 0)
        consent_inner.setSpacing(4)

        self.chk_consent_enabled = QCheckBox("Flag earthworks exceeding these thresholds")
        self.chk_consent_enabled.setChecked(False)
        self.chk_consent_enabled.setToolTip(
            "When checked, a warning will appear after drawing or editing an\n"
            "earthwork if its volume (or the total cut volume) exceeds the\n"
            "thresholds set below.\n\n"
            "Set the thresholds to match your local resource consent requirements.\n"
            "These are not enforced by the plugin — they are reminders only."
        )
        consent_inner.addWidget(self.chk_consent_enabled)

        single_row = QHBoxLayout()
        single_row.addWidget(QLabel("Max single earthwork:"))
        self.spin_consent_single_m3 = QDoubleSpinBox()
        self.spin_consent_single_m3.setRange(1, 1_000_000)
        self.spin_consent_single_m3.setValue(5000)
        self.spin_consent_single_m3.setDecimals(0)
        self.spin_consent_single_m3.setSuffix(" m³")
        self.spin_consent_single_m3.setSingleStep(500)
        self.spin_consent_single_m3.setToolTip(
            "Volume threshold for a single earthwork feature.\n"
            "Earthworks larger than this will be flagged with a consent warning."
        )
        single_row.addWidget(self.spin_consent_single_m3)
        consent_inner.addLayout(single_row)

        total_row = QHBoxLayout()
        total_row.addWidget(QLabel("Max total cut volume:"))
        self.spin_consent_total_m3 = QDoubleSpinBox()
        self.spin_consent_total_m3.setRange(1, 10_000_000)
        self.spin_consent_total_m3.setValue(50_000)
        self.spin_consent_total_m3.setDecimals(0)
        self.spin_consent_total_m3.setSuffix(" m³")
        self.spin_consent_total_m3.setSingleStep(1000)
        self.spin_consent_total_m3.setToolTip(
            "Total cut (excavation) volume threshold across all earthworks.\n"
            "A warning will appear when the combined cut volume exceeds this."
        )
        total_row.addWidget(self.spin_consent_total_m3)
        consent_inner.addLayout(total_row)

        self._widget_consent.setVisible(False)
        adv_layout.addWidget(self._widget_consent)

        self._widget_advanced.setVisible(False)
        analysis_layout.addWidget(self._widget_advanced)

        self.btn_run = QPushButton("Run Baseline Analysis")
        self.btn_run.setEnabled(False)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.lbl_status = QLabel("Load a DEM to begin.")
        self.lbl_status.setWordWrap(True)
        analysis_layout.addWidget(self.btn_run)
        analysis_layout.addWidget(self.progress_bar)
        analysis_layout.addWidget(self.lbl_status)
        layout.addWidget(analysis_group)

        # --------------------------------------------------------- Earthworks
        ew_group = QGroupBox("Earthworks")
        ew_layout = QVBoxLayout(ew_group)
        ew_layout.setSpacing(6)

        # --- Primary draw row: swale is the most common action ---
        primary_draw_row = QHBoxLayout()
        self.btn_draw_swale = QPushButton("✏  Draw Swale")
        self.btn_draw_swale.setToolTip(
            "Freehand swale — left-click to add vertices, right-click to finish.\n"
            "Use 'Contour Swale' below to snap directly to a contour line."
        )
        primary_draw_row.addWidget(self.btn_draw_swale)
        ew_layout.addLayout(primary_draw_row)

        # --- Contour workflow (core demo path) ---
        ew_layout.addWidget(QLabel("Contour layer:"))
        contour_layer_row = QHBoxLayout()
        self.combo_contour_layer = QgsMapLayerComboBox()
        self.combo_contour_layer.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.combo_contour_layer.setAllowEmptyLayer(True)
        self.combo_contour_layer.setCurrentIndex(0)
        self.combo_contour_layer.setToolTip(
            "Select which line layer to pick contours from.\n"
            "Auto-set when you run 'Generate Contours' or 'Optimal Swale Contours'."
        )
        contour_layer_row.addWidget(self.combo_contour_layer, 1)
        self.btn_contours = QPushButton("Generate")
        self.btn_contours.setToolTip("Generate a contour layer from the DEM")
        self.btn_contours.setEnabled(False)
        contour_layer_row.addWidget(self.btn_contours)
        ew_layout.addLayout(contour_layer_row)

        contour_action_row = QHBoxLayout()
        self.btn_contour_swale = QPushButton("🖱  Contour Swale")
        self.btn_contour_swale.setEnabled(False)
        self.btn_contour_swale.setToolTip(
            "Click a contour line on the map to create a swale that follows it exactly.\n"
            "The lip elevation will be constant along the entire swale.\n\n"
            "Select a contour layer above, or generate one using 'Generate'.\n"
            "Run 'Optimal' to find the highest-inflow contours automatically."
        )
        self.btn_optimal_swale_contours = QPushButton("Optimal")
        self.btn_optimal_swale_contours.setEnabled(False)
        self.btn_optimal_swale_contours.setToolTip(
            "Find the N contour elevations that intercept the most flow,\n"
            "and generate contour lines at those elevations.\n\n"
            "Requires: baseline analysis run."
        )
        contour_action_row.addWidget(self.btn_contour_swale)
        contour_action_row.addWidget(self.btn_optimal_swale_contours)
        ew_layout.addLayout(contour_action_row)

        # --- Earthworks list ---
        ew_layout.addWidget(QLabel("Drawn earthworks (✓ to enable, double-click to edit):"))
        self.list_earthworks = QListWidget()
        self.list_earthworks.setMaximumHeight(130)
        self.list_earthworks.setToolTip(
            "Check/uncheck to enable or disable features.\n"
            "Double-click to edit properties."
        )
        ew_layout.addWidget(self.list_earthworks)

        list_actions = QHBoxLayout()
        self.btn_edit_earthwork = QPushButton("Edit Properties")
        self.btn_edit_earthwork.setEnabled(False)
        self.btn_delete_earthwork = QPushButton("Delete")
        self.btn_delete_earthwork.setEnabled(False)
        list_actions.addWidget(self.btn_edit_earthwork)
        list_actions.addWidget(self.btn_delete_earthwork)
        ew_layout.addLayout(list_actions)

        # --- Re-analyse (primary CTA) ---
        self.btn_reanalyse = QPushButton("⚙  Re-analyse with Earthworks")
        self.btn_reanalyse.setEnabled(False)
        self.btn_reanalyse.setToolTip("Burn earthworks into DEM and re-run flow analysis")
        self.btn_reanalyse.setStyleSheet("font-weight: bold;")
        ew_layout.addWidget(self.btn_reanalyse)

        # --- Before/After toggle ---
        self.btn_toggle_before_after = QPushButton("Show: Baseline")
        self.btn_toggle_before_after.setCheckable(True)
        self.btn_toggle_before_after.setEnabled(False)
        self.btn_toggle_before_after.setToolTip("Toggle between baseline and post-earthwork results")
        ew_layout.addWidget(self.btn_toggle_before_after)

        # --- More Tools (collapsible) ---
        self._btn_more_ew_tools = QPushButton("▶  More Earthwork Tools")
        self._btn_more_ew_tools.setCheckable(True)
        self._btn_more_ew_tools.setChecked(False)
        self._btn_more_ew_tools.setFlat(True)
        self._btn_more_ew_tools.setStyleSheet("text-align: left; color: #555;")
        self._btn_more_ew_tools.clicked.connect(self._toggle_more_ew_tools)
        ew_layout.addWidget(self._btn_more_ew_tools)

        self._widget_more_ew_tools = QWidget()
        more_layout = QVBoxLayout(self._widget_more_ew_tools)
        more_layout.setContentsMargins(8, 0, 0, 0)
        more_layout.setSpacing(4)

        # Draw berm / basin row
        more_draw_row1 = QHBoxLayout()
        self.btn_draw_berm = QPushButton("Draw Berm")
        self.btn_draw_berm.setToolTip(
            "Draw a berm / levee ridge that raises terrain, blocking downhill flow."
        )
        self.btn_draw_basin = QPushButton("Draw Basin")
        self.btn_draw_basin.setToolTip("Draw a detention basin polygon.")
        more_draw_row1.addWidget(self.btn_draw_berm)
        more_draw_row1.addWidget(self.btn_draw_basin)
        more_layout.addLayout(more_draw_row1)

        # Draw dam / diversion row
        more_draw_row2 = QHBoxLayout()
        self.btn_draw_dam = QPushButton("Draw Dam")
        self.btn_draw_dam.setToolTip(
            "Draw a dam wall across a valley. Draw a line across the valley;\n"
            "the wall is raised to the higher endpoint elevation."
        )
        self.btn_draw_diversion = QPushButton("Draw Diversion")
        self.btn_draw_diversion.setToolTip(
            "Draw a graded diversion drain — conveys water across a slope at\n"
            "a controlled gradient rather than retaining it."
        )
        more_draw_row2.addWidget(self.btn_draw_dam)
        more_draw_row2.addWidget(self.btn_draw_diversion)
        more_layout.addLayout(more_draw_row2)

        # Spillway
        self.btn_place_spillway = QPushButton("Place Spillway Point")
        self.btn_place_spillway.setEnabled(False)
        self.btn_place_spillway.setToolTip(
            "Click on the map to place a spillway point on the selected earthwork."
        )
        more_layout.addWidget(self.btn_place_spillway)

        # Exclusion zone — load from layer
        excl_load_row = QHBoxLayout()
        excl_load_row.addWidget(QLabel("Excl. layer:"))
        self.combo_exclusion_layer = QgsMapLayerComboBox()
        self.combo_exclusion_layer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.combo_exclusion_layer.setAllowEmptyLayer(True)
        self.combo_exclusion_layer.setCurrentIndex(0)
        excl_load_row.addWidget(self.combo_exclusion_layer, stretch=1)
        self.btn_load_exclusion_layer = QPushButton("Load")
        self.btn_load_exclusion_layer.setToolTip(
            "Add all features from the selected polygon layer as exclusion zones."
        )
        excl_load_row.addWidget(self.btn_load_exclusion_layer)
        more_layout.addLayout(excl_load_row)

        # Exclusion zones
        excl_row = QHBoxLayout()
        self.btn_draw_exclusion = QPushButton("Draw Exclusion Zone")
        self.btn_draw_exclusion.setToolTip(
            "Mark areas where earthworks should not be placed.\n"
            "Optimal swale contours will be clipped to avoid these zones."
        )
        self.btn_clear_exclusion_zones = QPushButton("Clear")
        self.btn_clear_exclusion_zones.setEnabled(False)
        self.btn_toggle_exclusion_zones = QPushButton("Show")
        self.btn_toggle_exclusion_zones.setCheckable(True)
        self.btn_toggle_exclusion_zones.setChecked(True)
        self.btn_toggle_exclusion_zones.setEnabled(False)
        excl_row.addWidget(self.btn_draw_exclusion)
        excl_row.addWidget(self.btn_clear_exclusion_zones)
        excl_row.addWidget(self.btn_toggle_exclusion_zones)
        more_layout.addLayout(excl_row)

        # Volume report
        self.btn_volume_report = QPushButton("Volume Report")
        self.btn_volume_report.setEnabled(False)
        self.btn_volume_report.setToolTip(
            "Show total cut and fill volumes for all drawn earthworks."
        )
        more_layout.addWidget(self.btn_volume_report)

        # Contour flow analysis + cascade
        more_contour_row = QHBoxLayout()
        self.btn_analyse_contour_flow = QPushButton("Analyse Contour Flow")
        self.btn_analyse_contour_flow.setEnabled(False)
        self.btn_analyse_contour_flow.setToolTip(
            "Rank contours in the active layer by peak inflow.\n"
            "Requires: baseline analysis run + a contour layer."
        )
        self.btn_suggest_cascade = QPushButton("Suggest Cascade")
        self.btn_suggest_cascade.setEnabled(False)
        self.btn_suggest_cascade.setToolTip(
            "After Optimal Swale Contours, suggest spillway locations\n"
            "to chain swales into a cascade."
        )
        more_contour_row.addWidget(self.btn_analyse_contour_flow)
        more_contour_row.addWidget(self.btn_suggest_cascade)
        more_layout.addLayout(more_contour_row)

        opt_count_row = QHBoxLayout()
        opt_count_row.addWidget(QLabel("Optimal contours to find:"))
        self.spin_optimal_contour_count = QSpinBox()
        self.spin_optimal_contour_count.setRange(1, 10)
        self.spin_optimal_contour_count.setValue(5)
        opt_count_row.addWidget(self.spin_optimal_contour_count)
        more_layout.addLayout(opt_count_row)

        self.lbl_contour_flow_result = QLabel("")
        self.lbl_contour_flow_result.setWordWrap(True)
        self.lbl_contour_flow_result.setStyleSheet("color: #003080; font-size: 10px;")
        more_layout.addWidget(self.lbl_contour_flow_result)

        self._widget_more_ew_tools.setVisible(False)
        ew_layout.addWidget(self._widget_more_ew_tools)

        layout.addWidget(ew_group)

        # ----------------------------------------------------------- Results
        results_group = QGroupBox("Results")
        results_layout = QVBoxLayout(results_group)

        self.btn_query_ponding = QPushButton("Query Depression / Ponding")
        self.btn_query_ponding.setEnabled(False)
        self.btn_query_ponding.setToolTip(
            "Click on a blue zone in the 'Natural Depressions' or\n"
            "'Water Captured' layer to select the entire connected\n"
            "pooling area and report its volume and surface area.\n\n"
            "Baseline: shows natural low spots where water collects.\n"
            "Earthworks: shows water captured by your swales/basins."
        )
        self.lbl_ponding_result = QLabel("")
        self.lbl_ponding_result.setWordWrap(True)

        buffer_row = QHBoxLayout()
        buffer_row.addWidget(QLabel("Sizing buffer:"))
        self.spin_fill_buffer = QDoubleSpinBox()
        self.spin_fill_buffer.setRange(0, 100)
        self.spin_fill_buffer.setValue(20.0)
        self.spin_fill_buffer.setSuffix(" %")
        self.spin_fill_buffer.setDecimals(0)
        self.spin_fill_buffer.setFixedWidth(80)
        self.spin_fill_buffer.setToolTip(
            "Headroom above the design storm inflow.\n"
            "20% means target capacity = 1.2 × inflow.\n\n"
            "Well-sized:  fills to ≤ 1/(1+buffer) of capacity.\n"
            "Undersized:  inflow exceeds capacity — will overflow.\n"
            "Oversized:   too much capacity for the design storm."
        )
        buffer_row.addWidget(self.spin_fill_buffer)
        buffer_row.addStretch()

        results_layout.addWidget(self.btn_query_ponding)
        results_layout.addLayout(buffer_row)
        results_layout.addWidget(self.lbl_ponding_result)

        self.btn_toggle_streams = QPushButton("Show Stream Network")
        self.btn_toggle_streams.setCheckable(True)
        self.btn_toggle_streams.setEnabled(False)

        self.btn_toggle_accumulation = QPushButton("Show Flow Accumulation")
        self.btn_toggle_accumulation.setCheckable(True)
        self.btn_toggle_accumulation.setEnabled(False)

        self.btn_toggle_slope_arrows = QPushButton("Show Slope Direction")
        self.btn_toggle_slope_arrows.setCheckable(True)
        self.btn_toggle_slope_arrows.setEnabled(False)
        self.btn_toggle_slope_arrows.setToolTip(
            "Overlay arrows showing the direction of steepest downslope at regular intervals.\n"
            "Generated from the DEM aspect — arrows point in the direction water would flow."
        )

        self.txt_results = QTextEdit()
        self.txt_results.setReadOnly(True)
        self.txt_results.setMaximumHeight(160)
        self.txt_results.setPlaceholderText("Runoff summary will appear here after analysis.")

        self.btn_toggle_slope_class = QPushButton("Show Slope Classification")
        self.btn_toggle_slope_class.setCheckable(True)
        self.btn_toggle_slope_class.setEnabled(False)
        self.btn_toggle_slope_class.setToolTip(
            "Semi-transparent slope suitability overlay (calculated from DEM):\n"
            "  Green  (0–3°):   ideal — suitable for swales and basins\n"
            "  Yellow (3–8°):   moderate — suitable with care\n"
            "  Orange (8–15°):  challenging — consider companion berm\n"
            "  Red    (>15°):   steep — berms or diversion drains recommended"
        )
        results_layout.addWidget(self.btn_toggle_slope_class)

        # Inline slope legend — always shown so user knows what colours mean
        slope_legend = QWidget()
        slope_legend_layout = QHBoxLayout(slope_legend)
        slope_legend_layout.setContentsMargins(4, 0, 4, 2)
        slope_legend_layout.setSpacing(4)
        for hex_colour, lbl_text in [
            ("#50C850", "0–3°"),
            ("#DCDC1E", "3–8°"),
            ("#FF8C00", "8–15°"),
            ("#DC1E1E", ">15°"),
        ]:
            swatch = QLabel()
            swatch.setFixedSize(13, 13)
            swatch.setStyleSheet(
                f"background-color: {hex_colour}; border: 1px solid #888;"
            )
            lbl = QLabel(lbl_text)
            lbl.setStyleSheet("font-size: 10px;")
            slope_legend_layout.addWidget(swatch)
            slope_legend_layout.addWidget(lbl)
        slope_legend_layout.addStretch()
        results_layout.addWidget(slope_legend)

        results_layout.addWidget(self.btn_toggle_streams)
        results_layout.addWidget(self.btn_toggle_accumulation)
        results_layout.addWidget(self.btn_toggle_slope_arrows)
        results_layout.addWidget(self.txt_results)
        layout.addWidget(results_group)

        # ------------------------------------------------------- Simulation
        sim_group = QGroupBox("Simulation")
        sim_layout = QVBoxLayout(sim_group)

        # Rainfall mode selector
        sim_mode_row = QHBoxLayout()
        sim_mode_row.addWidget(QLabel("Rainfall input:"))
        self.combo_sim_rainfall_mode = QComboBox()
        self.combo_sim_rainfall_mode.addItems([
            "Uniform (use rainfall settings above)",
            "Custom CSV hyetograph",
        ])
        self.combo_sim_rainfall_mode.setToolTip(
            "Uniform: uses the intensity and duration from the Rainfall section above.\n"
            "Each timestep gets intensity × dt mm of rain.\n\n"
            "Custom CSV: load a gauge time-series CSV with columns:\n"
            "  time_min   — end of interval in minutes\n"
            "  rainfall_mm — cumulative (or per-interval) rainfall\n\n"
            "The timestep is derived from the CSV time column."
        )
        self.combo_sim_rainfall_mode.currentIndexChanged.connect(self._on_sim_mode_changed)
        sim_mode_row.addWidget(self.combo_sim_rainfall_mode)
        sim_layout.addLayout(sim_mode_row)

        # Uniform: timestep selector (shown by default)
        self._widget_sim_uniform = QWidget()
        sim_uniform_inner = QHBoxLayout(self._widget_sim_uniform)
        sim_uniform_inner.setContentsMargins(0, 0, 0, 0)
        sim_uniform_inner.addWidget(QLabel("Timestep:"))
        self.combo_sim_timestep = QComboBox()
        self.combo_sim_timestep.addItems(["5 min", "10 min", "15 min", "30 min", "60 min"])
        self.combo_sim_timestep.setCurrentIndex(2)   # default: 15 min
        self.combo_sim_timestep.setToolTip(
            "Time resolution for the simulation.\n"
            "Smaller steps give finer animation but produce more raster files."
        )
        sim_uniform_inner.addWidget(self.combo_sim_timestep)
        sim_uniform_inner.addStretch()
        sim_layout.addWidget(self._widget_sim_uniform)

        # CSV: file picker (hidden by default)
        self._widget_sim_csv = QWidget()
        sim_csv_inner = QVBoxLayout(self._widget_sim_csv)
        sim_csv_inner.setContentsMargins(0, 0, 0, 0)
        sim_csv_inner.setSpacing(2)
        sim_csv_file_row = QHBoxLayout()
        self.btn_sim_csv_browse = QPushButton("Browse CSV…")
        self.lbl_sim_csv_file = QLabel("No file selected")
        self.lbl_sim_csv_file.setStyleSheet("color: #555; font-style: italic;")
        sim_csv_file_row.addWidget(self.btn_sim_csv_browse)
        sim_csv_file_row.addWidget(self.lbl_sim_csv_file, 1)
        sim_csv_inner.addLayout(sim_csv_file_row)
        self.lbl_sim_csv_hint = QLabel("Columns required: time_min, rainfall_mm")
        self.lbl_sim_csv_hint.setStyleSheet("color: #888; font-size: 10px;")
        self.lbl_sim_csv_hint.setWordWrap(True)
        sim_csv_inner.addWidget(self.lbl_sim_csv_hint)
        self._widget_sim_csv.setVisible(False)
        sim_layout.addWidget(self._widget_sim_csv)

        # Run button + progress
        self.btn_run_simulation = QPushButton("Run Simulation")
        self.btn_run_simulation.setEnabled(False)
        self.btn_run_simulation.setToolTip(
            "Run a time-stepped flow simulation for the current storm.\n\n"
            "Rainfall is split into discrete intervals; each interval computes\n"
            "the incremental runoff and routes it through the flow network.\n\n"
            "Requires: baseline analysis run.\n"
            "Uses the current DEM (with earthworks if applied)."
        )
        sim_layout.addWidget(self.btn_run_simulation)
        self.progress_sim = QProgressBar()
        self.progress_sim.setRange(0, 100)
        self.progress_sim.setValue(0)
        self.lbl_sim_status = QLabel("")
        self.lbl_sim_status.setWordWrap(True)
        self.lbl_sim_status.setStyleSheet("color: #444; font-size: 10px;")
        sim_layout.addWidget(self.progress_sim)
        sim_layout.addWidget(self.lbl_sim_status)

        # Playback section (hidden until simulation completes)
        self._widget_sim_playback = QWidget()
        pb_layout = QVBoxLayout(self._widget_sim_playback)
        pb_layout.setContentsMargins(0, 4, 0, 0)
        pb_layout.setSpacing(4)

        # Thin divider
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        pb_layout.addWidget(line)

        # Display mode row
        display_row = QHBoxLayout()
        display_row.addWidget(QLabel("Display:"))
        self.combo_sim_display = QComboBox()
        self.combo_sim_display.addItems(["Incremental flow", "Cumulative flow"])
        self.combo_sim_display.setToolTip(
            "Incremental: shows flow accumulation generated by runoff in that timestep only.\n"
            "You see where water is actively moving during each time window.\n\n"
            "Cumulative: shows total flow accumulated from storm start up to this timestep.\n"
            "Builds up progressively — useful for seeing where water has passed."
        )
        display_row.addWidget(self.combo_sim_display)
        pb_layout.addLayout(display_row)

        # Slider row
        slider_row = QHBoxLayout()
        self.lbl_sim_time = QLabel("T = 0:00")
        self.lbl_sim_time.setStyleSheet("font-weight: bold; min-width: 60px;")
        self.slider_sim = QSlider(Qt.Horizontal)
        self.slider_sim.setRange(0, 0)
        self.slider_sim.setValue(0)
        slider_row.addWidget(self.lbl_sim_time)
        slider_row.addWidget(self.slider_sim, 1)
        pb_layout.addLayout(slider_row)

        # Play / Stop row
        play_row = QHBoxLayout()
        self.btn_sim_play = QPushButton("▶ Play")
        self.btn_sim_play.setCheckable(True)
        self.btn_sim_play.setToolTip("Auto-advance through simulation frames (1 second per step).")
        self.btn_sim_stop = QPushButton("■ Stop")
        self.btn_sim_stop.setToolTip("Stop playback and return to frame 0.")
        play_row.addWidget(self.btn_sim_play)
        play_row.addWidget(self.btn_sim_stop)
        play_row.addStretch()
        pb_layout.addLayout(play_row)

        self._widget_sim_playback.setVisible(False)
        sim_layout.addWidget(self._widget_sim_playback)

        layout.addWidget(sim_group)

        # ------------------------------------------------------- Keyline Analysis
        keyline_group = QGroupBox("Keyline Analysis (Yeomans)")
        keyline_layout = QVBoxLayout(keyline_group)

        keyline_layout.addWidget(QLabel(
            "Yeomans Keyline Design — find keypoints, ridgelines,\n"
            "pond sites, and cultivation lines from the DEM."
        ))

        # Settings row
        kl_settings_row = QHBoxLayout()
        kl_settings_row.addWidget(QLabel("Keypoints:"))
        self.spin_keypoint_count = QSpinBox()
        self.spin_keypoint_count.setRange(1, 10)
        self.spin_keypoint_count.setValue(3)
        self.spin_keypoint_count.setToolTip(
            "Number of keypoints to detect.\n"
            "Each keypoint is a valley inflection where slope eases from steep to gentle.\n"
            "Keypoints are spatially separated so they cover the full elevation range."
        )
        kl_settings_row.addWidget(self.spin_keypoint_count)
        kl_settings_row.addWidget(QLabel("Lines±:"))
        self.spin_keyline_lines = QSpinBox()
        self.spin_keyline_lines.setRange(1, 5)
        self.spin_keyline_lines.setValue(2)
        self.spin_keyline_lines.setToolTip(
            "Number of cultivation lines above and below each keyline.\n"
            "E.g. 2 = keyline + 2 above + 2 below = 5 lines per keypoint."
        )
        kl_settings_row.addWidget(self.spin_keyline_lines)
        keyline_layout.addLayout(kl_settings_row)

        kl_spacing_row = QHBoxLayout()
        kl_spacing_row.addWidget(QLabel("Line spacing (m):"))
        self.spin_keyline_spacing = QDoubleSpinBox()
        self.spin_keyline_spacing.setRange(1.0, 50.0)
        self.spin_keyline_spacing.setValue(5.0)
        self.spin_keyline_spacing.setDecimals(1)
        self.spin_keyline_spacing.setSuffix(" m")
        self.spin_keyline_spacing.setToolTip(
            "Vertical interval between cultivation lines (metres).\n"
            "Smaller spacing = more lines, more intensive water spreading."
        )
        kl_spacing_row.addWidget(self.spin_keyline_spacing)
        keyline_layout.addLayout(kl_spacing_row)

        # Action buttons row 1
        kl_btn_row1 = QHBoxLayout()
        self.btn_find_keypoints = QPushButton("Find Keypoints + Ridgelines")
        self.btn_find_keypoints.setEnabled(False)
        self.btn_find_keypoints.setToolTip(
            "Analyse the DEM and flow accumulation to locate:\n\n"
            "  Keypoints — valley inflection points where slope transitions\n"
            "  from steep to gentle. This is where Yeomans' keyline begins.\n\n"
            "  Ridgelines — watershed divides that separate drainage basins.\n\n"
            "Requires: baseline analysis run."
        )
        kl_btn_row1.addWidget(self.btn_find_keypoints)
        keyline_layout.addLayout(kl_btn_row1)

        # Action buttons row 2
        kl_btn_row2 = QHBoxLayout()
        self.btn_recommend_ponds = QPushButton("Recommend Pond Sites")
        self.btn_recommend_ponds.setEnabled(False)
        self.btn_recommend_ponds.setToolTip(
            "For each keypoint, find the optimal dam/pond location:\n"
            "the narrowest valley cross-section just downstream.\n\n"
            "Requires: keypoints found first."
        )
        self.btn_generate_keylines = QPushButton("Generate Keylines")
        self.btn_generate_keylines.setEnabled(False)
        self.btn_generate_keylines.setToolTip(
            "Generate the keyline (at keypoint elevation) and parallel\n"
            "cultivation lines above and below at the chosen spacing.\n\n"
            "Keylines are shown in orange; cultivation lines in gold.\n"
            "Use these as guides for swale placement.\n\n"
            "Requires: keypoints found first."
        )
        self.btn_generate_keyline_only = QPushButton("Keyline Only")
        self.btn_generate_keyline_only.setEnabled(False)
        self.btn_generate_keyline_only.setToolTip(
            "Generate only the keyline at each keypoint elevation.\n"
            "No parallel cultivation lines — just the keyline itself.\n\n"
            "Useful as a guide for placing a single contour swale\n"
            "at the Yeomans keyline position.\n\n"
            "Requires: keypoints found first."
        )
        kl_btn_row2.addWidget(self.btn_recommend_ponds)
        kl_btn_row2.addWidget(self.btn_generate_keylines)
        kl_btn_row2.addWidget(self.btn_generate_keyline_only)
        keyline_layout.addLayout(kl_btn_row2)

        # Toggle visibility row
        kl_toggle_row = QHBoxLayout()
        self.btn_toggle_ridgelines = QPushButton("Show Ridgelines")
        self.btn_toggle_ridgelines.setCheckable(True)
        self.btn_toggle_ridgelines.setEnabled(False)
        self.btn_toggle_keylines = QPushButton("Show Keylines")
        self.btn_toggle_keylines.setCheckable(True)
        self.btn_toggle_keylines.setEnabled(False)
        kl_toggle_row.addWidget(self.btn_toggle_ridgelines)
        kl_toggle_row.addWidget(self.btn_toggle_keylines)
        keyline_layout.addLayout(kl_toggle_row)

        self.lbl_keyline_result = QLabel("")
        self.lbl_keyline_result.setWordWrap(True)
        self.lbl_keyline_result.setStyleSheet("color: #5a3000; font-size: 10px;")
        keyline_layout.addWidget(self.lbl_keyline_result)

        layout.addWidget(keyline_group)

        layout.addStretch()
        scroll.setWidget(container)
        self.setWidget(scroll)

    # --------------------------------------------------------- preset handler

    def _on_preset_changed(self, index):
        label = self.combo_preset.currentText()
        intensity, duration = SCSRunoff.STORM_PRESETS[label]
        if intensity is not None:
            self.spin_intensity.setValue(intensity)
            self.spin_duration.setValue(duration)
            self.spin_intensity.setEnabled(False)
            self.spin_duration.setEnabled(False)
        else:
            self.spin_intensity.setEnabled(True)
            self.spin_duration.setEnabled(True)

    def _on_threshold_mode_changed(self, index):
        self._widget_volume_threshold.setVisible(index != 0)

    def _update_channel_type_label(self):
        ha = self.spin_threshold_ha.value()
        if ha < 0.5:
            ch_type = "Rill / erosion path"
            detail = "fine surface drainage, flows briefly during heavy rain"
        elif ha < 5.0:
            ch_type = "Ephemeral / seasonal channel"
            detail = "flows after rain, dry in summer"
        elif ha < 20.0:
            ch_type = "Permanent stream"
            detail = "year-round flow expected"
        else:
            ch_type = "River"
            detail = "major watercourse"
        self.lbl_channel_type.setText(f"↳  {ch_type}  —  {detail}")

    def _toggle_advanced_settings(self, checked):
        self._widget_advanced.setVisible(checked)
        arrow = "▼" if checked else "▶"
        self._btn_advanced.setText(f"{arrow}  Advanced Settings")

    def _toggle_more_ew_tools(self, checked):
        self._widget_more_ew_tools.setVisible(checked)
        arrow = "▼" if checked else "▶"
        self._btn_more_ew_tools.setText(f"{arrow}  More Earthwork Tools")

    def _toggle_cn_zones(self, checked):
        self._widget_cn_zones.setVisible(checked)
        arrow = "▼" if checked else "▶"
        self._btn_cn_zones.setText(f"{arrow}  CN Zone Mapping")

    def _toggle_consent(self, checked):
        self._widget_consent.setVisible(checked)
        arrow = "▼" if checked else "▶"
        self._btn_consent.setText(f"{arrow}  Resource Consent Thresholds")

    # --------------------------------------------------------- public helpers

    def get_moisture_key(self):
        return {0: "dry", 1: "normal", 2: "wet"}[self.combo_moisture.currentIndex()]

    def get_optimal_contour_count(self):
        return self.spin_optimal_contour_count.value()

    def get_routing(self):
        """Return 'dinf' or 'd8' based on the routing dropdown selection."""
        return "dinf" if self.combo_routing.currentIndex() == 0 else "d8"

    def get_threshold_mode(self):
        return "cells" if self.combo_threshold_mode.currentIndex() == 0 else "volume"

    def get_volume_threshold(self):
        return self.spin_volume_threshold.value()

    def get_stream_threshold_cells(self):
        """Convert ha threshold to cell count for analysis worker."""
        if self._cell_size_m2 and self._cell_size_m2 > 0:
            return max(1, int(self.spin_threshold_ha.value() * 10_000 / self._cell_size_m2))
        return 1000  # safe default before DEM is loaded

    def set_cell_size(self, cell_size_m2):
        """Called after DEM load with the cell area in m²."""
        self._cell_size_m2 = cell_size_m2
        self._update_channel_type_label()

    def update_preview_catchment_button(self):
        """Enable the Preview button when both DEM and boundary are loaded."""
        has_dem = bool(getattr(self, "_dem_path", None))
        has_boundary = self.combo_boundary_layer.currentLayer() is not None
        self.btn_preview_catchment.setEnabled(has_dem and has_boundary)

    def set_catchment_preview_result(self, area_ha, dem_area_ha, coverage_pct):
        """Show contributing area stats and reveal the Clip DEM button."""
        self.lbl_catchment_preview.setText(
            f"Contributing catchment: {area_ha:,.0f} ha "
            f"({coverage_pct:.0f}% of {dem_area_ha:,.0f} ha DEM).\n"
            f"Clip the DEM to this area before running full analysis."
        )
        self.lbl_catchment_preview.setVisible(True)
        self.btn_clip_dem.setVisible(True)
        self.btn_clip_dem.setEnabled(True)

    def set_dem_clipped(self, path):
        """Update status after DEM has been clipped to the catchment."""
        self.lbl_catchment_preview.setText(
            self.lbl_catchment_preview.text().rstrip() +
            f"\nClipped DEM saved — {os.path.basename(path)} is now active."
        )
        self.btn_clip_dem.setEnabled(False)

    def set_dem_path(self, path):
        self._dem_path = path
        self.lbl_dem_status.setText(os.path.basename(path))
        self.btn_run.setEnabled(True)
        self.btn_contours.setEnabled(True)
        self.btn_draw_cn_zone.setEnabled(True)
        self.lbl_status.setText("Ready to run analysis.")
        self.update_preview_catchment_button()

    def set_progress(self, value, message=""):
        self.progress_bar.setValue(value)
        if message:
            self.lbl_status.setText(message)

    def set_results_ready(self, summary_text=""):
        self.btn_toggle_streams.setEnabled(True)
        self.btn_toggle_accumulation.setEnabled(True)
        self.btn_toggle_slope_arrows.setEnabled(True)
        self.btn_reanalyse.setEnabled(True)
        self.lbl_status.setText("Analysis complete.")
        if summary_text:
            self.txt_results.setText(summary_text)

    # --------------------------------------------------------- simulation helpers

    def _on_sim_mode_changed(self, index):
        """Show/hide uniform or CSV widgets when rainfall mode changes."""
        is_csv = (index == 1)
        self._widget_sim_uniform.setVisible(not is_csv)
        self._widget_sim_csv.setVisible(is_csv)

    def get_sim_rainfall_mode(self):
        """Return 'uniform' or 'csv'."""
        return "csv" if self.combo_sim_rainfall_mode.currentIndex() == 1 else "uniform"

    def get_sim_timestep_min(self):
        """Return the selected timestep in minutes (uniform mode only)."""
        text = self.combo_sim_timestep.currentText()   # e.g. "15 min"
        try:
            return int(text.split()[0])
        except (ValueError, IndexError):
            return 15

    def set_sim_progress(self, value, message=""):
        self.progress_sim.setValue(value)
        if message:
            self.lbl_sim_status.setText(message)

    def set_simulation_ready(self, n_frames, time_labels):
        """Called when simulation completes — reveal playback controls."""
        self.slider_sim.setRange(0, max(0, n_frames - 1))
        self.slider_sim.setValue(0)
        self._widget_sim_playback.setVisible(True)
        self.lbl_sim_status.setText(
            f"Simulation complete — {n_frames} frame{'s' if n_frames != 1 else ''}."
        )

    def add_earthwork_to_list(self, index, summary):
        item = QListWidgetItem(summary)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
        item.setCheckState(Qt.Checked)
        item.setData(Qt.UserRole, index)
        self.list_earthworks.addItem(item)
        self.btn_place_spillway.setEnabled(True)
        self.btn_delete_earthwork.setEnabled(True)
        self.btn_edit_earthwork.setEnabled(True)
        self.btn_volume_report.setEnabled(True)

    def update_earthwork_in_list(self, index, summary):
        for i in range(self.list_earthworks.count()):
            item = self.list_earthworks.item(i)
            if item.data(Qt.UserRole) == index:
                item.setText(summary)
                break

    def refresh_earthwork_list(self, earthworks):
        self.list_earthworks.clear()
        for i, ew in enumerate(earthworks):
            item = QListWidgetItem(ew.summary())
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if ew.enabled else Qt.Unchecked)
            item.setData(Qt.UserRole, i)
            self.list_earthworks.addItem(item)

    def set_cn_zone_count(self, n):
        """Update the hint label showing how many CN zones are active."""
        if n == 0:
            self.lbl_cn_zones_hint.setText("No zones drawn — default CN applies everywhere.")
        else:
            self.lbl_cn_zones_hint.setText(
                f"{n} zone{'s' if n != 1 else ''} active. "
                "Re-run analysis to apply."
            )
        self.btn_delete_cn_zone.setEnabled(
            self.list_cn_zones.currentRow() >= 0 and n > 0
        )

    def get_keypoint_count(self):
        return self.spin_keypoint_count.value()

    def get_keyline_lines(self):
        return self.spin_keyline_lines.value()

    def get_keyline_spacing(self):
        return self.spin_keyline_spacing.value()

    # --------------------------------------------------------- session helpers

    def get_session_name(self):
        return self.edit_session_name.text().strip() or "Untitled Session"

    def set_session_name(self, name):
        self.edit_session_name.setText(name)

    # --------------------------------------------------------- consent helpers

    def get_consent_enabled(self):
        return self.chk_consent_enabled.isChecked()

    def get_consent_single_m3(self):
        return self.spin_consent_single_m3.value()

    def get_consent_total_m3(self):
        return self.spin_consent_total_m3.value()
