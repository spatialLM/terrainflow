def classFactory(iface):
    from .terrain_flow import TerrainFlow
    return TerrainFlow(iface)
