import os
import tempfile
import json
import numpy as np

from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QInputDialog
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsColorRampShader,
    QgsRasterShader, QgsSingleBandPseudoColorRenderer,
    QgsMessageLog, Qgis, QgsVectorLayer, QgsField,
    QgsFeature, QgsGeometry, QgsPointXY,
    QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsPalLayerSettings, QgsVectorLayerSimpleLabeling,
    QgsTextFormat, QgsWkbTypes, QgsLineSymbol,
    QgsFillSymbol, QgsRuleBasedRenderer,
    QgsCentroidFillSymbolLayer, QgsProperty,
    QgsSymbolLayer, QgsGraduatedSymbolRenderer, QgsRendererRange
)
from qgis.PyQt.QtCore import QVariant

from .terrain_flow_dialog import TerrainFlowPanel
from .processing.flow_analysis import FlowAnalysis
from .processing.scs_runoff import SCSRunoff
from .processing.earthwork import Earthwork, EarthworkManager, calculate_capacity
from .processing.dem_burner import DEMBurner
from .earthwork_properties_dialog import EarthworkPropertiesDialog
from .map_tools.draw_line_tool import DrawLineTool
from .map_tools.draw_polygon_tool import DrawPolygonTool
from .map_tools.place_point_tool import PlacePointTool
from .map_tools.ponding_query_tool import PondingQueryTool
from .map_tools.select_contour_tool import SelectContourTool


# ---------------------------------------------------------------------------
# Background worker
# ---------------------------------------------------------------------------

class AnalysisWorker(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, dem_path, output_dir, stream_threshold, cn, moisture,
                 rainfall_mm, duration_hours, boundary_path=None, label="",
                 run_catchments=False, threshold_mode="cells", volume_threshold=50.0):
        super().__init__()
        self.dem_path = dem_path
        self.output_dir = output_dir
        self.stream_threshold = stream_threshold
        self.cn = cn
        self.moisture = moisture
        self.rainfall_mm = rainfall_mm
        self.duration_hours = duration_hours
        self.boundary_path = boundary_path
        self.label = label
        self.run_catchments = run_catchments
        self.threshold_mode = threshold_mode
        self.volume_threshold = volume_threshold

    def run(self):
        try:
            analysis = FlowAnalysis()
            scs = SCSRunoff()

            self.progress.emit(10, "Loading DEM...")
            analysis.load_dem(self.dem_path)

            self.progress.emit(40, "Computing flow direction and accumulation...")
            results = analysis.run()

            self.progress.emit(70, "Extracting stream network...")
            self.progress.emit(82, "Calculating runoff volume...")
            effective_cn = scs.adjust_cn(self.cn, self.moisture)
            runoff_mm = scs.runoff_depth(self.rainfall_mm, effective_cn)
            cell_area_m2 = abs(analysis.transform.a * analysis.transform.e)
            catchment_area_m2 = float(np.sum(results["flow_accumulation"] > 0)) * cell_area_m2
            runoff_volume = analysis.get_runoff_volume_raster(runoff_mm, cell_area_m2)

            # Build stream network mask based on threshold mode.
            # Stream raster stores accumulation values at stream cells (not binary)
            # so the renderer can apply a size/colour gradient by flow magnitude.
            acc_array = np.array(results["flow_accumulation"])
            if self.threshold_mode == "volume":
                runoff_m = runoff_mm / 1000.0
                vol_array = acc_array * cell_area_m2 * runoff_m
                stream_mask = vol_array > self.volume_threshold
                mode_desc = f"volume_gt{self.volume_threshold:.1f}m3"
            else:
                stream_mask = acc_array > self.stream_threshold
                mode_desc = f"cells_gt{self.stream_threshold}"

            # Values at stream cells = upstream cell count (encodes stream size)
            stream_values = np.where(stream_mask, acc_array, 0).astype("float32")
            stream_acc_max = float(np.max(stream_values)) if stream_mask.any() else float(self.stream_threshold)

            # Filenames encode scenario + label
            moisture_label = self.moisture.replace(" ", "").replace("/", "")
            prefix = f"{self.label}_" if self.label else ""
            acc_path  = os.path.join(self.output_dir, f"{prefix}flow_accumulation.tif")
            fdir_path = os.path.join(self.output_dir, f"{prefix}flow_direction.tif")
            streams_path = os.path.join(self.output_dir, f"{prefix}streams_{mode_desc}.tif")
            runoff_name = f"{prefix}runoff_{int(self.rainfall_mm)}mm_cn{int(self.cn)}_{moisture_label}.tif"
            runoff_path = os.path.join(self.output_dir, runoff_name)

            analysis.save_result(
                results["flow_accumulation"], acc_path,
                band_description="Upstream cell count — number of DEM cells draining through each point"
            )
            analysis.save_result(
                np.array(analysis.fdir).astype("float32"), fdir_path,
                band_description="D8 flow direction (ESRI codes: 1=E 2=SE 4=S 8=SW 16=W 32=NW 64=N 128=NE)"
            )
            analysis.save_result(
                stream_values, streams_path,
                band_description=f"Stream network — cell value = upstream cell count at stream cells ({mode_desc}), 0 = no stream"
            )
            analysis.save_result(
                runoff_volume, runoff_path,
                band_description="Surface runoff volume (m³) — accumulated runoff passing through each cell for this storm scenario"
            )

            # Ponding / depression layer — baseline shows natural depressions;
            # earthworks run shows water captured by the modified terrain.
            self.progress.emit(88, "Calculating depressions and water capture...")
            burner = DEMBurner(self.dem_path)
            ponding = burner.get_ponding_layer(np.array(analysis.dem, dtype="float32"))
            ponding_path = os.path.join(self.output_dir, f"{prefix}ponding.tif")
            analysis.save_result(ponding, ponding_path)

            # Exit points
            exit_points = []
            if self.boundary_path:
                self.progress.emit(92, "Detecting boundary exit points...")
                exit_points = analysis.get_boundary_exit_points(
                    self.boundary_path, self.stream_threshold, runoff_mm, self.duration_hours
                )

            # Catchment polygons (optional — controlled by UI toggle)
            catchments = []
            if self.run_catchments:
                self.progress.emit(95, "Delineating catchment polygons...")
                outlet_points = [(p["x"], p["y"]) for p in exit_points] if exit_points else None
                catchments = analysis.get_catchment_polygons(outlet_points, stream_threshold=self.stream_threshold)

            self.progress.emit(100, "Done.")
            self.finished.emit({
                "label": self.label,
                "flow_accumulation": acc_path,
                "flow_direction": fdir_path,
                "stream_network": streams_path,
                "stream_acc_max": stream_acc_max,
                "stream_threshold": self.stream_threshold,
                "runoff_volume": runoff_path,
                "ponding": ponding_path,
                "effective_cn": effective_cn,
                "runoff_mm": runoff_mm,
                "cell_area_m2": cell_area_m2,
                "catchment_area_m2": catchment_area_m2,
                "runoff_volume_max": float(np.nanmax(runoff_volume)) if runoff_mm > 0 else 1.0,
                "exit_points": exit_points,
                "catchments": catchments,
            })
        except Exception as e:
            import traceback
            self.error.emit(traceback.format_exc())


# ---------------------------------------------------------------------------
# Main plugin class
# ---------------------------------------------------------------------------

class TerrainFlow:

    def __init__(self, iface):
        self.iface = iface
        self.panel = None
        self.action = None
        self.worker = None
        self.output_dir = tempfile.mkdtemp(prefix="terrainflow_")
        self._scs = SCSRunoff()
        self._earthwork_manager = EarthworkManager()
        self._runoff_scale_max = None
        self._dem_path = None
        self._modified_dem_path = None
        self._burner = None
        # Layer ID tracking
        self._baseline_layer_ids = []
        self._earthworks_layer_ids = []
        self._ponding_raster_path = None
        self._earthwork_vector_layer = None
        self._spillway_vector_layer = None
        self._showing_baseline = True
        # Map tools
        self._current_tool = None
        # Slope arrows
        self._slope_arrow_layer_id = None
        # Slope classification
        self._slope_raster_path = None
        self._slope_class_layer_id = None
        # Exclusion zones
        self._exclusion_zone_layer = None
        self._overlap_highlight_layer = None
        # Contour flow analysis state
        self._contour_layer = None
        self._acc_tif_path = None
        self._fdir_tif_path = None
        self._last_cell_area_m2 = None
        self._last_runoff_mm = None
        self._last_stream_threshold = 1000
        self._contour_flow_results = []

    # ---------------------------------------------------------------- init / unload

    def initGui(self):
        self.action = QAction("TerrainFlow", self.iface.mainWindow())
        self.action.triggered.connect(self.toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("TerrainFlow", self.action)
        self._create_panel()

    def unload(self):
        self.iface.removePluginMenu("TerrainFlow", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.panel:
            self.iface.removeDockWidget(self.panel)

    def toggle_panel(self):
        if self.panel:
            self.panel.setVisible(not self.panel.isVisible())

    # ---------------------------------------------------------------- panel

    def _create_panel(self):
        self.panel = TerrainFlowPanel(self.iface.mainWindow())

        # Data — DEM auto-applied when combo selection changes
        self.panel.btn_load_dem.clicked.connect(self._load_dem)
        self.panel.combo_dem_layer.layerChanged.connect(self._on_dem_layer_changed)

        # Analysis
        self.panel.btn_run.clicked.connect(self._run_baseline)

        # Results toggles
        self.panel.btn_toggle_streams.toggled.connect(self._toggle_streams_layer)
        self.panel.btn_toggle_accumulation.toggled.connect(self._toggle_accumulation_layer)
        self.panel.btn_toggle_slope_arrows.toggled.connect(self._toggle_slope_arrows)
        self.panel.btn_toggle_slope_class.toggled.connect(self._toggle_slope_class_layer)

        # Earthworks
        self.panel.btn_draw_swale.clicked.connect(lambda: self._activate_draw_line("swale"))
        self.panel.btn_draw_berm.clicked.connect(lambda: self._activate_draw_line("berm"))
        self.panel.btn_draw_basin.clicked.connect(self._activate_draw_basin)
        self.panel.btn_place_spillway.clicked.connect(self._activate_place_spillway)
        self.panel.btn_delete_earthwork.clicked.connect(self._delete_selected_earthwork)
        self.panel.btn_edit_earthwork.clicked.connect(self._edit_selected_earthwork)
        self.panel.list_earthworks.itemChanged.connect(self._on_earthwork_toggled)
        self.panel.list_earthworks.itemDoubleClicked.connect(self._edit_selected_earthwork)
        self.panel.btn_reanalyse.clicked.connect(self._run_with_earthworks)
        self.panel.btn_toggle_before_after.toggled.connect(self._toggle_before_after)
        self.panel.btn_contours.clicked.connect(self._generate_contours)
        self.panel.btn_query_ponding.clicked.connect(self._activate_ponding_query)
        self.panel.btn_analyse_contour_flow.clicked.connect(self._analyse_contour_flow)
        self.panel.btn_optimal_swale_contours.clicked.connect(self._find_optimal_swale_contours)
        self.panel.btn_contour_swale.clicked.connect(self._activate_contour_swale)
        self.panel.btn_draw_exclusion.clicked.connect(self._activate_draw_exclusion_zone)
        self.panel.btn_clear_exclusion_zones.clicked.connect(self._clear_exclusion_zones)
        self.panel.btn_toggle_exclusion_zones.toggled.connect(self._toggle_exclusion_zones)

        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.panel)

    # ---------------------------------------------------------------- DEM loading

    def _on_dem_layer_changed(self, layer):
        if layer:
            self._set_dem(layer.source())

    def _load_dem(self):
        path, _ = QFileDialog.getOpenFileName(
            self.panel, "Select DEM GeoTIFF", "", "GeoTIFF (*.tif *.tiff)"
        )
        if path:
            layer = QgsRasterLayer(path, "DEM")
            if not layer.isValid():
                QMessageBox.critical(self.panel, "Error", "Could not load DEM.")
                return
            QgsProject.instance().addMapLayer(layer)
            self._set_dem(path)

    def _set_dem(self, path):
        self._dem_path = path
        self._runoff_scale_max = None
        self._burner = DEMBurner(path)
        self.panel.set_dem_path(path)
        # Pass cell area so the threshold hint can show contributing area in ha
        self.panel.set_cell_size(self._burner.cell_size ** 2)
        # Auto-calculate slope classification layer
        self._calculate_slope_layer()

    # ---------------------------------------------------------------- analysis

    def _run_baseline(self):
        if not self._dem_path:
            return
        self._run_analysis(self._dem_path, label="baseline")

    def _run_with_earthworks(self):
        if not self._dem_path:
            return
        enabled = self._earthwork_manager.get_enabled()
        if not enabled:
            QMessageBox.information(self.panel, "No earthworks", "Draw and enable at least one earthwork first.")
            return

        self.panel.set_progress(0, "Applying earthworks to DEM...")
        modified = self._burner.burn_earthworks(enabled)
        self._modified_dem_path = os.path.join(self.output_dir, "dem_modified.tif")
        self._burner.save(modified, self._modified_dem_path)
        self._run_analysis(self._modified_dem_path, label="earthworks")

    def _run_analysis(self, dem_path, label):
        self.panel.btn_run.setEnabled(False)
        self.panel.btn_reanalyse.setEnabled(False)
        self.panel.set_progress(0, "Starting analysis...")

        intensity = self.panel.spin_intensity.value()
        duration = self.panel.spin_duration.value()
        boundary_layer = self.panel.combo_boundary_layer.currentLayer()

        self.worker = AnalysisWorker(
            dem_path=dem_path,
            output_dir=self.output_dir,
            stream_threshold=self.panel.get_stream_threshold_cells(),
            cn=self.panel.spin_cn.value(),
            moisture=self.panel.get_moisture_key(),
            rainfall_mm=intensity * duration,
            duration_hours=duration,
            boundary_path=boundary_layer.source() if boundary_layer else None,
            label=label,
            run_catchments=self.panel.chk_catchments.isChecked(),
            threshold_mode=self.panel.get_threshold_mode(),
            volume_threshold=self.panel.get_volume_threshold(),
        )
        self.worker.progress.connect(self.panel.set_progress)
        self.worker.finished.connect(self._on_analysis_complete)
        self.worker.error.connect(self._on_analysis_error)
        self.worker.start()

    # ---------------------------------------------------------------- analysis complete

    def _on_analysis_complete(self, result_paths):
        label = result_paths["label"]
        is_baseline = label == "baseline"

        # Store analysis state for contour flow analysis
        if is_baseline:
            self._acc_tif_path  = result_paths["flow_accumulation"]
            self._fdir_tif_path = result_paths.get("flow_direction")
            self._last_cell_area_m2 = result_paths["cell_area_m2"]
            self._last_runoff_mm = result_paths["runoff_mm"]
            self._last_stream_threshold = result_paths["stream_threshold"]
            # Optimal contours only need analysis (no pre-existing contours)
            self.panel.btn_optimal_swale_contours.setEnabled(True)
            # Contour flow analysis also needs a contour layer
            if self._contour_layer:
                self.panel.btn_analyse_contour_flow.setEnabled(True)

        # Flow accumulation + stream network (baseline only — terrain doesn't change)
        if is_baseline:
            if not hasattr(self, "_acc_layer_id"):
                acc_layer = QgsRasterLayer(
                    result_paths["flow_accumulation"],
                    "Flow Accumulation (upstream cell count)"
                )
                if acc_layer.isValid():
                    self._apply_accumulation_ramp(acc_layer)
                    QgsProject.instance().addMapLayer(acc_layer)
                    self._acc_layer_id = acc_layer.id()
                    self._baseline_layer_ids.append(acc_layer.id())

            if not hasattr(self, "_stream_layer_id"):
                mode = self.panel.get_threshold_mode()
                if mode == "cells":
                    name = f"Stream Network (>{self.panel.spin_threshold_ha.value():.1f} ha)"
                else:
                    name = f"Stream Network (>{self.panel.get_volume_threshold():.0f} m³)"
                stream_layer = QgsRasterLayer(result_paths["stream_network"], name)
                if stream_layer.isValid():
                    self._apply_stream_ramp(
                        stream_layer,
                        result_paths["stream_threshold"],
                        result_paths["stream_acc_max"],
                    )
                    QgsProject.instance().addMapLayer(stream_layer)
                    self._stream_layer_id = stream_layer.id()
                    self._baseline_layer_ids.append(stream_layer.id())

        # Runoff volume — always add as new named layer
        if self._runoff_scale_max is None:
            self._runoff_scale_max = result_paths["runoff_volume_max"]

        runoff_path = result_paths["runoff_volume"]
        layer_name = os.path.splitext(os.path.basename(runoff_path))[0]
        runoff_layer = QgsRasterLayer(runoff_path, layer_name)
        if runoff_layer.isValid():
            self._apply_runoff_ramp(runoff_layer, self._runoff_scale_max)
            QgsProject.instance().addMapLayer(runoff_layer)
            if is_baseline:
                self._baseline_layer_ids.append(runoff_layer.id())
            else:
                self._earthworks_layer_ids.append(runoff_layer.id())

        # Ponding / depressions layer — shown for both baseline and earthworks runs
        if result_paths.get("ponding"):
            self._ponding_raster_path = result_paths["ponding"]
            layer_name = (
                "Natural Depressions — depth (metres)"
                if is_baseline else
                "Water Captured — ponding depth (metres)"
            )
            ponding_layer = QgsRasterLayer(self._ponding_raster_path, layer_name)
            if ponding_layer.isValid():
                self._apply_ponding_ramp(ponding_layer)
                QgsProject.instance().addMapLayer(ponding_layer)
                if is_baseline:
                    self._baseline_layer_ids.append(ponding_layer.id())
                else:
                    self._earthworks_layer_ids.append(ponding_layer.id())
                self.panel.btn_query_ponding.setEnabled(True)
                hint = (
                    "Click 'Query Depression/Ponding' then click a blue zone to measure its volume."
                    if is_baseline else
                    "Click 'Query Depression/Ponding' then click a blue ponding zone on the map."
                )
                self.panel.lbl_ponding_result.setText(hint)

        # Exit points
        exit_points = result_paths.get("exit_points", [])
        if exit_points:
            self._display_exit_points(exit_points)

        # Catchment polygons
        catchments = result_paths.get("catchments", [])
        if catchments:
            self._display_catchments(catchments, label=label)

        # Enable before/after toggle once both runs exist
        if self._baseline_layer_ids and self._earthworks_layer_ids:
            self.panel.btn_toggle_before_after.setEnabled(True)

        # Summary
        intensity = self.panel.spin_intensity.value()
        duration = self.panel.spin_duration.value()
        rainfall_mm = intensity * duration
        effective_cn = result_paths["effective_cn"]
        runoff_mm = result_paths["runoff_mm"]
        runoff_ratio = runoff_mm / rainfall_mm if rainfall_mm > 0 else 0
        catchment_ha = result_paths["catchment_area_m2"] / 10000
        volume_m3 = self._scs.catchment_volume(runoff_mm, result_paths["catchment_area_m2"])
        avg_flow_ls = (volume_m3 * 1000) / (duration * 3600) if duration > 0 else 0

        tag = "Baseline" if is_baseline else "With Earthworks"
        summary = (
            f"=== {tag} ===\n"
            f"Rainfall:         {rainfall_mm:.1f} mm ({intensity:.0f} mm/hr × {duration:.1f} hr)\n"
            f"CN (entered):     {self.panel.spin_cn.value()}\n"
            f"CN (adjusted):    {effective_cn:.1f}  [{self.panel.combo_moisture.currentText()}]\n"
            f"Runoff depth:     {runoff_mm:.1f} mm\n"
            f"Runoff ratio:     {runoff_ratio*100:.0f}% of rainfall\n"
            f"Catchment area:   {catchment_ha:.1f} ha\n"
            f"Total runoff vol: {volume_m3:,.0f} m³  ({volume_m3*1000:,.0f} L)\n"
            f"Avg flow rate:    {avg_flow_ls:,.0f} L/s  (outlet, storm avg)"
        )

        if exit_points:
            exit_lines = "\n".join(f"  {p['label']}" for p in exit_points)
            summary += f"\n\nSite exit points ({len(exit_points)}):\n{exit_lines}"

        catchments = result_paths.get("catchments", [])
        if catchments:
            catch_lines = "\n".join(f"  {c['label']}" for c in catchments)
            summary += f"\n\nCatchment areas ({len(catchments)}):\n{catch_lines}"

        self.panel.btn_run.setEnabled(True)
        self.panel.set_results_ready(summary)

    def _on_analysis_error(self, message):
        self.panel.btn_run.setEnabled(True)
        self.panel.btn_reanalyse.setEnabled(True)
        self.panel.set_progress(0, "Error — see log.")
        QMessageBox.critical(self.panel, "Analysis Error", message)
        QgsMessageLog.logMessage(message, "TerrainFlow", Qgis.Critical)

    # ---------------------------------------------------------------- earthwork drawing

    def _activate_draw_line(self, ew_type):
        colors = {"swale": QColor(0, 100, 220, 200), "berm": QColor(160, 100, 30, 200)}
        tool = DrawLineTool(self.iface.mapCanvas(), color=colors.get(ew_type))
        tool.line_drawn.connect(lambda geom: self._on_geometry_drawn(ew_type, geom))
        tool.cancelled.connect(self._on_draw_cancelled)
        self.iface.mapCanvas().setMapTool(tool)
        self._current_tool = tool
        self.panel.lbl_status.setText(f"Drawing {ew_type}... right-click or double-click to finish, Esc to cancel.")

    def _activate_draw_basin(self):
        tool = DrawPolygonTool(self.iface.mapCanvas())
        tool.polygon_drawn.connect(lambda geom: self._on_geometry_drawn("basin", geom))
        tool.cancelled.connect(self._on_draw_cancelled)
        self.iface.mapCanvas().setMapTool(tool)
        self._current_tool = tool
        self.panel.lbl_status.setText("Drawing basin... right-click or double-click to finish, Esc to cancel.")

    def _on_draw_cancelled(self):
        self.panel.lbl_status.setText("Drawing cancelled.")

    def _on_geometry_drawn(self, ew_type, geometry):
        """Geometry drawn — show properties dialog, then add earthwork."""
        dlg = EarthworkPropertiesDialog(ew_type, geometry, parent=self.panel)
        if dlg.exec_() != EarthworkPropertiesDialog.Accepted:
            return

        ew = Earthwork(ew_type, geometry, dlg.get_name())
        ew.depth = dlg.get_depth()
        ew.width = dlg.get_width()
        ew.companion_berm = dlg.get_companion_berm()
        ew.capacity_m3, ew.capacity_l = calculate_capacity(
            ew_type, geometry, ew.depth, ew.width, ew.companion_berm
        )

        index = len(self._earthwork_manager)
        self._earthwork_manager.add(ew)
        self.panel.add_earthwork_to_list(index, ew.summary())
        self._add_earthwork_to_map(ew)
        self._delineate_and_display_catchment(geometry, ew_type, ew.name)

        status_msg = f"'{ew.name}' added."
        if ew_type == "swale":
            max_slope = self._check_swale_slope(geometry)
            if max_slope is not None:
                if max_slope > 15.0:
                    status_msg += (
                        f"  ⚠ Slope {max_slope:.0f}° — too steep for swales. "
                        "Recommend berm or diversion drain instead."
                    )
                elif max_slope > 8.0:
                    status_msg += (
                        f"  ⚠ Slope {max_slope:.0f}° — consider a companion berm "
                        "on the downhill side for stability."
                    )
            overlap = self._get_exclusion_overlap(geometry)
            if overlap:
                status_msg += "  ⛔ Earthwork overlaps an exclusion zone — adjust placement."
                self._show_overlap_highlight(overlap)
        self.panel.lbl_status.setText(status_msg)

    def _edit_selected_earthwork(self, *args):
        row = self.panel.list_earthworks.currentRow()
        if row < 0:
            return
        ew = self._earthwork_manager.get(row)
        dlg = EarthworkPropertiesDialog(ew.type, ew.geometry, parent=self.panel, earthwork=ew)
        if dlg.exec_() != EarthworkPropertiesDialog.Accepted:
            return
        ew.name = dlg.get_name()
        ew.depth = dlg.get_depth()
        ew.width = dlg.get_width()
        ew.companion_berm = dlg.get_companion_berm()
        ew.capacity_m3, ew.capacity_l = calculate_capacity(
            ew.type, ew.geometry, ew.depth, ew.width, ew.companion_berm
        )
        if dlg.get_spillway_elevation() is not None:
            ew.spillway_elevation = dlg.get_spillway_elevation()
        self.panel.update_earthwork_in_list(row, ew.summary())

    def _delete_selected_earthwork(self):
        row = self.panel.list_earthworks.currentRow()
        if row < 0:
            return
        self._earthwork_manager.remove(row)
        self.panel.list_earthworks.takeItem(row)
        self._refresh_earthwork_layer()
        self.panel.refresh_earthwork_list(self._earthwork_manager.get_all())

    def _on_earthwork_toggled(self, item):
        index = item.data(Qt.UserRole)
        enabled = item.checkState() == Qt.Checked
        ew = self._earthwork_manager.get(index)
        if ew.enabled != enabled:
            self._earthwork_manager.toggle(index)

    # ---------------------------------------------------------------- spillway

    def _activate_place_spillway(self):
        row = self.panel.list_earthworks.currentRow()
        if row < 0:
            QMessageBox.information(self.panel, "No earthwork selected",
                                    "Select an earthwork in the list, then place its spillway.")
            return
        tool = PlacePointTool(self.iface.mapCanvas())
        tool.point_placed.connect(lambda pt: self._on_spillway_placed(row, pt))
        self.iface.mapCanvas().setMapTool(tool)
        self.panel.lbl_status.setText("Click on the map to place the spillway point...")

    def _on_spillway_placed(self, ew_index, point):
        ew = self._earthwork_manager.get(ew_index)
        ew.spillway_point = point
        elev, ok = QInputDialog.getDouble(
            self.panel, "Spillway Elevation",
            f"Set spillway overflow elevation for '{ew.name}' (metres):",
            value=0.0, min=0.0, max=5000.0, decimals=2
        )
        if ok:
            ew.spillway_elevation = elev
        self._add_spillway_to_map(point, ew.name)
        self.panel.lbl_status.setText(f"Spillway placed for '{ew.name}'.")

    # ---------------------------------------------------------------- map layers

    def _ensure_earthwork_layer(self):
        if self._earthwork_vector_layer and QgsProject.instance().mapLayer(self._earthwork_vector_layer.id()):
            return
        layer = QgsVectorLayer("LineString", "Earthworks", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("name", QVariant.String),
            QgsField("type", QVariant.String),
            QgsField("depth_m", QVariant.Double),
            QgsField("width_m", QVariant.Double),
            QgsField("capacity_m3", QVariant.Double),
        ])
        layer.updateFields()
        self._style_earthwork_layer(layer)
        QgsProject.instance().addMapLayer(layer)
        self._earthwork_vector_layer = layer

    def _ensure_spillway_layer(self):
        if self._spillway_vector_layer and QgsProject.instance().mapLayer(self._spillway_vector_layer.id()):
            return
        layer = QgsVectorLayer("Point", "Spillway Points", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([QgsField("earthwork", QVariant.String)])
        layer.updateFields()
        symbol = QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "0,80,220,220",
            "outline_color": "0,40,160", "size": "4"
        })
        layer.setRenderer(QgsSingleSymbolRenderer(symbol))
        QgsProject.instance().addMapLayer(layer)
        self._spillway_vector_layer = layer

    def _add_earthwork_to_map(self, ew):
        self._ensure_earthwork_layer()
        f = QgsFeature()
        f.setGeometry(ew.geometry)
        f.setAttributes([ew.name, ew.type, ew.depth, ew.width, ew.capacity_m3])
        self._earthwork_vector_layer.dataProvider().addFeatures([f])
        self._earthwork_vector_layer.updateExtents()
        self._earthwork_vector_layer.triggerRepaint()

    def _add_spillway_to_map(self, point, ew_name):
        self._ensure_spillway_layer()
        f = QgsFeature()
        f.setGeometry(QgsGeometry.fromPointXY(point))
        f.setAttributes([ew_name])
        self._spillway_vector_layer.dataProvider().addFeatures([f])
        self._spillway_vector_layer.triggerRepaint()

    def _refresh_earthwork_layer(self):
        """Rebuild the earthwork vector layer from the manager state."""
        if self._earthwork_vector_layer:
            pr = self._earthwork_vector_layer.dataProvider()
            pr.truncate()
            features = []
            for ew in self._earthwork_manager.get_all():
                f = QgsFeature()
                f.setGeometry(ew.geometry)
                f.setAttributes([ew.name, ew.type, ew.depth, ew.width, ew.capacity_m3])
                features.append(f)
            pr.addFeatures(features)
            self._earthwork_vector_layer.updateExtents()
            self._earthwork_vector_layer.triggerRepaint()

    def _style_earthwork_layer(self, layer):
        """Colour swales blue, berms brown, basins green."""
        root_rule = QgsRuleBasedRenderer.Rule(None)
        styles = {
            "swale": ("\"type\" = 'swale'", "0,100,220", "Swale"),
            "berm":  ("\"type\" = 'berm'",  "140,90,30", "Berm"),
            "basin": ("\"type\" = 'basin'", "30,160,60", "Basin"),
        }
        for key, (expr, color, label) in styles.items():
            sym = QgsLineSymbol.createSimple({"color": color, "width": "1.0"})
            rule = QgsRuleBasedRenderer.Rule(sym)
            rule.setFilterExpression(expr)
            rule.setLabel(label)
            root_rule.appendChild(rule)
        layer.setRenderer(QgsRuleBasedRenderer(root_rule))

    def _display_catchments(self, catchments, label=""):
        """Display catchment polygons as a styled vector layer with area labels."""
        if not catchments:
            return

        layer_name = f"Catchments ({label})" if label else "Catchments"

        # Remove previous catchment layer with the same name
        for lyr in QgsProject.instance().mapLayersByName(layer_name):
            QgsProject.instance().removeMapLayer(lyr)

        layer = QgsVectorLayer("Polygon", layer_name, "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("id",           QVariant.Int),
            QgsField("area_m2",      QVariant.Double),
            QgsField("area_ha",      QVariant.Double),
            QgsField("flow_bearing", QVariant.Double),
            QgsField("label",        QVariant.String),
        ])
        layer.updateFields()

        colours = [
            QColor(100, 180, 255, 80),
            QColor(255, 180, 80,  80),
            QColor(80,  220, 120, 80),
            QColor(220, 100, 220, 80),
            QColor(255, 255, 80,  80),
        ]

        features = []
        for c in catchments:
            qgs_geom = QgsGeometry.fromWkt(c["geometry"].wkt)
            f = QgsFeature()
            f.setGeometry(qgs_geom)
            f.setAttributes([
                c["id"], c["area_m2"], c["area_ha"],
                c.get("flow_bearing", 0.0), c["label"]
            ])
            features.append(f)
        pr.addFeatures(features)

        def _make_catchment_symbol(color_str):
            """Fill polygon + centroid arrow showing dominant flow direction."""
            sym = QgsFillSymbol.createSimple({
                "color": color_str,
                "outline_color": "60,60,60,200",
                "outline_width": "0.6",
            })
            # Add a centroid marker (arrow) rotated by flow_bearing attribute
            try:
                centroid_layer = QgsCentroidFillSymbolLayer()
                arrow = QgsMarkerSymbol.createSimple({
                    "name": "filled_arrowhead",
                    "color": "0,60,160,200",
                    "size": "6",
                    "angle": "0",
                })
                # Data-defined rotation from flow_bearing field
                arrow.symbolLayer(0).setDataDefinedProperty(
                    QgsSymbolLayer.PropertyAngle,
                    QgsProperty.fromField("flow_bearing")
                )
                centroid_layer.setSubSymbol(arrow)
                sym.appendSymbolLayer(centroid_layer)
            except Exception:
                pass  # Arrow is cosmetic — don't fail if QGIS API differs
            return sym

        if len(catchments) == 1:
            layer.setRenderer(QgsSingleSymbolRenderer(
                _make_catchment_symbol("100,180,255,80")
            ))
        else:
            root_rule = QgsRuleBasedRenderer.Rule(None)
            for i, c in enumerate(catchments):
                col = colours[i % len(colours)]
                col_str = f"{col.red()},{col.green()},{col.blue()},{col.alpha()}"
                rule = QgsRuleBasedRenderer.Rule(_make_catchment_symbol(col_str))
                rule.setFilterExpression(f'"id" = {c["id"]}')
                rule.setLabel(c["label"])
                root_rule.appendChild(rule)
            layer.setRenderer(QgsRuleBasedRenderer(root_rule))

        # Label with area
        lbl = QgsPalLayerSettings()
        lbl.fieldName = "label"
        lbl.enabled = True
        try:
            lbl.placement = Qgis.LabelPlacement.OverPoint
        except Exception:
            pass
        tf = QgsTextFormat()
        tf.setColor(QColor(0, 40, 120))
        lbl.setFormat(tf)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl))
        layer.setLabelsEnabled(True)

        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer)

    def _display_exit_points(self, exit_points):
        existing = QgsProject.instance().mapLayersByName("Site Exit Points")
        for layer in existing:
            QgsProject.instance().removeMapLayer(layer)

        layer = QgsVectorLayer("Point", "Site Exit Points", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("label", QVariant.String),
            QgsField("volume_m3", QVariant.Double),
            QgsField("flow_ls", QVariant.Double),
        ])
        layer.updateFields()

        features = []
        for p in exit_points:
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(p["x"], p["y"])))
            f.setAttributes([p["label"], p["volume_m3"], p["flow_ls"]])
            features.append(f)
        pr.addFeatures(features)

        symbol = QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "220,0,0,200",
            "outline_color": "140,0,0", "size": "5",
        })
        layer.setRenderer(QgsSingleSymbolRenderer(symbol))

        label_settings = QgsPalLayerSettings()
        label_settings.fieldName = "label"
        label_settings.enabled = True
        try:
            label_settings.placement = Qgis.LabelPlacement.OverPoint
        except Exception:
            pass
        text_format = QgsTextFormat()
        text_format.setColor(QColor(180, 0, 0))
        label_settings.setFormat(text_format)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
        layer.setLabelsEnabled(True)

        QgsProject.instance().addMapLayer(layer)

    # ---------------------------------------------------------------- before/after toggle

    def _toggle_before_after(self, checked):
        """checked=True → show baseline. checked=False → show earthworks."""
        self._showing_baseline = checked
        self.panel.btn_toggle_before_after.setText(
            "Show: Baseline" if checked else "Show: With Earthworks"
        )
        for lid in self._baseline_layer_ids:
            node = QgsProject.instance().layerTreeRoot().findLayer(lid)
            if node:
                node.setItemVisibilityChecked(checked)
        for lid in self._earthworks_layer_ids:
            node = QgsProject.instance().layerTreeRoot().findLayer(lid)
            if node:
                node.setItemVisibilityChecked(not checked)
        if self._earthwork_vector_layer:
            node = QgsProject.instance().layerTreeRoot().findLayer(self._earthwork_vector_layer.id())
            if node:
                node.setItemVisibilityChecked(not checked)

    # ---------------------------------------------------------------- ponding query

    def _activate_ponding_query(self):
        if not self._ponding_raster_path:
            return
        tool = PondingQueryTool(self.iface.mapCanvas(), self._ponding_raster_path)
        tool.ponding_selected.connect(self._on_ponding_selected)
        tool.no_ponding.connect(lambda: self.panel.lbl_ponding_result.setText(
            "No ponding at that location — click on a blue zone."
        ))
        self.iface.mapCanvas().setMapTool(tool)
        self.panel.lbl_status.setText("Click on a ponding zone... Esc to cancel.")

    def _on_ponding_selected(self, volume_m3, volume_l, cell_count, area_m2, geometry):
        avg_depth_m = volume_m3 / area_m2 if area_m2 > 0 else 0
        self.panel.lbl_ponding_result.setText(
            f"Selected ponding area:\n"
            f"  Surface area: {area_m2:,.1f} m²  ({area_m2/10000:.3f} ha)\n"
            f"  Avg depth:    {avg_depth_m*100:.1f} cm\n"
            f"  Volume:       {volume_m3:,.2f} m³\n"
            f"               ({volume_l:,.0f} L)"
        )
        self.panel.lbl_status.setText("Ponding area selected. Click again to query another zone.")

    # ---------------------------------------------------------------- contours

    def _generate_contours(self):
        if not self._dem_path:
            return
        interval, ok = QInputDialog.getDouble(
            self.panel, "Contour Interval",
            "Contour interval (metres):", value=1.0, min=0.1, max=100.0, decimals=1
        )
        if not ok:
            return
        try:
            import processing
            result = processing.run("gdal:contour", {
                "INPUT": self._dem_path,
                "BAND": 1,
                "INTERVAL": interval,
                "FIELD_NAME": "ELEV",
                "OUTPUT": "TEMPORARY_OUTPUT",
            })
            contour_layer = result["OUTPUT"]
            if isinstance(contour_layer, str):
                contour_layer = QgsVectorLayer(contour_layer, f"Contours ({interval}m)", "ogr")
            else:
                contour_layer.setName(f"Contours ({interval}m)")
            QgsProject.instance().addMapLayer(contour_layer)
            self._contour_layer = contour_layer
            self.panel.lbl_status.setText(f"Contours generated at {interval}m interval.")
            # Enable contour analysis if baseline analysis has already been run
            if self._acc_tif_path:
                self.panel.btn_analyse_contour_flow.setEnabled(True)
            self.panel.btn_contour_swale.setEnabled(True)
        except Exception as e:
            QMessageBox.critical(self.panel, "Contour Error", str(e))

    # ---------------------------------------------------------------- optimal swale contour finder

    def _find_optimal_swale_contours(self):
        """
        Scan DEM + flow accumulation to find the N elevations where a swale would
        intercept the most water, generate contour lines at those exact elevations,
        and set them as the active contour layer for the Contour Swale tool.
        """
        if not self._acc_tif_path or not self._dem_path:
            QMessageBox.warning(self.panel, "No Analysis", "Run baseline analysis first.")
            return

        import rasterio
        import numpy as np

        self.panel.lbl_status.setText("Finding optimal swale elevations…")
        n_top = self.panel.get_optimal_contour_count()

        with rasterio.open(self._dem_path) as dem_src:
            dem_array = dem_src.read(1).astype("float32")
            nodata = dem_src.nodata

        with rasterio.open(self._acc_tif_path) as acc_src:
            acc_array = acc_src.read(1).astype("float32")

        # Valid, non-stream cells only.
        # Stream cells (very high accumulation) are valley bottoms — not suitable for swales.
        # Cap at 10× stream threshold so we still see tributary collection points.
        stream_cap = self._last_stream_threshold * 10
        valid = np.ones(dem_array.shape, dtype=bool)
        if nodata is not None:
            valid &= dem_array != nodata
        valid &= acc_array <= stream_cap
        valid &= acc_array > 0      # must have some upstream area

        elevs = dem_array[valid]
        accs  = acc_array[valid]

        if len(elevs) == 0:
            QMessageBox.warning(self.panel, "No Data",
                                "No suitable hillslope cells found in the DEM.")
            return

        # Bin elevations at ~0.1 m resolution (capped at 500 bins for large DEMs)
        elev_min, elev_max = float(elevs.min()), float(elevs.max())
        elev_range = elev_max - elev_min
        if elev_range < 0.2:
            QMessageBox.information(self.panel, "Flat Terrain",
                                    "Elevation range is too small to place multiple swales.")
            return

        n_bins = min(500, max(50, int(elev_range / 0.1)))
        bins = np.linspace(elev_min, elev_max, n_bins + 1)

        candidates = []
        for i in range(n_bins):
            lo, hi = bins[i], bins[i + 1]
            mask = (elevs >= lo) & (elevs < hi)
            if not mask.any():
                continue
            peak_acc = int(accs[mask].max())
            cell_area = self._last_cell_area_m2 or 1.0
            runoff_m  = (self._last_runoff_mm or 0) / 1000.0
            candidates.append({
                "elevation":    round((lo + hi) / 2, 2),
                "peak_acc":     peak_acc,
                "peak_vol_m3":  round(peak_acc * cell_area * runoff_m, 1),
            })

        candidates.sort(key=lambda r: r["peak_acc"], reverse=True)

        # Pick top N ensuring a minimum vertical spacing (5 % of elevation range,
        # at least 0.5 m) so swales are spread across the slope, not clustered.
        min_spacing = max(0.5, elev_range * 0.05)
        optimal = []
        for c in candidates:
            if all(abs(c["elevation"] - k["elevation"]) >= min_spacing for k in optimal):
                optimal.append(c)
            if len(optimal) >= n_top:
                break

        if not optimal:
            QMessageBox.information(self.panel, "No Candidates",
                                    "Could not find distinct optimal swale elevations.")
            return

        # Generate one contour per optimal elevation and merge into a single layer.
        # We avoid relying on GDAL's -fl flag (unreliable via QGIS EXTRA parameter)
        # by running gdal:contour once per elevation using OFFSET so that exactly
        # one contour is produced per run, then collecting features into a memory layer.
        self.panel.lbl_status.setText(
            f"Generating contours at {len(optimal)} optimal elevations…"
        )

        contour_layer = QgsVectorLayer("LineString", "Optimal Swale Contours", "memory")
        contour_layer.setCrs(QgsProject.instance().crs())
        pr = contour_layer.dataProvider()
        pr.addAttributes([QgsField("ELEV", QVariant.Double)])
        contour_layer.updateFields()

        try:
            import processing as qgis_processing

            # Binary-raster trick: for each target elevation write a 0/1 raster
            # (1 = DEM >= elev, 0 = below), then run gdal:contour at level 0.5.
            # The boundary between 0 and 1 is exactly the contour at `elev`.
            # This avoids relying on GDAL's OFFSET/INTERVAL behaviour which varies
            # across QGIS/GDAL versions and frequently produces no features.
            with rasterio.open(self._dem_path) as _src:
                _dem_arr  = _src.read(1).astype("float32")
                _dem_nd   = _src.nodata
                _profile  = _src.profile.copy()
            _profile.update(dtype="float32", count=1, nodata=-9999.0)

            for i, o in enumerate(optimal):
                elev = o["elevation"]

                binary = np.where(_dem_arr >= elev, 1.0, 0.0).astype("float32")
                if _dem_nd is not None:
                    binary[_dem_arr == _dem_nd] = -9999.0

                binary_path = os.path.join(self.output_dir, f"_opt_contour_{i}.tif")
                with rasterio.open(binary_path, "w", **_profile) as dst:
                    dst.write(binary, 1)

                result = qgis_processing.run("gdal:contour", {
                    "INPUT":      binary_path,
                    "BAND":       1,
                    "INTERVAL":   1.0,
                    "OFFSET":     0.5,
                    "FIELD_NAME": "ELEV",
                    "OUTPUT":     "TEMPORARY_OUTPUT",
                })
                tmp = result["OUTPUT"]
                if isinstance(tmp, str):
                    tmp = QgsVectorLayer(tmp, "", "ogr")
                if tmp and tmp.isValid():
                    feats = []
                    for f in tmp.getFeatures():
                        nf = QgsFeature()
                        nf.setGeometry(f.geometry())
                        nf.setAttributes([elev])
                        feats.append(nf)
                    pr.addFeatures(feats)
        except Exception as e:
            QMessageBox.critical(self.panel, "Contour Generation Error", str(e))
            return

        # Clip contours at exclusion zone boundaries (if any zones are defined)
        excl_union = self._get_exclusion_union()
        if excl_union and not excl_union.isEmpty():
            self._apply_exclusion_to_contour_layer(contour_layer, excl_union)

        contour_layer.updateExtents()
        if contour_layer.featureCount() == 0:
            QMessageBox.warning(self.panel, "No Contours Generated",
                                "Could not generate contours at the optimal elevations.\n"
                                "Check that the DEM is valid and try running the baseline analysis again.")
            return

        # Remove any previous optimal contour layer
        for lyr in QgsProject.instance().mapLayersByName("Optimal Swale Contours"):
            QgsProject.instance().removeMapLayer(lyr)

        # Style: graduated blue, labelled with elevation + estimated inflow
        # Build a lookup: elevation → peak_vol_m3 for label enrichment
        vol_by_elev = {o["elevation"]: o["peak_vol_m3"] for o in optimal}

        max_acc = max(o["peak_acc"] for o in optimal)
        ranges = []
        for i, o in enumerate(sorted(optimal, key=lambda x: x["peak_acc"])):
            frac = o["peak_acc"] / max(max_acc, 1)
            blue_val = int(255 * (1 - frac * 0.85))
            colour = QColor(0, int(80 + frac * 140), blue_val)
            width  = 0.6 + frac * 2.0
            sym = QgsLineSymbol.createSimple({
                "color": f"{colour.red()},{colour.green()},{colour.blue()}",
                "width": str(round(width, 2)),
            })
            ranges.append(QgsRendererRange(
                o["elevation"] - 0.01, o["elevation"] + 0.01,
                sym,
                f"{o['elevation']:.2f} m  ({o['peak_vol_m3']:,.0f} m³)",
            ))
        contour_layer.setRenderer(QgsGraduatedSymbolRenderer("ELEV", ranges))

        lbl = QgsPalLayerSettings()
        lbl.fieldName = "ELEV"
        lbl.enabled = True
        tf = QgsTextFormat()
        tf.setColor(QColor(0, 40, 120))
        lbl.setFormat(tf)
        contour_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl))
        contour_layer.setLabelsEnabled(True)
        contour_layer.updateExtents()
        QgsProject.instance().addMapLayer(contour_layer)

        # Make these the active contour layer so Contour Swale tool uses them
        self._contour_layer = contour_layer
        self.panel.btn_contour_swale.setEnabled(True)
        self.panel.btn_analyse_contour_flow.setEnabled(True)

        # Also run the flow analysis on these contours immediately
        self._contour_flow_results = [
            {
                "elevation":      o["elevation"],
                "peak_acc":       o["peak_acc"],
                "peak_volume_m3": o["peak_vol_m3"],
                "peak_x":         None,
                "peak_y":         None,
                "geometry":       None,
            }
            for o in optimal
        ]

        # Summary in panel
        lines = "\n".join(
            f"  #{i+1}  {o['elevation']:.2f} m  —  {o['peak_vol_m3']:,.0f} m³ peak inflow"
            for i, o in enumerate(optimal)
        )
        self.panel.lbl_contour_flow_result.setText(
            f"Optimal swale contours ({len(optimal)}):\n{lines}\n"
            f"Use 'Contour Swale' to place swales on these lines."
        )
        self.panel.lbl_status.setText(
            f"Generated {len(optimal)} optimal swale contours."
        )

    # ---------------------------------------------------------------- contour flow analysis

    def _analyse_contour_flow(self):
        """
        Sample flow accumulation along every contour, rank them by peak flow,
        and display a graduated contour layer + best-candidate markers.
        """
        if not self._contour_layer:
            QMessageBox.warning(self.panel, "No Contours",
                                "Generate contours first using 'Generate Contours'.")
            return
        if not self._acc_tif_path:
            QMessageBox.warning(self.panel, "No Analysis",
                                "Run baseline analysis first.")
            return

        import rasterio
        import json
        from shapely.geometry import shape as shapely_shape

        self.panel.lbl_status.setText("Analysing contour flow…")

        with rasterio.open(self._acc_tif_path) as src:
            acc_array = src.read(1)
            transform = src.transform
            cell_w = abs(transform.a)

        runoff_m = (self._last_runoff_mm or 0) / 1000.0
        cell_area_m2 = self._last_cell_area_m2 or (cell_w ** 2)

        results = []
        for feature in self._contour_layer.getFeatures():
            geom = feature.geometry()
            if geom is None or geom.isEmpty():
                continue
            try:
                shapely_geom = shapely_shape(json.loads(geom.asJson()))
            except Exception:
                continue

            n_samples = max(20, int(shapely_geom.length / cell_w))
            peak_acc = 0
            peak_pt = None
            for i in range(n_samples + 1):
                pt = shapely_geom.interpolate(i / n_samples, normalized=True)
                col = int((pt.x - transform.c) / transform.a)
                row = int((pt.y - transform.f) / transform.e)
                row = max(0, min(acc_array.shape[0] - 1, row))
                col = max(0, min(acc_array.shape[1] - 1, col))
                val = int(acc_array[row, col])
                if val > peak_acc:
                    peak_acc = val
                    peak_pt = (pt.x, pt.y)

            elev = 0.0
            for fname in ("ELEV", "elev", "elevation", "Elevation"):
                if fname in feature.fields().names():
                    try:
                        elev = float(feature[fname])
                    except (ValueError, TypeError):
                        pass
                    break

            results.append({
                "id": feature.id(),
                "elevation": elev,
                "peak_acc": peak_acc,
                "peak_volume_m3": round(peak_acc * cell_area_m2 * runoff_m, 1),
                "peak_x": peak_pt[0] if peak_pt else None,
                "peak_y": peak_pt[1] if peak_pt else None,
                "geometry": geom,
            })

        results.sort(key=lambda r: r["peak_acc"], reverse=True)
        self._contour_flow_results = results

        if not results:
            self.panel.lbl_status.setText("No contour features found.")
            return

        self._display_contour_flow(results)
        top = results[:3]
        lines = "\n".join(
            f"  #{i+1}  Elev {r['elevation']:.1f} m  —  "
            f"{r['peak_volume_m3']:,.0f} m³ peak inflow"
            for i, r in enumerate(top)
        )
        self.panel.lbl_contour_flow_result.setText(
            f"Best swale contours (by peak flow):\n{lines}"
        )
        self.panel.lbl_status.setText(
            f"Contour flow analysed — {len(results)} contours ranked."
        )

    def _display_contour_flow(self, results):
        """Graduated vector contour layer coloured by peak flow accumulation."""
        for lyr in QgsProject.instance().mapLayersByName("Contour Flow Intensity"):
            QgsProject.instance().removeMapLayer(lyr)

        layer = QgsVectorLayer("LineString", "Contour Flow Intensity", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("id",              QVariant.Int),
            QgsField("elevation",       QVariant.Double),
            QgsField("peak_acc",        QVariant.Int),
            QgsField("peak_volume_m3",  QVariant.Double),
        ])
        layer.updateFields()

        features = []
        for r in results:
            f = QgsFeature()
            f.setGeometry(r["geometry"])
            f.setAttributes([r["id"], r["elevation"], r["peak_acc"], r["peak_volume_m3"]])
            features.append(f)
        pr.addFeatures(features)

        # Graduated renderer: 5 classes from light (low) to dark (high) blue
        max_acc = max(r["peak_acc"] for r in results) if results else 1
        boundaries = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
        colours = [
            QColor(200, 230, 255),
            QColor(120, 180, 255),
            QColor(50,  120, 220),
            QColor(20,  60,  180),
            QColor(0,   20,  100),
        ]
        widths = ["0.5", "0.8", "1.2", "1.8", "2.5"]
        ranges = []
        for i in range(5):
            lo = boundaries[i] * max_acc
            hi = boundaries[i + 1] * max_acc
            sym = QgsLineSymbol.createSimple({
                "color": f"{colours[i].red()},{colours[i].green()},{colours[i].blue()}",
                "width": widths[i],
            })
            ranges.append(QgsRendererRange(lo, hi, sym, f"{lo:.0f}–{hi:.0f}"))
        layer.setRenderer(QgsGraduatedSymbolRenderer("peak_acc", ranges))

        # Label with elevation
        lbl = QgsPalLayerSettings()
        lbl.fieldName = "elevation"
        lbl.enabled = True
        tf = QgsTextFormat()
        tf.setColor(QColor(0, 40, 120))
        lbl.setFormat(tf)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl))
        layer.setLabelsEnabled(True)
        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer)

        # Mark the top 5 peak inflow points as stars
        self._display_contour_peak_points(results[:5])

    def _display_contour_peak_points(self, results):
        for lyr in QgsProject.instance().mapLayersByName("Best Swale Locations"):
            QgsProject.instance().removeMapLayer(lyr)

        layer = QgsVectorLayer("Point", "Best Swale Locations", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("rank",            QVariant.Int),
            QgsField("elevation",       QVariant.Double),
            QgsField("peak_volume_m3",  QVariant.Double),
            QgsField("label",           QVariant.String),
        ])
        layer.updateFields()

        features = []
        for i, r in enumerate(results):
            if r["peak_x"] is None:
                continue
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(r["peak_x"], r["peak_y"])))
            lbl = f"#{i+1}  {r['elevation']:.1f} m  {r['peak_volume_m3']:,.0f} m³"
            f.setAttributes([i + 1, r["elevation"], r["peak_volume_m3"], lbl])
            features.append(f)
        pr.addFeatures(features)

        sym = QgsMarkerSymbol.createSimple({
            "name": "star", "color": "0,120,220,220",
            "outline_color": "0,40,140", "size": "6",
        })
        layer.setRenderer(QgsSingleSymbolRenderer(sym))

        lbl_s = QgsPalLayerSettings()
        lbl_s.fieldName = "label"
        lbl_s.enabled = True
        tf = QgsTextFormat()
        tf.setColor(QColor(0, 40, 120))
        lbl_s.setFormat(tf)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_s))
        layer.setLabelsEnabled(True)
        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer)

    # ---------------------------------------------------------------- contour swale tool

    def _activate_contour_swale(self):
        if not self._contour_layer:
            QMessageBox.warning(self.panel, "No Contours",
                                "Generate contours first using 'Generate Contours'.")
            return
        tool = SelectContourTool(self.iface.mapCanvas(), self._contour_layer)
        tool.contour_selected.connect(self._on_contour_selected)
        tool.cancelled.connect(self._on_draw_cancelled)
        self.iface.mapCanvas().setMapTool(tool)
        self._current_tool = tool
        self.panel.lbl_status.setText(
            "Click a contour line to place a swale along it… Esc to cancel."
        )

    def _on_contour_selected(self, geom, elevation):
        """User clicked a contour — sample inflow, open properties dialog, create swale."""
        # Sample the flow accumulation raster along the contour to find peak inflow.
        # This is done before opening the dialog so the recommended-length field
        # is live and updates as the user adjusts depth / width.
        peak_inflow_m3 = self._sample_peak_inflow(geom)

        dlg = EarthworkPropertiesDialog(
            "swale", geom, parent=self.panel,
            peak_inflow_m3=peak_inflow_m3,
        )
        if dlg.exec_() != EarthworkPropertiesDialog.Accepted:
            return

        ew = Earthwork("swale", geom, dlg.get_name())
        ew.depth = dlg.get_depth()
        ew.width = dlg.get_width()
        ew.companion_berm = dlg.get_companion_berm()
        ew.capacity_m3, ew.capacity_l = calculate_capacity(
            "swale", geom, ew.depth, ew.width, ew.companion_berm
        )

        index = len(self._earthwork_manager)
        self._earthwork_manager.add(ew)
        self.panel.add_earthwork_to_list(index, ew.summary())
        self._add_earthwork_to_map(ew)
        self._delineate_and_display_catchment(geom, "swale", ew.name)

        msg = f"'{ew.name}' placed on contour (elev ≈ {elevation:.1f} m)."
        if peak_inflow_m3 and peak_inflow_m3 > 0:
            section = ew.depth * ew.width
            req_len = peak_inflow_m3 / section if section > 0 else 0
            msg += (
                f"\n  Peak storm inflow:    {peak_inflow_m3:,.0f} m³"
                f"\n  Minimum swale length: {req_len:.0f} m"
                f"  ({ew.depth:.2f} m × {ew.width:.2f} m section)"
            )
        max_slope = self._check_swale_slope(geom)
        if max_slope is not None:
            if max_slope > 15.0:
                msg += (
                    f"\n  ⚠ Slope {max_slope:.0f}° — too steep for swales. "
                    "Recommend berm or diversion drain instead."
                )
            elif max_slope > 8.0:
                msg += (
                    f"\n  ⚠ Slope {max_slope:.0f}° — consider a companion berm "
                    "on the downhill side for stability."
                )
        overlap = self._get_exclusion_overlap(geom)
        if overlap:
            msg += "\n  ⛔ Earthwork overlaps an exclusion zone — adjust placement."
            self._show_overlap_highlight(overlap)
        self.panel.lbl_status.setText(msg)

    def _sample_peak_inflow(self, geom):
        """
        Sample the flow accumulation raster along a geometry and return the
        estimated peak storm inflow volume (m³) at the highest-accumulation point.
        Returns None if analysis data is not available.
        """
        if not self._acc_tif_path or not self._last_cell_area_m2 or self._last_runoff_mm is None:
            return None
        import rasterio
        import json
        from shapely.geometry import shape as shapely_shape
        try:
            with rasterio.open(self._acc_tif_path) as src:
                acc_array = src.read(1)
                transform = src.transform
                cell_w = abs(transform.a)
            shapely_geom = shapely_shape(json.loads(geom.asJson()))
            n_samples = max(20, int(shapely_geom.length / max(cell_w, 0.01)))
            peak_acc = 0
            for i in range(n_samples + 1):
                pt = shapely_geom.interpolate(i / n_samples, normalized=True)
                col = int((pt.x - transform.c) / transform.a)
                row = int((pt.y - transform.f) / transform.e)
                row = max(0, min(acc_array.shape[0] - 1, row))
                col = max(0, min(acc_array.shape[1] - 1, col))
                peak_acc = max(peak_acc, int(acc_array[row, col]))
            runoff_m = self._last_runoff_mm / 1000.0
            return round(peak_acc * self._last_cell_area_m2 * runoff_m, 1)
        except Exception:
            return None

    # ---------------------------------------------------------------- colour ramps

    def _apply_stream_ramp(self, layer, threshold, stream_acc_max):
        """
        Stream network gradient using ecologically meaningful breakpoints:
          - Flow path:    > 1 ha contributing area  (minor drainage, trickle)
          - Stream:       > 5 ha contributing area  (defined channel, ~1-5 L/s)
          - Main channel: > 20 ha contributing area (significant stream, >5 L/s)

        Breakpoints are derived from the DEM cell size stored in _last_cell_area_m2
        so they are correct regardless of DEM resolution. Falls back to log-scale
        if cell size is unknown.
        """
        cell_m2 = self._last_cell_area_m2 or (1.0)

        # Cells equivalent to 1 ha, 5 ha, 20 ha
        flow_path_cells    = 10_000  / cell_m2   # 1 ha
        stream_cells       = 50_000  / cell_m2   # 5 ha
        main_channel_cells = 200_000 / cell_m2   # 20 ha

        # Don't let breakpoints exceed actual data maximum
        m = max(float(stream_acc_max), flow_path_cells * 1.1)

        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Interpolated)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem(0,                   QColor(255, 255, 255,   0), "No flow"),
            QgsColorRampShader.ColorRampItem(flow_path_cells,     QColor(180, 220, 255, 200), "Flow path  (>1 ha)"),
            QgsColorRampShader.ColorRampItem(stream_cells,        QColor(30,  130, 220, 230), "Stream  (>5 ha)"),
            QgsColorRampShader.ColorRampItem(main_channel_cells,  QColor(0,   40,  140, 245), "Main channel  (>20 ha)"),
            QgsColorRampShader.ColorRampItem(m,                   QColor(0,   10,   80, 255), "River"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    def _apply_accumulation_ramp(self, layer):
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Interpolated)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem(0,     QColor(255, 255, 255), "0"),
            QgsColorRampShader.ColorRampItem(500,   QColor(180, 220, 255), "500"),
            QgsColorRampShader.ColorRampItem(5000,  QColor(30, 120, 255),  "5,000"),
            QgsColorRampShader.ColorRampItem(50000, QColor(0, 0, 180),     "50,000+"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    def _apply_runoff_ramp(self, layer, scale_max):
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Interpolated)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem(0,               QColor(255, 255, 255), "0 m³"),
            QgsColorRampShader.ColorRampItem(scale_max * 0.1, QColor(255, 255, 0),   f"{scale_max*0.1:,.0f} m³"),
            QgsColorRampShader.ColorRampItem(scale_max * 0.5, QColor(255, 140, 0),   f"{scale_max*0.5:,.0f} m³"),
            QgsColorRampShader.ColorRampItem(scale_max,       QColor(180, 0, 0),     f"{scale_max:,.0f} m³"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    def _apply_ponding_ramp(self, layer):
        """Light to dark blue — depth of ponded water in metres."""
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Interpolated)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem(0,    QColor(255, 255, 255, 0),   "0 m"),
            QgsColorRampShader.ColorRampItem(0.05, QColor(180, 220, 255, 180), "0.05 m"),
            QgsColorRampShader.ColorRampItem(0.5,  QColor(30, 120, 220, 220),  "0.5 m"),
            QgsColorRampShader.ColorRampItem(2.0,  QColor(0, 30, 140, 255),    "2.0 m"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    # ---------------------------------------------------------------- layer toggles

    def _toggle_streams_layer(self, checked):
        if hasattr(self, "_stream_layer_id"):
            node = QgsProject.instance().layerTreeRoot().findLayer(self._stream_layer_id)
            if node:
                node.setItemVisibilityChecked(checked)

    def _toggle_accumulation_layer(self, checked):
        if hasattr(self, "_acc_layer_id"):
            node = QgsProject.instance().layerTreeRoot().findLayer(self._acc_layer_id)
            if node:
                node.setItemVisibilityChecked(checked)

    def _toggle_slope_arrows(self, checked):
        if checked:
            # Generate layer on first use; just show it on subsequent toggles
            existing = (self._slope_arrow_layer_id and
                        QgsProject.instance().mapLayer(self._slope_arrow_layer_id))
            if existing:
                node = QgsProject.instance().layerTreeRoot().findLayer(self._slope_arrow_layer_id)
                if node:
                    node.setItemVisibilityChecked(True)
            else:
                self._generate_slope_arrows()
        else:
            if self._slope_arrow_layer_id:
                node = QgsProject.instance().layerTreeRoot().findLayer(self._slope_arrow_layer_id)
                if node:
                    node.setItemVisibilityChecked(False)

    def _toggle_slope_class_layer(self, checked):
        if self._slope_class_layer_id:
            node = QgsProject.instance().layerTreeRoot().findLayer(self._slope_class_layer_id)
            if node:
                node.setItemVisibilityChecked(checked)
        self.panel.btn_toggle_slope_class.setText(
            "Hide Slope Classification" if checked else "Show Slope Classification"
        )

    def _generate_slope_arrows(self):
        if not self._dem_path:
            return
        try:
            import processing
            import rasterio
            import numpy as np

            self.panel.lbl_status.setText("Generating slope direction arrows...")

            # Compute aspect (0–360, clockwise from North, direction water flows downslope)
            result = processing.run("gdal:aspect", {
                "INPUT": self._dem_path,
                "BAND": 1,
                "TRIG_ANGLE": False,
                "ZERO_FOR_FLAT": True,
                "COMPUTE_EDGES": True,
                "ZEVENBERGEN": False,
                "OUTPUT": "TEMPORARY_OUTPUT",
            })
            aspect_path = result["OUTPUT"]
            if hasattr(aspect_path, "source"):
                aspect_path = aspect_path.source()

            with rasterio.open(self._dem_path) as src:
                cell_size = abs(src.transform.a)
                transform = src.transform

            with rasterio.open(aspect_path) as src:
                aspect = src.read(1).astype("float32")
                rows, cols = aspect.shape

            # One arrow per ~50 m on the ground
            step = max(1, int(50.0 / cell_size))

            layer = QgsVectorLayer("Point", "Slope Direction", "memory")
            layer.setCrs(QgsProject.instance().crs())
            pr = layer.dataProvider()
            pr.addAttributes([QgsField("angle", QVariant.Double)])
            layer.updateFields()

            features = []
            for r in range(0, rows, step):
                for c in range(0, cols, step):
                    val = float(aspect[r, c])
                    if val < 0 or val > 360:   # nodata or flat (-9999 / 361)
                        continue
                    x = transform.c + c * transform.a + cell_size / 2
                    y = transform.f + r * transform.e + cell_size / 2
                    f = QgsFeature()
                    f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                    f.setAttributes([val])
                    features.append(f)

            pr.addFeatures(features)
            layer.updateExtents()

            # Rotated arrowhead — angle field drives rotation (0 = North, clockwise)
            symbol = QgsMarkerSymbol.createSimple({
                "name": "arrow",
                "color": "60,60,200,200",
                "outline_color": "20,20,120,200",
                "size": "5",
                "angle": "0",
            })
            symbol.symbolLayer(0).setDataDefinedProperty(
                QgsSymbolLayer.PropertyAngle,
                QgsProperty.fromField("angle")
            )
            layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            QgsProject.instance().addMapLayer(layer)
            self._slope_arrow_layer_id = layer.id()
            self.panel.lbl_status.setText("Slope direction arrows generated.")

        except Exception as e:
            import traceback
            QMessageBox.critical(self.panel, "Slope Arrow Error", traceback.format_exc())
            self.panel.btn_toggle_slope_arrows.setChecked(False)

    # ---------------------------------------------------------------- slope classification

    def _calculate_slope_layer(self):
        """
        Run gdal:slope on the DEM and create a semi-transparent discrete ramp layer
        showing earthwork suitability zones: 0-3° green, 3-8° yellow, 8-15° orange, >15° red.
        Called automatically when a DEM is loaded.
        """
        if not self._dem_path:
            return
        try:
            import processing
            self.panel.lbl_status.setText("Calculating slope classification...")

            slope_out = os.path.join(self.output_dir, "slope_degrees.tif")
            result = processing.run("gdal:slope", {
                "INPUT": self._dem_path,
                "BAND": 1,
                "SCALE": 1.0,
                "AS_PERCENT": False,
                "COMPUTE_EDGES": True,
                "ZEVENBERGEN": False,
                "OUTPUT": slope_out,
            })
            slope_path = result["OUTPUT"]
            if hasattr(slope_path, "source"):
                slope_path = slope_path.source()
            self._slope_raster_path = slope_path

            # Remove previous slope class layer if present
            if self._slope_class_layer_id:
                old = QgsProject.instance().mapLayer(self._slope_class_layer_id)
                if old:
                    QgsProject.instance().removeMapLayer(old)
                self._slope_class_layer_id = None

            slope_layer = QgsRasterLayer(slope_path, "Slope Classification")
            if slope_layer.isValid():
                self._apply_slope_class_ramp(slope_layer)
                QgsProject.instance().addMapLayer(slope_layer)
                self._slope_class_layer_id = slope_layer.id()
                # Hidden by default — user enables via toggle
                node = QgsProject.instance().layerTreeRoot().findLayer(self._slope_class_layer_id)
                if node:
                    node.setItemVisibilityChecked(False)
                self.panel.btn_toggle_slope_class.setEnabled(True)

            self.panel.lbl_status.setText("Ready to run analysis.")

        except Exception:
            import traceback
            QgsMessageLog.logMessage(
                f"Slope layer error:\n{traceback.format_exc()}", "TerrainFlow", Qgis.Warning
            )
            self.panel.lbl_status.setText("Ready to run analysis.")

    def _apply_slope_class_ramp(self, layer):
        """Discrete colour ramp: green / yellow / orange / red by slope angle (degrees)."""
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Discrete)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem( 3.0, QColor( 80, 200,  80, 160), "0–3°   suitable"),
            QgsColorRampShader.ColorRampItem( 8.0, QColor(220, 220,  30, 160), "3–8°   moderate"),
            QgsColorRampShader.ColorRampItem(15.0, QColor(255, 140,   0, 160), "8–15°  challenging"),
            QgsColorRampShader.ColorRampItem(90.0, QColor(220,  30,  30, 160), ">15°   steep"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    def _check_swale_slope(self, geometry):
        """
        Sample the slope raster along a geometry and return the maximum slope in degrees.
        Returns None if the slope raster is not available.
        """
        if not self._slope_raster_path:
            return None
        try:
            import rasterio
            import json
            from shapely.geometry import shape as shapely_shape

            with rasterio.open(self._slope_raster_path) as src:
                slope_array = src.read(1).astype("float32")
                transform = src.transform
                cell_w = abs(transform.a)

            shapely_geom = shapely_shape(json.loads(geometry.asJson()))
            n_samples = max(20, int(shapely_geom.length / max(cell_w, 0.01)))
            max_slope = 0.0
            for i in range(n_samples + 1):
                pt = shapely_geom.interpolate(i / n_samples, normalized=True)
                col = int((pt.x - transform.c) / transform.a)
                row = int((pt.y - transform.f) / transform.e)
                row = max(0, min(slope_array.shape[0] - 1, row))
                col = max(0, min(slope_array.shape[1] - 1, col))
                val = float(slope_array[row, col])
                if 0.0 <= val <= 90.0:
                    max_slope = max(max_slope, val)
            return max_slope
        except Exception:
            return None

    # ---------------------------------------------------------------- exclusion zones

    def _ensure_exclusion_zone_layer(self):
        """Create the Exclusion Zones memory layer if it doesn't already exist."""
        if (self._exclusion_zone_layer and
                QgsProject.instance().mapLayer(self._exclusion_zone_layer.id())):
            return
        layer = QgsVectorLayer("Polygon", "Exclusion Zones", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([QgsField("id", QVariant.Int)])
        layer.updateFields()
        symbol = QgsFillSymbol.createSimple({
            "color":         "220,0,0,50",
            "outline_color": "220,0,0,220",
            "outline_width": "0.8",
            "outline_style": "dash",
        })
        layer.setRenderer(QgsSingleSymbolRenderer(symbol))
        QgsProject.instance().addMapLayer(layer)
        self._exclusion_zone_layer = layer

    def _activate_draw_exclusion_zone(self):
        tool = DrawPolygonTool(self.iface.mapCanvas())
        tool.polygon_drawn.connect(self._on_exclusion_zone_drawn)
        tool.cancelled.connect(self._on_draw_cancelled)
        self.iface.mapCanvas().setMapTool(tool)
        self._current_tool = tool
        self.panel.lbl_status.setText(
            "Draw exclusion zone — click to add vertices, double-click to finish, Esc to cancel."
        )

    def _on_exclusion_zone_drawn(self, geom):
        self._ensure_exclusion_zone_layer()
        n = self._exclusion_zone_layer.featureCount() + 1
        f = QgsFeature()
        f.setGeometry(geom)
        f.setAttributes([n])
        self._exclusion_zone_layer.dataProvider().addFeatures([f])
        self._exclusion_zone_layer.updateExtents()
        self._exclusion_zone_layer.triggerRepaint()
        self.panel.btn_clear_exclusion_zones.setEnabled(True)
        self.panel.btn_toggle_exclusion_zones.setEnabled(True)
        self.panel.btn_toggle_exclusion_zones.setChecked(True)
        self.panel.lbl_status.setText(
            f"Exclusion zone {n} added. Draw another or continue with analysis."
        )

    def _clear_exclusion_zones(self):
        if self._exclusion_zone_layer:
            self._exclusion_zone_layer.dataProvider().truncate()
            self._exclusion_zone_layer.triggerRepaint()
        self.panel.btn_clear_exclusion_zones.setEnabled(False)
        self.panel.lbl_status.setText("Exclusion zones cleared.")

    def _toggle_exclusion_zones(self, checked):
        if self._exclusion_zone_layer:
            node = QgsProject.instance().layerTreeRoot().findLayer(
                self._exclusion_zone_layer.id()
            )
            if node:
                node.setItemVisibilityChecked(checked)
        self.panel.btn_toggle_exclusion_zones.setText(
            "Hide Zones" if checked else "Show Zones"
        )

    def _get_exclusion_union(self):
        """Return the union of all exclusion zone geometries, or None if none exist."""
        if not self._exclusion_zone_layer or self._exclusion_zone_layer.featureCount() == 0:
            return None
        geoms = [f.geometry() for f in self._exclusion_zone_layer.getFeatures()
                 if f.geometry() and not f.geometry().isEmpty()]
        if not geoms:
            return None
        if len(geoms) == 1:
            return geoms[0]
        return QgsGeometry.unaryUnion(geoms)

    def _get_exclusion_overlap(self, geometry):
        """
        Return the intersection of geometry with the exclusion zones union,
        or None if there is no overlap.
        """
        excl_union = self._get_exclusion_union()
        if not excl_union or excl_union.isEmpty():
            return None
        intersection = geometry.intersection(excl_union)
        if intersection and not intersection.isEmpty():
            return intersection
        return None

    def _show_overlap_highlight(self, overlap_geom):
        """
        Add a bold red layer showing the section of a swale that overlaps
        an exclusion zone. Replaces any previous overlap highlight.
        """
        if (self._overlap_highlight_layer and
                QgsProject.instance().mapLayer(self._overlap_highlight_layer.id())):
            QgsProject.instance().removeMapLayer(self._overlap_highlight_layer)
            self._overlap_highlight_layer = None

        layer = QgsVectorLayer("LineString", "⚠ Swale in Exclusion Zone", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([QgsField("note", QVariant.String)])
        layer.updateFields()

        f = QgsFeature()
        f.setGeometry(overlap_geom)
        f.setAttributes(["Overlaps exclusion zone"])
        pr.addFeatures([f])

        sym = QgsLineSymbol.createSimple({
            "color": "220,0,0,255",
            "width": "2.5",
        })
        layer.setRenderer(QgsSingleSymbolRenderer(sym))
        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer)
        self._overlap_highlight_layer = layer

    def _apply_exclusion_to_contour_layer(self, layer, excl_union):
        """
        Split features in `layer` at exclusion zone boundaries.

        Active segments (outside exclusion zones) replace the original features.
        Excluded segments (inside exclusion zones) are added to a new grey-dashed
        layer so the user can still see where the contour runs.
        """
        orig_features = list(layer.getFeatures())
        pr = layer.dataProvider()
        pr.deleteFeatures([f.id() for f in orig_features])

        active_feats  = []
        excluded_feats = []

        for f in orig_features:
            geom = f.geometry()
            elev = f["ELEV"]

            active_geom = geom.difference(excl_union)
            if active_geom and not active_geom.isEmpty():
                nf = QgsFeature()
                nf.setGeometry(active_geom)
                nf.setAttributes([elev])
                active_feats.append(nf)

            excl_geom = geom.intersection(excl_union)
            if excl_geom and not excl_geom.isEmpty():
                nf = QgsFeature()
                nf.setGeometry(excl_geom)
                nf.setAttributes([elev])
                excluded_feats.append(nf)

        pr.addFeatures(active_feats)
        layer.updateExtents()

        if excluded_feats:
            excl_layer = QgsVectorLayer("LineString", "Excluded Contour Segments", "memory")
            excl_layer.setCrs(layer.crs())
            ex_pr = excl_layer.dataProvider()
            ex_pr.addAttributes([QgsField("ELEV", QVariant.Double)])
            excl_layer.updateFields()
            ex_pr.addFeatures(excluded_feats)
            excl_layer.updateExtents()
            sym = QgsLineSymbol.createSimple({
                "color":      "150,150,150,160",
                "width":      "0.5",
                "line_style": "dash",
            })
            excl_layer.setRenderer(QgsSingleSymbolRenderer(sym))
            for lyr in QgsProject.instance().mapLayersByName("Excluded Contour Segments"):
                QgsProject.instance().removeMapLayer(lyr)
            QgsProject.instance().addMapLayer(excl_layer)

    # ---------------------------------------------------------------- earthwork catchment

    def _delineate_and_display_catchment(self, geometry, ew_type, ew_name):
        """
        Delineate the catchment feeding into an earthwork and display it as a
        labelled polygon layer. Runs only when baseline analysis data is available.
        Silently skips if fdir/acc rasters are not yet computed.
        """
        if not self._fdir_tif_path or not self._acc_tif_path:
            return

        self.panel.lbl_status.setText(f"Delineating catchment for '{ew_name}'…")

        try:
            import rasterio
            import numpy as np
            import json
            from shapely.geometry import shape as shapely_shape
            from shapely.ops import unary_union
            from rasterio.features import shapes as rasterio_shapes
            from pysheds.grid import Grid

            with rasterio.open(self._acc_tif_path) as acc_src:
                acc_array = acc_src.read(1)
                transform = acc_src.transform
                cell_w    = abs(transform.a)

            # ---- find best pour point (highest accumulation along the geometry) ----
            if ew_type == "basin":
                centroid = geometry.centroid().asPoint()
                pour_x, pour_y = centroid.x(), centroid.y()
            else:
                shapely_geom = shapely_shape(json.loads(geometry.asJson()))
                n_samples = max(20, int(shapely_geom.length / max(cell_w, 0.01)))
                peak_acc  = 0
                pour_x, pour_y = None, None
                for i in range(n_samples + 1):
                    pt  = shapely_geom.interpolate(i / n_samples, normalized=True)
                    col = int((pt.x - transform.c) / transform.a)
                    row = int((pt.y - transform.f) / transform.e)
                    row = max(0, min(acc_array.shape[0] - 1, row))
                    col = max(0, min(acc_array.shape[1] - 1, col))
                    val = int(acc_array[row, col])
                    if val > peak_acc:
                        peak_acc = val
                        pour_x, pour_y = pt.x, pt.y
                if pour_x is None:
                    return

            # ---- delineate catchment using saved flow direction raster ----
            grid = Grid.from_raster(self._fdir_tif_path)
            fdir = grid.read_raster(self._fdir_tif_path)
            catch_mask = grid.catchment(
                x=pour_x, y=pour_y, fdir=fdir, xytype="coordinate"
            )
            catch_bool = np.array(catch_mask).astype(bool)

            if not catch_bool.any():
                return

            # ---- vectorise mask to polygon ----
            local_uint8 = np.where(catch_bool, 1, 0).astype("uint8")
            polys = [
                shapely_shape(geom)
                for geom, val in rasterio_shapes(local_uint8, transform=grid.transform)
                if val == 1
            ]
            if not polys:
                return

            catchment_poly = unary_union(polys)
            area_m2 = catchment_poly.area
            area_ha = area_m2 / 10000

            # ---- average slope over the catchment ----
            avg_slope = None
            if self._slope_raster_path:
                with rasterio.open(self._slope_raster_path) as slope_src:
                    slope_arr = slope_src.read(1).astype("float32")
                if slope_arr.shape == catch_bool.shape:
                    valid = catch_bool & (slope_arr >= 0) & (slope_arr <= 90)
                    if valid.any():
                        avg_slope = float(slope_arr[valid].mean())

            # ---- estimated peak inflow at the pour point ----
            pour_col = int((pour_x - transform.c) / transform.a)
            pour_row = int((pour_y - transform.f) / transform.e)
            pour_row = max(0, min(acc_array.shape[0] - 1, pour_row))
            pour_col = max(0, min(acc_array.shape[1] - 1, pour_col))
            peak_acc_val = int(acc_array[pour_row, pour_col])
            cell_area    = self._last_cell_area_m2 or (cell_w ** 2)
            runoff_m     = (self._last_runoff_mm or 0) / 1000.0
            est_inflow   = round(peak_acc_val * cell_area * runoff_m, 1)

            self._display_earthwork_catchment({
                "geometry":     QgsGeometry.fromWkt(catchment_poly.wkt),
                "area_ha":      round(area_ha, 2),
                "avg_slope":    avg_slope,
                "est_inflow":   est_inflow,
            }, ew_name)

        except Exception:
            import traceback
            QgsMessageLog.logMessage(
                f"Catchment delineation error:\n{traceback.format_exc()}",
                "TerrainFlow", Qgis.Warning
            )

    def _display_earthwork_catchment(self, data, ew_name):
        """
        Add a semi-transparent teal polygon showing the catchment area for an
        earthwork, labelled with area, average slope, and estimated storm inflow.
        """
        layer_name = f"Catchment — {ew_name}"
        for lyr in QgsProject.instance().mapLayersByName(layer_name):
            QgsProject.instance().removeMapLayer(lyr)

        layer = QgsVectorLayer("Polygon", layer_name, "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("area_ha",    QVariant.Double),
            QgsField("avg_slope",  QVariant.Double),
            QgsField("inflow_m3",  QVariant.Double),
            QgsField("label",      QVariant.String),
        ])
        layer.updateFields()

        avg_slope = data.get("avg_slope")
        slope_str = f"{avg_slope:.1f}°" if avg_slope is not None else "—"
        inflow    = data.get("est_inflow", 0)
        area_ha   = data["area_ha"]

        label_txt = (
            f"{ew_name}\n"
            f"Area: {area_ha:.1f} ha\n"
            f"Avg slope: {slope_str}\n"
            f"Est. inflow: {inflow:,.0f} m³"
        )

        f = QgsFeature()
        f.setGeometry(data["geometry"])
        f.setAttributes([area_ha, avg_slope or -1.0, inflow, label_txt])
        pr.addFeatures([f])

        # Distinct teal colour — separates from the blue/orange analysis catchments
        symbol = QgsFillSymbol.createSimple({
            "color":         "0,180,160,45",
            "outline_color": "0,130,115,200",
            "outline_width": "0.8",
            "outline_style": "dash",
        })
        layer.setRenderer(QgsSingleSymbolRenderer(symbol))

        lbl = QgsPalLayerSettings()
        lbl.fieldName = "label"
        lbl.enabled   = True
        try:
            lbl.placement = Qgis.LabelPlacement.OverPoint
        except Exception:
            pass
        tf = QgsTextFormat()
        tf.setColor(QColor(0, 90, 80))
        lbl.setFormat(tf)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl))
        layer.setLabelsEnabled(True)

        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer)
