import os
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QGroupBox,
    QProgressBar, QSpinBox, QDoubleSpinBox,
    QComboBox, QTextEdit, QListWidget, QListWidgetItem,
    QScrollArea, QSizePolicy, QCheckBox
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel

from .processing.scs_runoff import SCSRunoff


class TerrainFlowPanel(QDockWidget):
    """Docked panel for TerrainFlow plugin."""

    def __init__(self, parent=None):
        super().__init__("TerrainFlow", parent)
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self._dem_path = None
        self._cell_size_m2 = None
        self._build_ui()
        self._update_channel_type_label()

    def _build_ui(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(8)

        # ---------------------------------------------------------------- Data
        data_group = QGroupBox("Data")
        data_layout = QVBoxLayout(data_group)

        data_layout.addWidget(QLabel("DEM layer (auto-applied on selection):"))
        self.combo_dem_layer = QgsMapLayerComboBox()
        self.combo_dem_layer.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.combo_dem_layer.setAllowEmptyLayer(True)
        self.combo_dem_layer.setCurrentIndex(0)
        data_layout.addWidget(self.combo_dem_layer)

        data_layout.addWidget(QLabel("Or load from file:"))
        self.btn_load_dem = QPushButton("Browse...")
        data_layout.addWidget(self.btn_load_dem)

        self.lbl_dem_status = QLabel("No DEM selected")
        self.lbl_dem_status.setWordWrap(True)
        data_layout.addWidget(self.lbl_dem_status)

        data_layout.addWidget(QLabel("Site boundary (polygon layer):"))
        self.combo_boundary_layer = QgsMapLayerComboBox()
        self.combo_boundary_layer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.combo_boundary_layer.setAllowEmptyLayer(True)
        self.combo_boundary_layer.setCurrentIndex(0)
        self.combo_boundary_layer.setToolTip(
            "Select a polygon layer for your site boundary.\n"
            "Exit points where water leaves the site will be detected."
        )
        data_layout.addWidget(self.combo_boundary_layer)
        layout.addWidget(data_group)

        # ------------------------------------------------------------ Rainfall
        rainfall_group = QGroupBox("Rainfall")
        rainfall_layout = QVBoxLayout(rainfall_group)

        preset_layout = QHBoxLayout()
        preset_layout.addWidget(QLabel("Storm preset:"))
        self.combo_preset = QComboBox()
        for label in SCSRunoff.STORM_PRESETS:
            self.combo_preset.addItem(label)
        self.combo_preset.currentIndexChanged.connect(self._on_preset_changed)
        preset_layout.addWidget(self.combo_preset)
        rainfall_layout.addLayout(preset_layout)

        intensity_layout = QHBoxLayout()
        intensity_layout.addWidget(QLabel("Intensity (mm/hr):"))
        self.spin_intensity = QDoubleSpinBox()
        self.spin_intensity.setRange(1, 500)
        self.spin_intensity.setValue(40)
        self.spin_intensity.setDecimals(1)
        intensity_layout.addWidget(self.spin_intensity)
        rainfall_layout.addLayout(intensity_layout)

        duration_layout = QHBoxLayout()
        duration_layout.addWidget(QLabel("Duration (hours):"))
        self.spin_duration = QDoubleSpinBox()
        self.spin_duration.setRange(0.1, 72)
        self.spin_duration.setValue(1.0)
        self.spin_duration.setDecimals(1)
        duration_layout.addWidget(self.spin_duration)
        rainfall_layout.addLayout(duration_layout)
        layout.addWidget(rainfall_group)

        # ---------------------------------------------------------- Analysis
        analysis_group = QGroupBox("Baseline Analysis")
        analysis_layout = QVBoxLayout(analysis_group)

        # Water flow threshold (ha-based)
        thresh_row = QHBoxLayout()
        thresh_row.addWidget(QLabel("Water flow threshold:"))
        self.spin_threshold_ha = QDoubleSpinBox()
        self.spin_threshold_ha.setRange(0.1, 500.0)
        self.spin_threshold_ha.setValue(1.0)
        self.spin_threshold_ha.setDecimals(1)
        self.spin_threshold_ha.setSingleStep(0.5)
        self.spin_threshold_ha.setSuffix(" ha")
        self.spin_threshold_ha.setToolTip(
            "Minimum upstream catchment area for a flow path to be shown as a channel.\n\n"
            "Lower = more channels shown.  Higher = major watercourses only.\n\n"
            "Channel types by contributing area:\n"
            "  Rills / erosion paths:   < 0.5 ha\n"
            "  Ephemeral / seasonal:    0.5 – 5 ha\n"
            "  Permanent stream:        5 – 20 ha\n"
            "  River:                   > 20 ha"
        )
        self.spin_threshold_ha.valueChanged.connect(self._update_channel_type_label)
        thresh_row.addWidget(self.spin_threshold_ha)
        analysis_layout.addLayout(thresh_row)

        self.lbl_channel_type = QLabel("")
        self.lbl_channel_type.setStyleSheet("color: #555555; font-style: italic;")
        self.lbl_channel_type.setWordWrap(True)
        analysis_layout.addWidget(self.lbl_channel_type)

        # Advanced settings toggle
        self._btn_advanced = QPushButton("▶  Advanced Settings")
        self._btn_advanced.setCheckable(True)
        self._btn_advanced.setChecked(False)
        self._btn_advanced.setFlat(True)
        self._btn_advanced.setStyleSheet("text-align: left; font-weight: bold;")
        self._btn_advanced.clicked.connect(self._toggle_advanced_settings)
        analysis_layout.addWidget(self._btn_advanced)

        # Advanced settings widget (hidden by default)
        self._widget_advanced = QWidget()
        adv_layout = QVBoxLayout(self._widget_advanced)
        adv_layout.setContentsMargins(8, 0, 0, 0)
        adv_layout.setSpacing(4)

        # CN
        cn_layout = QHBoxLayout()
        cn_layout.addWidget(QLabel("Curve Number (CN):"))
        self.spin_cn = QSpinBox()
        self.spin_cn.setRange(1, 100)
        self.spin_cn.setValue(70)
        self.spin_cn.setToolTip(
            "SCS Curve Number — soil runoff potential.\n"
            "Higher = more runoff.\n\n"
            "Typical values (Normal moisture):\n"
            "  Sand: 39  |  Sandy loam: 49\n"
            "  Loam: 61  |  Clay loam: 74  |  Clay: 80"
        )
        cn_layout.addWidget(self.spin_cn)
        adv_layout.addLayout(cn_layout)

        # Moisture condition
        moisture_layout = QHBoxLayout()
        moisture_layout.addWidget(QLabel("Moisture condition:"))
        self.combo_moisture = QComboBox()
        self.combo_moisture.addItems(["Dry", "Normal", "Wet / Saturated"])
        self.combo_moisture.setCurrentIndex(1)
        moisture_layout.addWidget(self.combo_moisture)
        adv_layout.addLayout(moisture_layout)

        # Stream mode
        mode_layout = QHBoxLayout()
        mode_layout.addWidget(QLabel("Stream mode:"))
        self.combo_threshold_mode = QComboBox()
        self.combo_threshold_mode.addItems([
            "Contributing area (ha)",
            "Runoff volume (m³)",
        ])
        self.combo_threshold_mode.setToolTip(
            "Contributing area (ha): streams defined by upstream catchment area.\n"
            "Independent of rainfall — shows the terrain's natural drainage network.\n\n"
            "Runoff volume (m³): streams defined by volume of runoff passing through.\n"
            "Rainfall- and CN-dependent — changes with storm size and soil conditions.\n"
            "Use this to see which channels only activate in larger storms."
        )
        self.combo_threshold_mode.currentIndexChanged.connect(self._on_threshold_mode_changed)
        mode_layout.addWidget(self.combo_threshold_mode)
        adv_layout.addLayout(mode_layout)

        # Volume threshold (shown when mode = runoff volume)
        self._widget_volume_threshold = QWidget()
        vol_layout = QHBoxLayout(self._widget_volume_threshold)
        vol_layout.setContentsMargins(0, 0, 0, 0)
        vol_layout.addWidget(QLabel("Threshold (m³):"))
        self.spin_volume_threshold = QDoubleSpinBox()
        self.spin_volume_threshold.setRange(0.1, 1_000_000)
        self.spin_volume_threshold.setValue(50.0)
        self.spin_volume_threshold.setDecimals(1)
        self.spin_volume_threshold.setSingleStep(10)
        self.spin_volume_threshold.setToolTip(
            "Minimum runoff volume (m³) passing through a cell for it to be\n"
            "classified as a stream. Calculated from flow accumulation × storm runoff.\n\n"
            "Lower = more channels shown in this storm.\n"
            "Higher = only the highest-flow channels shown.\n\n"
            "Unlike contributing area mode, this changes when rainfall or CN changes."
        )
        vol_layout.addWidget(self.spin_volume_threshold)
        self._widget_volume_threshold.setVisible(False)
        adv_layout.addWidget(self._widget_volume_threshold)

        # Catchments option
        self.chk_catchments = QCheckBox("Delineate catchment polygons")
        self.chk_catchments.setChecked(False)
        self.chk_catchments.setToolTip(
            "Delineate and display catchment area polygons with flow direction arrows.\n"
            "Adds processing time — disable for quick scenario comparisons."
        )
        adv_layout.addWidget(self.chk_catchments)

        self._widget_advanced.setVisible(False)
        analysis_layout.addWidget(self._widget_advanced)

        self.btn_run = QPushButton("Run Baseline Analysis")
        self.btn_run.setEnabled(False)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.lbl_status = QLabel("Load a DEM to begin.")
        self.lbl_status.setWordWrap(True)
        analysis_layout.addWidget(self.btn_run)
        analysis_layout.addWidget(self.progress_bar)
        analysis_layout.addWidget(self.lbl_status)
        layout.addWidget(analysis_group)

        # --------------------------------------------------------- Earthworks
        ew_group = QGroupBox("Earthworks")
        ew_layout = QVBoxLayout(ew_group)

        # Draw tools row 1: manual drawing
        draw_row = QHBoxLayout()
        self.btn_draw_swale = QPushButton("Draw Swale")
        self.btn_draw_swale.setToolTip(
            "Freehand swale — left-click to add vertices, right-click to finish.\n"
            "Use 'Contour Swale' to snap directly to a contour line."
        )
        self.btn_draw_berm = QPushButton("Draw Berm")
        self.btn_draw_berm.setToolTip(
            "Draw a berm / levee ridge.\n\n"
            "The berm raises terrain by the specified depth, blocking downhill flow.\n"
            "Water retained behind it will show after Re-analyse with Earthworks.\n\n"
            "For a valley dam that spans two hillsides, use Draw Dam instead."
        )
        self.btn_draw_basin = QPushButton("Draw Basin")
        self.btn_draw_basin.setToolTip("Draw a detention basin polygon")
        draw_row.addWidget(self.btn_draw_swale)
        draw_row.addWidget(self.btn_draw_berm)
        draw_row.addWidget(self.btn_draw_basin)
        ew_layout.addLayout(draw_row)

        # Draw tools row 2: dam
        dam_row = QHBoxLayout()
        self.btn_draw_dam = QPushButton("Draw Dam / Valley Wall")
        self.btn_draw_dam.setToolTip(
            "Draw a dam wall across a valley to block and store water.\n\n"
            "Draw a line between two points on opposite sides of the valley.\n"
            "The plugin will sample the DEM elevation at both endpoints and\n"
            "set the crest to the higher of the two — you can adjust this.\n\n"
            "The wall is raised to that absolute elevation across its full width,\n"
            "filling the valley profile underneath it. Water pools behind the dam\n"
            "up to the crest elevation.\n\n"
            "Requires a DEM to be loaded. Run Re-analyse with Earthworks to\n"
            "see the retained volume."
        )
        dam_row.addWidget(self.btn_draw_dam)
        ew_layout.addLayout(dam_row)

        # Draw tools row 2: contour swale
        contour_row = QHBoxLayout()
        self.btn_contour_swale = QPushButton("Contour Swale")
        self.btn_contour_swale.setEnabled(False)
        self.btn_contour_swale.setToolTip(
            "Click a contour line on the map to create a swale that follows it exactly.\n"
            "The lip elevation will be constant along the entire swale — water fills evenly\n"
            "and only overflows at the spillway point.\n\n"
            "Generate contours first using 'Generate Contours', then optionally run\n"
            "'Analyse Contour Flow' to identify the best contour for swale placement."
        )
        contour_row.addWidget(self.btn_contour_swale)
        ew_layout.addLayout(contour_row)

        # Exclusion zones row
        excl_row = QHBoxLayout()
        self.btn_draw_exclusion = QPushButton("Draw Exclusion Zone")
        self.btn_draw_exclusion.setToolTip(
            "Draw a polygon on the map to mark areas where earthworks should not\n"
            "be placed (buildings, roads, watercourses, protected areas, etc.).\n\n"
            "Optimal swale contours will be clipped to avoid these zones.\n"
            "A warning will appear if you draw a swale that overlaps a zone.\n\n"
            "Left-click to add vertices, double-click to finish the polygon."
        )
        self.btn_clear_exclusion_zones = QPushButton("Clear Zones")
        self.btn_clear_exclusion_zones.setEnabled(False)
        self.btn_clear_exclusion_zones.setToolTip("Remove all drawn exclusion zone polygons.")
        self.btn_toggle_exclusion_zones = QPushButton("Show Zones")
        self.btn_toggle_exclusion_zones.setCheckable(True)
        self.btn_toggle_exclusion_zones.setChecked(True)
        self.btn_toggle_exclusion_zones.setEnabled(False)
        excl_row.addWidget(self.btn_draw_exclusion)
        excl_row.addWidget(self.btn_clear_exclusion_zones)
        excl_row.addWidget(self.btn_toggle_exclusion_zones)
        ew_layout.addLayout(excl_row)

        # Spillway row
        spillway_row = QHBoxLayout()
        self.btn_place_spillway = QPushButton("Place Spillway Point")
        self.btn_place_spillway.setToolTip(
            "Click on the map to place a spillway point on the selected earthwork.\n"
            "Select an earthwork in the list below first."
        )
        self.btn_place_spillway.setEnabled(False)
        spillway_row.addWidget(self.btn_place_spillway)
        ew_layout.addLayout(spillway_row)

        # Earthworks list
        ew_layout.addWidget(QLabel("Drawn earthworks (check to enable):"))
        self.list_earthworks = QListWidget()
        self.list_earthworks.setMaximumHeight(160)
        self.list_earthworks.setToolTip(
            "Check/uncheck to enable or disable features.\n"
            "Double-click to edit properties."
        )
        ew_layout.addWidget(self.list_earthworks)

        # List actions row
        list_actions = QHBoxLayout()
        self.btn_delete_earthwork = QPushButton("Delete Selected")
        self.btn_delete_earthwork.setEnabled(False)
        self.btn_edit_earthwork = QPushButton("Edit Properties")
        self.btn_edit_earthwork.setEnabled(False)
        list_actions.addWidget(self.btn_edit_earthwork)
        list_actions.addWidget(self.btn_delete_earthwork)
        ew_layout.addLayout(list_actions)

        # Re-analyse + contours row
        action_row = QHBoxLayout()
        self.btn_reanalyse = QPushButton("Re-analyse with Earthworks")
        self.btn_reanalyse.setEnabled(False)
        self.btn_reanalyse.setToolTip("Burn earthworks into DEM and re-run flow analysis")
        self.btn_contours = QPushButton("Generate Contours")
        self.btn_contours.setToolTip("Generate a contour layer from the DEM to aid swale placement")
        self.btn_contours.setEnabled(False)
        action_row.addWidget(self.btn_reanalyse)
        action_row.addWidget(self.btn_contours)
        ew_layout.addLayout(action_row)

        # Contour / swale analysis row
        contour_analysis_row = QHBoxLayout()
        self.btn_optimal_swale_contours = QPushButton("Optimal Swale Contours")
        self.btn_optimal_swale_contours.setEnabled(False)
        self.btn_optimal_swale_contours.setToolTip(
            "Scan the DEM and flow accumulation to find the N elevations where a\n"
            "swale would intercept the most water, then automatically generate\n"
            "contour lines at exactly those elevations.\n\n"
            "No pre-existing contours needed — works directly from the DEM.\n"
            "Requires: baseline analysis run."
        )
        self.btn_analyse_contour_flow = QPushButton("Analyse Contour Flow")
        self.btn_analyse_contour_flow.setEnabled(False)
        self.btn_analyse_contour_flow.setToolTip(
            "Sample flow accumulation along every contour in the active contour layer\n"
            "to rank them by peak inflow. Use after 'Generate Contours' or\n"
            "'Optimal Swale Contours'.\n\n"
            "Requires: baseline analysis run + a contour layer."
        )
        contour_analysis_row.addWidget(self.btn_optimal_swale_contours)
        contour_analysis_row.addWidget(self.btn_analyse_contour_flow)
        ew_layout.addLayout(contour_analysis_row)

        opt_count_row = QHBoxLayout()
        opt_count_row.addWidget(QLabel("Optimal contours to find:"))
        self.spin_optimal_contour_count = QSpinBox()
        self.spin_optimal_contour_count.setRange(1, 10)
        self.spin_optimal_contour_count.setValue(5)
        self.spin_optimal_contour_count.setToolTip(
            "Number of optimal swale contours to generate.\n"
            "Each will be at a different elevation, spread across the hillslope."
        )
        opt_count_row.addWidget(self.spin_optimal_contour_count)
        ew_layout.addLayout(opt_count_row)

        self.lbl_contour_flow_result = QLabel("")
        self.lbl_contour_flow_result.setWordWrap(True)
        self.lbl_contour_flow_result.setStyleSheet("color: #003080;")
        ew_layout.addWidget(self.lbl_contour_flow_result)

        # Before/After toggle
        self.btn_toggle_before_after = QPushButton("Show: Baseline")
        self.btn_toggle_before_after.setCheckable(True)
        self.btn_toggle_before_after.setEnabled(False)
        self.btn_toggle_before_after.setToolTip("Toggle between baseline and post-earthwork results")
        ew_layout.addWidget(self.btn_toggle_before_after)

        layout.addWidget(ew_group)

        # ----------------------------------------------------------- Results
        results_group = QGroupBox("Results")
        results_layout = QVBoxLayout(results_group)

        self.btn_query_ponding = QPushButton("Query Depression / Ponding")
        self.btn_query_ponding.setEnabled(False)
        self.btn_query_ponding.setToolTip(
            "Click on a blue zone in the 'Natural Depressions' or\n"
            "'Water Captured' layer to select the entire connected\n"
            "pooling area and report its volume and surface area.\n\n"
            "Baseline: shows natural low spots where water collects.\n"
            "Earthworks: shows water captured by your swales/basins."
        )
        self.lbl_ponding_result = QLabel("")
        self.lbl_ponding_result.setWordWrap(True)
        results_layout.addWidget(self.btn_query_ponding)
        results_layout.addWidget(self.lbl_ponding_result)

        self.btn_toggle_streams = QPushButton("Show Stream Network")
        self.btn_toggle_streams.setCheckable(True)
        self.btn_toggle_streams.setEnabled(False)

        self.btn_toggle_accumulation = QPushButton("Show Flow Accumulation")
        self.btn_toggle_accumulation.setCheckable(True)
        self.btn_toggle_accumulation.setEnabled(False)

        self.btn_toggle_slope_arrows = QPushButton("Show Slope Direction")
        self.btn_toggle_slope_arrows.setCheckable(True)
        self.btn_toggle_slope_arrows.setEnabled(False)
        self.btn_toggle_slope_arrows.setToolTip(
            "Overlay arrows showing the direction of steepest downslope at regular intervals.\n"
            "Generated from the DEM aspect — arrows point in the direction water would flow."
        )

        self.txt_results = QTextEdit()
        self.txt_results.setReadOnly(True)
        self.txt_results.setMaximumHeight(160)
        self.txt_results.setPlaceholderText("Runoff summary will appear here after analysis.")

        self.btn_toggle_slope_class = QPushButton("Show Slope Classification")
        self.btn_toggle_slope_class.setCheckable(True)
        self.btn_toggle_slope_class.setEnabled(False)
        self.btn_toggle_slope_class.setToolTip(
            "Semi-transparent slope suitability overlay (calculated from DEM):\n"
            "  Green  (0–3°):   ideal — suitable for swales and basins\n"
            "  Yellow (3–8°):   moderate — suitable with care\n"
            "  Orange (8–15°):  challenging — consider companion berm\n"
            "  Red    (>15°):   steep — berms or diversion drains recommended"
        )
        results_layout.addWidget(self.btn_toggle_slope_class)

        # Inline slope legend — always shown so user knows what colours mean
        slope_legend = QWidget()
        slope_legend_layout = QHBoxLayout(slope_legend)
        slope_legend_layout.setContentsMargins(4, 0, 4, 2)
        slope_legend_layout.setSpacing(4)
        for hex_colour, lbl_text in [
            ("#50C850", "0–3°"),
            ("#DCDC1E", "3–8°"),
            ("#FF8C00", "8–15°"),
            ("#DC1E1E", ">15°"),
        ]:
            swatch = QLabel()
            swatch.setFixedSize(13, 13)
            swatch.setStyleSheet(
                f"background-color: {hex_colour}; border: 1px solid #888;"
            )
            lbl = QLabel(lbl_text)
            lbl.setStyleSheet("font-size: 10px;")
            slope_legend_layout.addWidget(swatch)
            slope_legend_layout.addWidget(lbl)
        slope_legend_layout.addStretch()
        results_layout.addWidget(slope_legend)

        results_layout.addWidget(self.btn_toggle_streams)
        results_layout.addWidget(self.btn_toggle_accumulation)
        results_layout.addWidget(self.btn_toggle_slope_arrows)
        results_layout.addWidget(self.txt_results)
        layout.addWidget(results_group)

        layout.addStretch()
        scroll.setWidget(container)
        self.setWidget(scroll)

    # --------------------------------------------------------- preset handler

    def _on_preset_changed(self, index):
        label = self.combo_preset.currentText()
        intensity, duration = SCSRunoff.STORM_PRESETS[label]
        if intensity is not None:
            self.spin_intensity.setValue(intensity)
            self.spin_duration.setValue(duration)
            self.spin_intensity.setEnabled(False)
            self.spin_duration.setEnabled(False)
        else:
            self.spin_intensity.setEnabled(True)
            self.spin_duration.setEnabled(True)

    def _on_threshold_mode_changed(self, index):
        self._widget_volume_threshold.setVisible(index != 0)

    def _update_channel_type_label(self):
        ha = self.spin_threshold_ha.value()
        if ha < 0.5:
            ch_type = "Rill / erosion path"
            detail = "fine surface drainage, flows briefly during heavy rain"
        elif ha < 5.0:
            ch_type = "Ephemeral / seasonal channel"
            detail = "flows after rain, dry in summer"
        elif ha < 20.0:
            ch_type = "Permanent stream"
            detail = "year-round flow expected"
        else:
            ch_type = "River"
            detail = "major watercourse"
        self.lbl_channel_type.setText(f"↳  {ch_type}  —  {detail}")

    def _toggle_advanced_settings(self, checked):
        self._widget_advanced.setVisible(checked)
        arrow = "▼" if checked else "▶"
        self._btn_advanced.setText(f"{arrow}  Advanced Settings")

    # --------------------------------------------------------- public helpers

    def get_moisture_key(self):
        return {0: "dry", 1: "normal", 2: "wet"}[self.combo_moisture.currentIndex()]

    def get_optimal_contour_count(self):
        return self.spin_optimal_contour_count.value()

    def get_threshold_mode(self):
        return "cells" if self.combo_threshold_mode.currentIndex() == 0 else "volume"

    def get_volume_threshold(self):
        return self.spin_volume_threshold.value()

    def get_stream_threshold_cells(self):
        """Convert ha threshold to cell count for analysis worker."""
        if self._cell_size_m2 and self._cell_size_m2 > 0:
            return max(1, int(self.spin_threshold_ha.value() * 10_000 / self._cell_size_m2))
        return 1000  # safe default before DEM is loaded

    def set_cell_size(self, cell_size_m2):
        """Called after DEM load with the cell area in m²."""
        self._cell_size_m2 = cell_size_m2
        self._update_channel_type_label()

    def set_dem_path(self, path):
        self._dem_path = path
        self.lbl_dem_status.setText(os.path.basename(path))
        self.btn_run.setEnabled(True)
        self.btn_contours.setEnabled(True)
        self.lbl_status.setText("Ready to run analysis.")

    def set_progress(self, value, message=""):
        self.progress_bar.setValue(value)
        if message:
            self.lbl_status.setText(message)

    def set_results_ready(self, summary_text=""):
        self.btn_toggle_streams.setEnabled(True)
        self.btn_toggle_accumulation.setEnabled(True)
        self.btn_toggle_slope_arrows.setEnabled(True)
        self.btn_reanalyse.setEnabled(True)
        self.lbl_status.setText("Analysis complete.")
        if summary_text:
            self.txt_results.setText(summary_text)

    def add_earthwork_to_list(self, index, summary):
        item = QListWidgetItem(summary)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
        item.setCheckState(Qt.Checked)
        item.setData(Qt.UserRole, index)
        self.list_earthworks.addItem(item)
        self.btn_place_spillway.setEnabled(True)
        self.btn_delete_earthwork.setEnabled(True)
        self.btn_edit_earthwork.setEnabled(True)

    def update_earthwork_in_list(self, index, summary):
        for i in range(self.list_earthworks.count()):
            item = self.list_earthworks.item(i)
            if item.data(Qt.UserRole) == index:
                item.setText(summary)
                break

    def refresh_earthwork_list(self, earthworks):
        self.list_earthworks.clear()
        for i, ew in enumerate(earthworks):
            item = QListWidgetItem(ew.summary())
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if ew.enabled else Qt.Unchecked)
            item.setData(Qt.UserRole, i)
            self.list_earthworks.addItem(item)
