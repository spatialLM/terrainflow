class Earthwork:
    """Represents a single earthwork feature."""

    TYPE_SWALE = "swale"
    TYPE_BERM = "berm"
    TYPE_BASIN = "basin"

    def __init__(self, ew_type, geometry, name):
        self.type = ew_type          # 'swale' | 'berm' | 'basin'
        self.geometry = geometry     # QgsGeometry
        self.name = name
        self.depth = 0.5             # metres cut/raised
        self.width = 1.0             # metres cross-section
        self.companion_berm = False  # swales only: place excavated material downhill
        self.spillway_point = None   # QgsPointXY or None
        self.spillway_elevation = None  # metres; None = top of feature
        self.enabled = True
        self.capacity_m3 = 0.0
        self.capacity_l = 0.0

    def type_label(self):
        return self.type.capitalize()

    def summary(self):
        status = "" if self.enabled else " [OFF]"
        return f"{self.name} ({self.type_label()}) — {self.capacity_m3:.1f} m³ | {self.capacity_l:,.0f} L{status}"


class EarthworkManager:
    """Manages the list of earthworks for the current session."""

    def __init__(self):
        self._earthworks = []

    def add(self, earthwork):
        self._earthworks.append(earthwork)

    def remove(self, index):
        if 0 <= index < len(self._earthworks):
            self._earthworks.pop(index)

    def toggle(self, index):
        if 0 <= index < len(self._earthworks):
            ew = self._earthworks[index]
            ew.enabled = not ew.enabled

    def get(self, index):
        return self._earthworks[index]

    def get_all(self):
        return list(self._earthworks)

    def get_enabled(self):
        return [e for e in self._earthworks if e.enabled]

    def clear(self):
        self._earthworks.clear()

    def __len__(self):
        return len(self._earthworks)


def calculate_capacity(ew_type, geometry, depth, width):
    """
    Calculate storage capacity of an earthwork from its geometry and dimensions.

    Swale / Berm (polyline):
        Trapezoidal cross-section, 1:1 side slopes.
        Area = (bottom_width + top_width) / 2 * depth
             = (width + (width + 2*depth)) / 2 * depth
        Volume = area * length * 0.8  (0.8 freeboard factor)

    Basin (polygon):
        Volume = polygon_area * depth * 0.8

    Berm:
        No storage capacity — it's a barrier, returns 0.
    """
    if ew_type == "berm":
        return 0.0, 0.0

    if ew_type == "swale":
        length = geometry.length()  # map units (metres for NZTM)
        bottom_width = max(0.1, width - 2 * depth)
        top_width = width + 2 * depth
        cross_section_area = ((bottom_width + top_width) / 2) * depth
        volume_m3 = cross_section_area * length * 0.8

    elif ew_type == "basin":
        area_m2 = geometry.area()
        volume_m3 = area_m2 * depth * 0.8

    else:
        return 0.0, 0.0

    return round(volume_m3, 2), round(volume_m3 * 1000, 1)
