from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QSpinBox, QDoubleSpinBox, QCheckBox,
    QLabel, QPushButton, QDialogButtonBox, QGroupBox
)
from qgis.PyQt.QtCore import Qt

from .processing.earthwork import calculate_capacity


class EarthworkPropertiesDialog(QDialog):
    """
    Popup dialog shown after an earthwork is drawn.
    Lets the user set name, depth, width, and companion berm option.
    Displays calculated capacity in real time.
    """

    def __init__(self, ew_type, geometry, parent=None, earthwork=None):
        super().__init__(parent)
        self.ew_type = ew_type
        self.geometry = geometry
        self._editing = earthwork is not None

        self.setWindowTitle(f"{'Edit' if self._editing else 'New'} {ew_type.capitalize()} Properties")
        self.setMinimumWidth(320)
        self._build_ui(earthwork)
        self._update_capacity()

    def _build_ui(self, ew=None):
        layout = QVBoxLayout(self)

        form = QFormLayout()

        # Name
        self.edit_name = QLineEdit(ew.name if ew else f"New {self.ew_type.capitalize()}")
        form.addRow("Name:", self.edit_name)

        # Type (read-only label)
        form.addRow("Type:", QLabel(self.ew_type.capitalize()))

        # Depth
        self.spin_depth = QDoubleSpinBox()
        self.spin_depth.setRange(0.1, 10.0)
        self.spin_depth.setValue(ew.depth if ew else 0.5)
        self.spin_depth.setDecimals(2)
        self.spin_depth.setSuffix(" m")
        self.spin_depth.valueChanged.connect(self._update_capacity)
        form.addRow("Depth:", self.spin_depth)

        # Width
        self.spin_width = QDoubleSpinBox()
        self.spin_width.setRange(0.1, 50.0)
        self.spin_width.setValue(ew.width if ew else 1.0)
        self.spin_width.setDecimals(2)
        self.spin_width.setSuffix(" m")
        self.spin_width.valueChanged.connect(self._update_capacity)
        form.addRow("Width:", self.spin_width)

        # Companion berm (swales only)
        self.chk_companion = QCheckBox("Build companion berm on downhill side")
        self.chk_companion.setChecked(ew.companion_berm if ew else False)
        self.chk_companion.setVisible(self.ew_type == "swale")
        if self.ew_type == "swale":
            self.chk_companion.setToolTip(
                "Excavated material is placed on the downhill side of the swale,\n"
                "forming a berm that increases water retention. Volume is conserved."
            )
            form.addRow("", self.chk_companion)

        layout.addLayout(form)

        # Capacity display
        cap_group = QGroupBox("Calculated Capacity")
        cap_layout = QFormLayout(cap_group)
        self.lbl_capacity_m3 = QLabel("—")
        self.lbl_capacity_l = QLabel("—")
        cap_layout.addRow("Volume (m³):", self.lbl_capacity_m3)
        cap_layout.addRow("Volume (L):", self.lbl_capacity_l)
        if self.ew_type == "berm":
            cap_layout.addRow(QLabel("Berms are barriers — no storage capacity."))
        layout.addWidget(cap_group)

        # Spillway section (display only in properties, placement done via map tool)
        if self.ew_type != "berm" and ew and ew.spillway_point:
            spill_group = QGroupBox("Spillway")
            spill_layout = QFormLayout(spill_group)
            spill_layout.addRow("Point:", QLabel("Placed ✓"))
            self.spin_spillway_elev = QDoubleSpinBox()
            self.spin_spillway_elev.setRange(0, 5000)
            self.spin_spillway_elev.setValue(ew.spillway_elevation or 0)
            self.spin_spillway_elev.setSuffix(" m")
            spill_layout.addRow("Overflow elevation:", self.spin_spillway_elev)
            layout.addWidget(spill_group)
        else:
            self.spin_spillway_elev = None

        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _update_capacity(self):
        depth = self.spin_depth.value()
        width = self.spin_width.value()
        m3, l = calculate_capacity(self.ew_type, self.geometry, depth, width)
        self.lbl_capacity_m3.setText(f"{m3:,.2f}")
        self.lbl_capacity_l.setText(f"{l:,.0f}")

    # -- Result accessors --

    def get_name(self):
        return self.edit_name.text().strip() or f"New {self.ew_type.capitalize()}"

    def get_depth(self):
        return self.spin_depth.value()

    def get_width(self):
        return self.spin_width.value()

    def get_companion_berm(self):
        return self.chk_companion.isChecked() if self.ew_type == "swale" else False

    def get_spillway_elevation(self):
        if self.spin_spillway_elev:
            return self.spin_spillway_elev.value()
        return None
