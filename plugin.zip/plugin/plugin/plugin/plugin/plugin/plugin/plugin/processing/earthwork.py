class Earthwork:
    """Represents a single earthwork feature."""

    TYPE_SWALE = "swale"
    TYPE_BERM = "berm"
    TYPE_BASIN = "basin"
    TYPE_DAM = "dam"

    def __init__(self, ew_type, geometry, name):
        self.type = ew_type          # 'swale' | 'berm' | 'basin' | 'dam'
        self.geometry = geometry     # QgsGeometry
        self.name = name
        self.depth = 0.5             # metres cut/raised (not used for dam)
        self.width = 2.0             # metres cross-section
        self.companion_berm = False  # swales only
        self.crest_elevation = None  # dam only: absolute crest elevation (m)
        self.spillway_point = None   # QgsPointXY or None
        self.spillway_elevation = None  # metres; None = top of feature
        self.enabled = True
        self.capacity_m3 = 0.0
        self.capacity_l = 0.0

    def type_label(self):
        return self.type.capitalize()

    def summary(self):
        status = "" if self.enabled else " [OFF]"
        if self.type == "dam":
            elev_str = f"{self.crest_elevation:.1f} m" if self.crest_elevation is not None else "?"
            return f"{self.name} (Dam) — crest {elev_str}{status}"
        return f"{self.name} ({self.type_label()}) — {self.capacity_m3:.1f} m³ | {self.capacity_l:,.0f} L{status}"


class EarthworkManager:
    """Manages the list of earthworks for the current session."""

    def __init__(self):
        self._earthworks = []

    def add(self, earthwork):
        self._earthworks.append(earthwork)

    def remove(self, index):
        if 0 <= index < len(self._earthworks):
            self._earthworks.pop(index)

    def toggle(self, index):
        if 0 <= index < len(self._earthworks):
            ew = self._earthworks[index]
            ew.enabled = not ew.enabled

    def get(self, index):
        return self._earthworks[index]

    def get_all(self):
        return list(self._earthworks)

    def get_enabled(self):
        return [e for e in self._earthworks if e.enabled]

    def clear(self):
        self._earthworks.clear()

    def __len__(self):
        return len(self._earthworks)


def calculate_capacity(ew_type, geometry, depth, width, companion_berm=False):
    """
    Calculate storage capacity of an earthwork from its geometry and dimensions.

    Swale (polyline):
        Trapezoidal cross-section, 1:1 side slopes.
        cross_section = (bottom_width + top_width) / 2 * depth
        Volume = cross_section * length * 0.8  (0.8 freeboard factor)

        With companion berm (volume-conserved):
        1. Excavated volume → berm with ~75% compaction.
           Triangular berm cross-section (1:1 slopes): area = h_b²
           ∴ h_b = sqrt(swale_cross_section × 0.75)
        2. Berm raises water level h_b above original ground.
           Additional ponding cross-section (triangular wedge, base = top_width):
           additional = h_b × top_width / 2
        3. Total = (swale_cross_section + additional) × length × 0.8

    Basin (polygon):
        Volume = polygon_area * depth * 0.8

    Berm:
        No storage capacity — it's a barrier, returns 0.
    """
    if ew_type in ("berm", "dam"):
        return 0.0, 0.0

    if ew_type == "swale":
        length = geometry.length()  # map units (metres for NZTM)
        bottom_width = max(0.1, width - 2 * depth)
        top_width = width + 2 * depth
        cross_section = ((bottom_width + top_width) / 2) * depth

        if companion_berm and cross_section > 0:
            # Berm height from volume conservation (75% compaction, triangular section)
            berm_height = (cross_section * 0.75) ** 0.5
            # Additional ponding above ground level against the berm
            additional_cs = berm_height * top_width / 2
            cross_section += additional_cs

        volume_m3 = cross_section * length * 0.8

    elif ew_type == "basin":
        area_m2 = geometry.area()
        volume_m3 = area_m2 * depth * 0.8

    else:
        return 0.0, 0.0

    return round(volume_m3, 2), round(volume_m3 * 1000, 1)


def berm_height_estimate(depth, width):
    """
    Estimate the height of a companion berm formed from swale excavation.
    Used for display in the properties dialog.
    """
    bottom_width = max(0.1, width - 2 * depth)
    top_width = width + 2 * depth
    cross_section = ((bottom_width + top_width) / 2) * depth
    return round((cross_section * 0.75) ** 0.5, 2)
