import os
import tempfile
import json
import numpy as np

from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QInputDialog
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsColorRampShader,
    QgsRasterShader, QgsSingleBandPseudoColorRenderer,
    QgsMessageLog, Qgis, QgsVectorLayer, QgsField,
    QgsFeature, QgsGeometry, QgsPointXY,
    QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsPalLayerSettings, QgsVectorLayerSimpleLabeling,
    QgsTextFormat, QgsWkbTypes, QgsLineSymbol,
    QgsFillSymbol, QgsRuleBasedRenderer,
    QgsCentroidFillSymbolLayer, QgsProperty,
    QgsSymbolLayer
)
from qgis.PyQt.QtCore import QVariant

from .terrain_flow_dialog import TerrainFlowPanel
from .processing.flow_analysis import FlowAnalysis
from .processing.scs_runoff import SCSRunoff
from .processing.earthwork import Earthwork, EarthworkManager, calculate_capacity
from .processing.dem_burner import DEMBurner
from .earthwork_properties_dialog import EarthworkPropertiesDialog
from .map_tools.draw_line_tool import DrawLineTool
from .map_tools.draw_polygon_tool import DrawPolygonTool
from .map_tools.place_point_tool import PlacePointTool
from .map_tools.ponding_query_tool import PondingQueryTool


# ---------------------------------------------------------------------------
# Background worker
# ---------------------------------------------------------------------------

class AnalysisWorker(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, dem_path, output_dir, stream_threshold, cn, moisture,
                 rainfall_mm, duration_hours, boundary_path=None, label="",
                 run_catchments=False):
        super().__init__()
        self.dem_path = dem_path
        self.output_dir = output_dir
        self.stream_threshold = stream_threshold
        self.cn = cn
        self.moisture = moisture
        self.rainfall_mm = rainfall_mm
        self.duration_hours = duration_hours
        self.boundary_path = boundary_path
        self.label = label
        self.run_catchments = run_catchments

    def run(self):
        try:
            analysis = FlowAnalysis()
            scs = SCSRunoff()

            self.progress.emit(10, "Loading DEM...")
            analysis.load_dem(self.dem_path)

            self.progress.emit(40, "Computing flow direction and accumulation...")
            results = analysis.run()

            self.progress.emit(70, "Extracting stream network...")
            streams = analysis.get_stream_network(accumulation_threshold=self.stream_threshold)

            self.progress.emit(82, "Calculating runoff volume...")
            effective_cn = scs.adjust_cn(self.cn, self.moisture)
            runoff_mm = scs.runoff_depth(self.rainfall_mm, effective_cn)
            cell_area_m2 = abs(analysis.transform.a * analysis.transform.e)
            catchment_area_m2 = float(np.sum(results["flow_accumulation"] > 0)) * cell_area_m2
            runoff_volume = analysis.get_runoff_volume_raster(runoff_mm, cell_area_m2)

            # Filenames encode scenario + label
            moisture_label = self.moisture.replace(" ", "").replace("/", "")
            prefix = f"{self.label}_" if self.label else ""
            acc_path = os.path.join(self.output_dir, f"{prefix}flow_accumulation.tif")
            streams_path = os.path.join(self.output_dir, f"{prefix}streams_thresh{self.stream_threshold}.tif")
            runoff_name = f"{prefix}runoff_{int(self.rainfall_mm)}mm_cn{int(self.cn)}_{moisture_label}.tif"
            runoff_path = os.path.join(self.output_dir, runoff_name)

            analysis.save_result(
                results["flow_accumulation"], acc_path,
                band_description="Upstream cell count — number of DEM cells draining through each point"
            )
            analysis.save_result(
                streams.astype("float32"), streams_path,
                band_description=f"Stream network — 1 = stream (threshold: >{self.stream_threshold} upstream cells), 0 = no stream"
            )
            analysis.save_result(
                runoff_volume, runoff_path,
                band_description="Surface runoff volume (m³) — accumulated runoff passing through each cell for this storm scenario"
            )

            # Ponding layer (only meaningful after earthworks)
            ponding_path = None
            if self.label == "earthworks":
                self.progress.emit(88, "Calculating water capture (ponding)...")
                burner = DEMBurner(self.dem_path)  # reuse transform/crs
                modified_array = analysis.dem  # already the modified DEM
                ponding = burner.get_ponding_layer(np.array(analysis.dem, dtype="float32"))
                ponding_path = os.path.join(self.output_dir, f"{prefix}ponding.tif")
                analysis.save_result(ponding, ponding_path)

            # Exit points
            exit_points = []
            if self.boundary_path:
                self.progress.emit(92, "Detecting boundary exit points...")
                exit_points = analysis.get_boundary_exit_points(
                    self.boundary_path, self.stream_threshold, runoff_mm, self.duration_hours
                )

            # Catchment polygons (optional — controlled by UI toggle)
            catchments = []
            if self.run_catchments:
                self.progress.emit(95, "Delineating catchment polygons...")
                outlet_points = [(p["x"], p["y"]) for p in exit_points] if exit_points else None
                catchments = analysis.get_catchment_polygons(outlet_points)

            self.progress.emit(100, "Done.")
            self.finished.emit({
                "label": self.label,
                "flow_accumulation": acc_path,
                "stream_network": streams_path,
                "runoff_volume": runoff_path,
                "ponding": ponding_path,
                "effective_cn": effective_cn,
                "runoff_mm": runoff_mm,
                "cell_area_m2": cell_area_m2,
                "catchment_area_m2": catchment_area_m2,
                "runoff_volume_max": float(np.nanmax(runoff_volume)) if runoff_mm > 0 else 1.0,
                "exit_points": exit_points,
                "catchments": catchments,
            })
        except Exception as e:
            import traceback
            self.error.emit(traceback.format_exc())


# ---------------------------------------------------------------------------
# Main plugin class
# ---------------------------------------------------------------------------

class TerrainFlow:

    def __init__(self, iface):
        self.iface = iface
        self.panel = None
        self.action = None
        self.worker = None
        self.output_dir = tempfile.mkdtemp(prefix="terrainflow_")
        self._scs = SCSRunoff()
        self._earthwork_manager = EarthworkManager()
        self._runoff_scale_max = None
        self._dem_path = None
        self._modified_dem_path = None
        self._burner = None
        # Layer ID tracking
        self._baseline_layer_ids = []
        self._earthworks_layer_ids = []
        self._ponding_raster_path = None
        self._earthwork_vector_layer = None
        self._spillway_vector_layer = None
        self._showing_baseline = True
        # Map tools
        self._current_tool = None
        # Slope arrows
        self._slope_arrow_layer_id = None

    # ---------------------------------------------------------------- init / unload

    def initGui(self):
        self.action = QAction("TerrainFlow", self.iface.mainWindow())
        self.action.triggered.connect(self.toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("TerrainFlow", self.action)
        self._create_panel()

    def unload(self):
        self.iface.removePluginMenu("TerrainFlow", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.panel:
            self.iface.removeDockWidget(self.panel)

    def toggle_panel(self):
        if self.panel:
            self.panel.setVisible(not self.panel.isVisible())

    # ---------------------------------------------------------------- panel

    def _create_panel(self):
        self.panel = TerrainFlowPanel(self.iface.mainWindow())

        # Data
        self.panel.btn_load_dem.clicked.connect(self._load_dem)
        self.panel.btn_use_layer.clicked.connect(self._use_selected_layer)

        # Analysis
        self.panel.btn_run.clicked.connect(self._run_baseline)

        # Results toggles
        self.panel.btn_toggle_streams.toggled.connect(self._toggle_streams_layer)
        self.panel.btn_toggle_accumulation.toggled.connect(self._toggle_accumulation_layer)
        self.panel.btn_toggle_slope_arrows.toggled.connect(self._toggle_slope_arrows)

        # Earthworks
        self.panel.btn_draw_swale.clicked.connect(lambda: self._activate_draw_line("swale"))
        self.panel.btn_draw_berm.clicked.connect(lambda: self._activate_draw_line("berm"))
        self.panel.btn_draw_basin.clicked.connect(self._activate_draw_basin)
        self.panel.btn_place_spillway.clicked.connect(self._activate_place_spillway)
        self.panel.btn_delete_earthwork.clicked.connect(self._delete_selected_earthwork)
        self.panel.btn_edit_earthwork.clicked.connect(self._edit_selected_earthwork)
        self.panel.list_earthworks.itemChanged.connect(self._on_earthwork_toggled)
        self.panel.list_earthworks.itemDoubleClicked.connect(self._edit_selected_earthwork)
        self.panel.btn_reanalyse.clicked.connect(self._run_with_earthworks)
        self.panel.btn_toggle_before_after.toggled.connect(self._toggle_before_after)
        self.panel.btn_contours.clicked.connect(self._generate_contours)
        self.panel.btn_query_ponding.clicked.connect(self._activate_ponding_query)

        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.panel)

    # ---------------------------------------------------------------- DEM loading

    def _use_selected_layer(self):
        layer = self.panel.combo_dem_layer.currentLayer()
        if not layer:
            QMessageBox.warning(self.panel, "No layer selected", "Select a raster layer from the dropdown.")
            return
        self._set_dem(layer.source())

    def _load_dem(self):
        path, _ = QFileDialog.getOpenFileName(
            self.panel, "Select DEM GeoTIFF", "", "GeoTIFF (*.tif *.tiff)"
        )
        if path:
            layer = QgsRasterLayer(path, "DEM")
            if not layer.isValid():
                QMessageBox.critical(self.panel, "Error", "Could not load DEM.")
                return
            QgsProject.instance().addMapLayer(layer)
            self._set_dem(path)

    def _set_dem(self, path):
        self._dem_path = path
        self._runoff_scale_max = None
        self._burner = DEMBurner(path)
        self.panel.set_dem_path(path)

    # ---------------------------------------------------------------- analysis

    def _run_baseline(self):
        if not self._dem_path:
            return
        self._run_analysis(self._dem_path, label="baseline")

    def _run_with_earthworks(self):
        if not self._dem_path:
            return
        enabled = self._earthwork_manager.get_enabled()
        if not enabled:
            QMessageBox.information(self.panel, "No earthworks", "Draw and enable at least one earthwork first.")
            return

        self.panel.set_progress(0, "Applying earthworks to DEM...")
        modified = self._burner.burn_earthworks(enabled)
        self._modified_dem_path = os.path.join(self.output_dir, "dem_modified.tif")
        self._burner.save(modified, self._modified_dem_path)
        self._run_analysis(self._modified_dem_path, label="earthworks")

    def _run_analysis(self, dem_path, label):
        self.panel.btn_run.setEnabled(False)
        self.panel.btn_reanalyse.setEnabled(False)
        self.panel.set_progress(0, "Starting analysis...")

        intensity = self.panel.spin_intensity.value()
        duration = self.panel.spin_duration.value()
        boundary_layer = self.panel.combo_boundary_layer.currentLayer()

        self.worker = AnalysisWorker(
            dem_path=dem_path,
            output_dir=self.output_dir,
            stream_threshold=self.panel.spin_threshold.value(),
            cn=self.panel.spin_cn.value(),
            moisture=self.panel.get_moisture_key(),
            rainfall_mm=intensity * duration,
            duration_hours=duration,
            boundary_path=boundary_layer.source() if boundary_layer else None,
            label=label,
            run_catchments=self.panel.chk_catchments.isChecked(),
        )
        self.worker.progress.connect(self.panel.set_progress)
        self.worker.finished.connect(self._on_analysis_complete)
        self.worker.error.connect(self._on_analysis_error)
        self.worker.start()

    # ---------------------------------------------------------------- analysis complete

    def _on_analysis_complete(self, result_paths):
        label = result_paths["label"]
        is_baseline = label == "baseline"

        # Flow accumulation + stream network (baseline only — terrain doesn't change)
        if is_baseline:
            if not hasattr(self, "_acc_layer_id"):
                acc_layer = QgsRasterLayer(
                    result_paths["flow_accumulation"],
                    "Flow Accumulation (upstream cell count)"
                )
                if acc_layer.isValid():
                    self._apply_accumulation_ramp(acc_layer)
                    QgsProject.instance().addMapLayer(acc_layer)
                    self._acc_layer_id = acc_layer.id()
                    self._baseline_layer_ids.append(acc_layer.id())

            if not hasattr(self, "_stream_layer_id"):
                threshold = self.panel.spin_threshold.value()
                stream_layer = QgsRasterLayer(
                    result_paths["stream_network"],
                    f"Stream Network (threshold: >{threshold} cells)"
                )
                if stream_layer.isValid():
                    self._apply_stream_ramp(stream_layer)
                    QgsProject.instance().addMapLayer(stream_layer)
                    self._stream_layer_id = stream_layer.id()
                    self._baseline_layer_ids.append(stream_layer.id())

        # Runoff volume — always add as new named layer
        if self._runoff_scale_max is None:
            self._runoff_scale_max = result_paths["runoff_volume_max"]

        runoff_path = result_paths["runoff_volume"]
        layer_name = os.path.splitext(os.path.basename(runoff_path))[0]
        runoff_layer = QgsRasterLayer(runoff_path, layer_name)
        if runoff_layer.isValid():
            self._apply_runoff_ramp(runoff_layer, self._runoff_scale_max)
            QgsProject.instance().addMapLayer(runoff_layer)
            if is_baseline:
                self._baseline_layer_ids.append(runoff_layer.id())
            else:
                self._earthworks_layer_ids.append(runoff_layer.id())

        # Ponding layer (earthworks run only)
        if result_paths.get("ponding"):
            self._ponding_raster_path = result_paths["ponding"]
            ponding_layer = QgsRasterLayer(
                self._ponding_raster_path,
                "Water Captured — ponding depth (metres)"
            )
            if ponding_layer.isValid():
                self._apply_ponding_ramp(ponding_layer)
                QgsProject.instance().addMapLayer(ponding_layer)
                self._earthworks_layer_ids.append(ponding_layer.id())
                self.panel.btn_query_ponding.setEnabled(True)
                self.panel.lbl_ponding_result.setText(
                    "Click 'Query Ponding Area' then click a blue ponding zone on the map."
                )

        # Exit points
        exit_points = result_paths.get("exit_points", [])
        if exit_points:
            self._display_exit_points(exit_points)

        # Catchment polygons
        catchments = result_paths.get("catchments", [])
        if catchments:
            self._display_catchments(catchments, label=label)

        # Enable before/after toggle once both runs exist
        if self._baseline_layer_ids and self._earthworks_layer_ids:
            self.panel.btn_toggle_before_after.setEnabled(True)

        # Summary
        intensity = self.panel.spin_intensity.value()
        duration = self.panel.spin_duration.value()
        rainfall_mm = intensity * duration
        effective_cn = result_paths["effective_cn"]
        runoff_mm = result_paths["runoff_mm"]
        runoff_ratio = runoff_mm / rainfall_mm if rainfall_mm > 0 else 0
        catchment_ha = result_paths["catchment_area_m2"] / 10000
        volume_m3 = self._scs.catchment_volume(runoff_mm, result_paths["catchment_area_m2"])
        avg_flow_ls = (volume_m3 * 1000) / (duration * 3600) if duration > 0 else 0

        tag = "Baseline" if is_baseline else "With Earthworks"
        summary = (
            f"=== {tag} ===\n"
            f"Rainfall:         {rainfall_mm:.1f} mm ({intensity:.0f} mm/hr × {duration:.1f} hr)\n"
            f"CN (entered):     {self.panel.spin_cn.value()}\n"
            f"CN (adjusted):    {effective_cn:.1f}  [{self.panel.combo_moisture.currentText()}]\n"
            f"Runoff depth:     {runoff_mm:.1f} mm\n"
            f"Runoff ratio:     {runoff_ratio*100:.0f}% of rainfall\n"
            f"Catchment area:   {catchment_ha:.1f} ha\n"
            f"Total runoff vol: {volume_m3:,.0f} m³  ({volume_m3*1000:,.0f} L)\n"
            f"Avg flow rate:    {avg_flow_ls:,.0f} L/s  (outlet, storm avg)"
        )

        if exit_points:
            exit_lines = "\n".join(f"  {p['label']}" for p in exit_points)
            summary += f"\n\nSite exit points ({len(exit_points)}):\n{exit_lines}"

        catchments = result_paths.get("catchments", [])
        if catchments:
            catch_lines = "\n".join(f"  {c['label']}" for c in catchments)
            summary += f"\n\nCatchment areas ({len(catchments)}):\n{catch_lines}"

        self.panel.btn_run.setEnabled(True)
        self.panel.set_results_ready(summary)

    def _on_analysis_error(self, message):
        self.panel.btn_run.setEnabled(True)
        self.panel.btn_reanalyse.setEnabled(True)
        self.panel.set_progress(0, "Error — see log.")
        QMessageBox.critical(self.panel, "Analysis Error", message)
        QgsMessageLog.logMessage(message, "TerrainFlow", Qgis.Critical)

    # ---------------------------------------------------------------- earthwork drawing

    def _activate_draw_line(self, ew_type):
        colors = {"swale": QColor(0, 100, 220, 200), "berm": QColor(160, 100, 30, 200)}
        tool = DrawLineTool(self.iface.mapCanvas(), color=colors.get(ew_type))
        tool.line_drawn.connect(lambda geom: self._on_geometry_drawn(ew_type, geom))
        tool.cancelled.connect(self._on_draw_cancelled)
        self.iface.mapCanvas().setMapTool(tool)
        self._current_tool = tool
        self.panel.lbl_status.setText(f"Drawing {ew_type}... right-click or double-click to finish, Esc to cancel.")

    def _activate_draw_basin(self):
        tool = DrawPolygonTool(self.iface.mapCanvas())
        tool.polygon_drawn.connect(lambda geom: self._on_geometry_drawn("basin", geom))
        tool.cancelled.connect(self._on_draw_cancelled)
        self.iface.mapCanvas().setMapTool(tool)
        self._current_tool = tool
        self.panel.lbl_status.setText("Drawing basin... right-click or double-click to finish, Esc to cancel.")

    def _on_draw_cancelled(self):
        self.panel.lbl_status.setText("Drawing cancelled.")

    def _on_geometry_drawn(self, ew_type, geometry):
        """Geometry drawn — show properties dialog, then add earthwork."""
        dlg = EarthworkPropertiesDialog(ew_type, geometry, parent=self.panel)
        if dlg.exec_() != EarthworkPropertiesDialog.Accepted:
            return

        ew = Earthwork(ew_type, geometry, dlg.get_name())
        ew.depth = dlg.get_depth()
        ew.width = dlg.get_width()
        ew.companion_berm = dlg.get_companion_berm()
        ew.capacity_m3, ew.capacity_l = calculate_capacity(ew_type, geometry, ew.depth, ew.width)

        index = len(self._earthwork_manager)
        self._earthwork_manager.add(ew)
        self.panel.add_earthwork_to_list(index, ew.summary())
        self._add_earthwork_to_map(ew)
        self.panel.lbl_status.setText(f"'{ew.name}' added.")

    def _edit_selected_earthwork(self, *args):
        row = self.panel.list_earthworks.currentRow()
        if row < 0:
            return
        ew = self._earthwork_manager.get(row)
        dlg = EarthworkPropertiesDialog(ew.type, ew.geometry, parent=self.panel, earthwork=ew)
        if dlg.exec_() != EarthworkPropertiesDialog.Accepted:
            return
        ew.name = dlg.get_name()
        ew.depth = dlg.get_depth()
        ew.width = dlg.get_width()
        ew.companion_berm = dlg.get_companion_berm()
        ew.capacity_m3, ew.capacity_l = calculate_capacity(ew.type, ew.geometry, ew.depth, ew.width)
        if dlg.get_spillway_elevation() is not None:
            ew.spillway_elevation = dlg.get_spillway_elevation()
        self.panel.update_earthwork_in_list(row, ew.summary())

    def _delete_selected_earthwork(self):
        row = self.panel.list_earthworks.currentRow()
        if row < 0:
            return
        self._earthwork_manager.remove(row)
        self.panel.list_earthworks.takeItem(row)
        self._refresh_earthwork_layer()
        self.panel.refresh_earthwork_list(self._earthwork_manager.get_all())

    def _on_earthwork_toggled(self, item):
        index = item.data(Qt.UserRole)
        enabled = item.checkState() == Qt.Checked
        ew = self._earthwork_manager.get(index)
        if ew.enabled != enabled:
            self._earthwork_manager.toggle(index)

    # ---------------------------------------------------------------- spillway

    def _activate_place_spillway(self):
        row = self.panel.list_earthworks.currentRow()
        if row < 0:
            QMessageBox.information(self.panel, "No earthwork selected",
                                    "Select an earthwork in the list, then place its spillway.")
            return
        tool = PlacePointTool(self.iface.mapCanvas())
        tool.point_placed.connect(lambda pt: self._on_spillway_placed(row, pt))
        self.iface.mapCanvas().setMapTool(tool)
        self.panel.lbl_status.setText("Click on the map to place the spillway point...")

    def _on_spillway_placed(self, ew_index, point):
        ew = self._earthwork_manager.get(ew_index)
        ew.spillway_point = point
        elev, ok = QInputDialog.getDouble(
            self.panel, "Spillway Elevation",
            f"Set spillway overflow elevation for '{ew.name}' (metres):",
            value=0.0, min=0.0, max=5000.0, decimals=2
        )
        if ok:
            ew.spillway_elevation = elev
        self._add_spillway_to_map(point, ew.name)
        self.panel.lbl_status.setText(f"Spillway placed for '{ew.name}'.")

    # ---------------------------------------------------------------- map layers

    def _ensure_earthwork_layer(self):
        if self._earthwork_vector_layer and QgsProject.instance().mapLayer(self._earthwork_vector_layer.id()):
            return
        layer = QgsVectorLayer("LineString", "Earthworks", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("name", QVariant.String),
            QgsField("type", QVariant.String),
            QgsField("depth_m", QVariant.Double),
            QgsField("width_m", QVariant.Double),
            QgsField("capacity_m3", QVariant.Double),
        ])
        layer.updateFields()
        self._style_earthwork_layer(layer)
        QgsProject.instance().addMapLayer(layer)
        self._earthwork_vector_layer = layer

    def _ensure_spillway_layer(self):
        if self._spillway_vector_layer and QgsProject.instance().mapLayer(self._spillway_vector_layer.id()):
            return
        layer = QgsVectorLayer("Point", "Spillway Points", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([QgsField("earthwork", QVariant.String)])
        layer.updateFields()
        symbol = QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "0,80,220,220",
            "outline_color": "0,40,160", "size": "4"
        })
        layer.setRenderer(QgsSingleSymbolRenderer(symbol))
        QgsProject.instance().addMapLayer(layer)
        self._spillway_vector_layer = layer

    def _add_earthwork_to_map(self, ew):
        self._ensure_earthwork_layer()
        f = QgsFeature()
        f.setGeometry(ew.geometry)
        f.setAttributes([ew.name, ew.type, ew.depth, ew.width, ew.capacity_m3])
        self._earthwork_vector_layer.dataProvider().addFeatures([f])
        self._earthwork_vector_layer.updateExtents()
        self._earthwork_vector_layer.triggerRepaint()

    def _add_spillway_to_map(self, point, ew_name):
        self._ensure_spillway_layer()
        f = QgsFeature()
        f.setGeometry(QgsGeometry.fromPointXY(point))
        f.setAttributes([ew_name])
        self._spillway_vector_layer.dataProvider().addFeatures([f])
        self._spillway_vector_layer.triggerRepaint()

    def _refresh_earthwork_layer(self):
        """Rebuild the earthwork vector layer from the manager state."""
        if self._earthwork_vector_layer:
            pr = self._earthwork_vector_layer.dataProvider()
            pr.truncate()
            features = []
            for ew in self._earthwork_manager.get_all():
                f = QgsFeature()
                f.setGeometry(ew.geometry)
                f.setAttributes([ew.name, ew.type, ew.depth, ew.width, ew.capacity_m3])
                features.append(f)
            pr.addFeatures(features)
            self._earthwork_vector_layer.updateExtents()
            self._earthwork_vector_layer.triggerRepaint()

    def _style_earthwork_layer(self, layer):
        """Colour swales blue, berms brown, basins green."""
        root_rule = QgsRuleBasedRenderer.Rule(None)
        styles = {
            "swale": ("\"type\" = 'swale'", "0,100,220", "Swale"),
            "berm":  ("\"type\" = 'berm'",  "140,90,30", "Berm"),
            "basin": ("\"type\" = 'basin'", "30,160,60", "Basin"),
        }
        for key, (expr, color, label) in styles.items():
            sym = QgsLineSymbol.createSimple({"color": color, "width": "1.0"})
            rule = QgsRuleBasedRenderer.Rule(sym)
            rule.setFilterExpression(expr)
            rule.setLabel(label)
            root_rule.appendChild(rule)
        layer.setRenderer(QgsRuleBasedRenderer(root_rule))

    def _display_catchments(self, catchments, label=""):
        """Display catchment polygons as a styled vector layer with area labels."""
        if not catchments:
            return

        layer_name = f"Catchments ({label})" if label else "Catchments"

        # Remove previous catchment layer with the same name
        for lyr in QgsProject.instance().mapLayersByName(layer_name):
            QgsProject.instance().removeMapLayer(lyr)

        layer = QgsVectorLayer("Polygon", layer_name, "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("id",           QVariant.Int),
            QgsField("area_m2",      QVariant.Double),
            QgsField("area_ha",      QVariant.Double),
            QgsField("flow_bearing", QVariant.Double),
            QgsField("label",        QVariant.String),
        ])
        layer.updateFields()

        colours = [
            QColor(100, 180, 255, 80),
            QColor(255, 180, 80,  80),
            QColor(80,  220, 120, 80),
            QColor(220, 100, 220, 80),
            QColor(255, 255, 80,  80),
        ]

        features = []
        for c in catchments:
            qgs_geom = QgsGeometry.fromWkt(c["geometry"].wkt)
            f = QgsFeature()
            f.setGeometry(qgs_geom)
            f.setAttributes([
                c["id"], c["area_m2"], c["area_ha"],
                c.get("flow_bearing", 0.0), c["label"]
            ])
            features.append(f)
        pr.addFeatures(features)

        def _make_catchment_symbol(color_str):
            """Fill polygon + centroid arrow showing dominant flow direction."""
            sym = QgsFillSymbol.createSimple({
                "color": color_str,
                "outline_color": "60,60,60,200",
                "outline_width": "0.6",
            })
            # Add a centroid marker (arrow) rotated by flow_bearing attribute
            try:
                centroid_layer = QgsCentroidFillSymbolLayer()
                arrow = QgsMarkerSymbol.createSimple({
                    "name": "filled_arrowhead",
                    "color": "0,60,160,200",
                    "size": "6",
                    "angle": "0",
                })
                # Data-defined rotation from flow_bearing field
                arrow.symbolLayer(0).setDataDefinedProperty(
                    QgsSymbolLayer.PropertyAngle,
                    QgsProperty.fromField("flow_bearing")
                )
                centroid_layer.setSubSymbol(arrow)
                sym.appendSymbolLayer(centroid_layer)
            except Exception:
                pass  # Arrow is cosmetic — don't fail if QGIS API differs
            return sym

        if len(catchments) == 1:
            layer.setRenderer(QgsSingleSymbolRenderer(
                _make_catchment_symbol("100,180,255,80")
            ))
        else:
            root_rule = QgsRuleBasedRenderer.Rule(None)
            for i, c in enumerate(catchments):
                col = colours[i % len(colours)]
                col_str = f"{col.red()},{col.green()},{col.blue()},{col.alpha()}"
                rule = QgsRuleBasedRenderer.Rule(_make_catchment_symbol(col_str))
                rule.setFilterExpression(f'"id" = {c["id"]}')
                rule.setLabel(c["label"])
                root_rule.appendChild(rule)
            layer.setRenderer(QgsRuleBasedRenderer(root_rule))

        # Label with area
        lbl = QgsPalLayerSettings()
        lbl.fieldName = "label"
        lbl.enabled = True
        try:
            lbl.placement = Qgis.LabelPlacement.OverPoint
        except Exception:
            pass
        tf = QgsTextFormat()
        tf.setColor(QColor(0, 40, 120))
        lbl.setFormat(tf)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl))
        layer.setLabelsEnabled(True)

        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer)

    def _display_exit_points(self, exit_points):
        existing = QgsProject.instance().mapLayersByName("Site Exit Points")
        for layer in existing:
            QgsProject.instance().removeMapLayer(layer)

        layer = QgsVectorLayer("Point", "Site Exit Points", "memory")
        layer.setCrs(QgsProject.instance().crs())
        pr = layer.dataProvider()
        pr.addAttributes([
            QgsField("label", QVariant.String),
            QgsField("volume_m3", QVariant.Double),
            QgsField("flow_ls", QVariant.Double),
        ])
        layer.updateFields()

        features = []
        for p in exit_points:
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(p["x"], p["y"])))
            f.setAttributes([p["label"], p["volume_m3"], p["flow_ls"]])
            features.append(f)
        pr.addFeatures(features)

        symbol = QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "220,0,0,200",
            "outline_color": "140,0,0", "size": "5",
        })
        layer.setRenderer(QgsSingleSymbolRenderer(symbol))

        label_settings = QgsPalLayerSettings()
        label_settings.fieldName = "label"
        label_settings.enabled = True
        try:
            label_settings.placement = Qgis.LabelPlacement.OverPoint
        except Exception:
            pass
        text_format = QgsTextFormat()
        text_format.setColor(QColor(180, 0, 0))
        label_settings.setFormat(text_format)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
        layer.setLabelsEnabled(True)

        QgsProject.instance().addMapLayer(layer)

    # ---------------------------------------------------------------- before/after toggle

    def _toggle_before_after(self, checked):
        """checked=True → show baseline. checked=False → show earthworks."""
        self._showing_baseline = checked
        self.panel.btn_toggle_before_after.setText(
            "Show: Baseline" if checked else "Show: With Earthworks"
        )
        for lid in self._baseline_layer_ids:
            node = QgsProject.instance().layerTreeRoot().findLayer(lid)
            if node:
                node.setItemVisibilityChecked(checked)
        for lid in self._earthworks_layer_ids:
            node = QgsProject.instance().layerTreeRoot().findLayer(lid)
            if node:
                node.setItemVisibilityChecked(not checked)
        if self._earthwork_vector_layer:
            node = QgsProject.instance().layerTreeRoot().findLayer(self._earthwork_vector_layer.id())
            if node:
                node.setItemVisibilityChecked(not checked)

    # ---------------------------------------------------------------- ponding query

    def _activate_ponding_query(self):
        if not self._ponding_raster_path:
            return
        tool = PondingQueryTool(self.iface.mapCanvas(), self._ponding_raster_path)
        tool.ponding_selected.connect(self._on_ponding_selected)
        tool.no_ponding.connect(lambda: self.panel.lbl_ponding_result.setText(
            "No ponding at that location — click on a blue zone."
        ))
        self.iface.mapCanvas().setMapTool(tool)
        self.panel.lbl_status.setText("Click on a ponding zone... Esc to cancel.")

    def _on_ponding_selected(self, volume_m3, volume_l, cell_count, area_m2, geometry):
        avg_depth_m = volume_m3 / area_m2 if area_m2 > 0 else 0
        self.panel.lbl_ponding_result.setText(
            f"Selected ponding area:\n"
            f"  Surface area: {area_m2:,.1f} m²  ({area_m2/10000:.3f} ha)\n"
            f"  Avg depth:    {avg_depth_m*100:.1f} cm\n"
            f"  Volume:       {volume_m3:,.2f} m³\n"
            f"               ({volume_l:,.0f} L)"
        )
        self.panel.lbl_status.setText("Ponding area selected. Click again to query another zone.")

    # ---------------------------------------------------------------- contours

    def _generate_contours(self):
        if not self._dem_path:
            return
        interval, ok = QInputDialog.getDouble(
            self.panel, "Contour Interval",
            "Contour interval (metres):", value=1.0, min=0.1, max=100.0, decimals=1
        )
        if not ok:
            return
        try:
            import processing
            result = processing.run("gdal:contour", {
                "INPUT": self._dem_path,
                "BAND": 1,
                "INTERVAL": interval,
                "FIELD_NAME": "ELEV",
                "OUTPUT": "TEMPORARY_OUTPUT",
            })
            contour_layer = result["OUTPUT"]
            if isinstance(contour_layer, str):
                contour_layer = QgsVectorLayer(contour_layer, f"Contours ({interval}m)", "ogr")
            else:
                contour_layer.setName(f"Contours ({interval}m)")
            QgsProject.instance().addMapLayer(contour_layer)
            self.panel.lbl_status.setText(f"Contours generated at {interval}m interval.")
        except Exception as e:
            QMessageBox.critical(self.panel, "Contour Error", str(e))

    # ---------------------------------------------------------------- colour ramps

    def _apply_stream_ramp(self, layer):
        """
        Stream network: transparent where no stream (value=0), blue where stream (value=1).
        Values are binary: 0 = not a stream, 1 = stream cell.
        """
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Exact)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem(0, QColor(255, 255, 255, 0),   "No stream"),
            QgsColorRampShader.ColorRampItem(1, QColor(0, 100, 220, 230),   "Stream"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    def _apply_accumulation_ramp(self, layer):
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Interpolated)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem(0,     QColor(255, 255, 255), "0"),
            QgsColorRampShader.ColorRampItem(500,   QColor(180, 220, 255), "500"),
            QgsColorRampShader.ColorRampItem(5000,  QColor(30, 120, 255),  "5,000"),
            QgsColorRampShader.ColorRampItem(50000, QColor(0, 0, 180),     "50,000+"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    def _apply_runoff_ramp(self, layer, scale_max):
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Interpolated)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem(0,               QColor(255, 255, 255), "0 m³"),
            QgsColorRampShader.ColorRampItem(scale_max * 0.1, QColor(255, 255, 0),   f"{scale_max*0.1:,.0f} m³"),
            QgsColorRampShader.ColorRampItem(scale_max * 0.5, QColor(255, 140, 0),   f"{scale_max*0.5:,.0f} m³"),
            QgsColorRampShader.ColorRampItem(scale_max,       QColor(180, 0, 0),     f"{scale_max:,.0f} m³"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    def _apply_ponding_ramp(self, layer):
        """Light to dark blue — depth of ponded water in metres."""
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Interpolated)
        ramp.setColorRampItemList([
            QgsColorRampShader.ColorRampItem(0,    QColor(255, 255, 255, 0),   "0 m"),
            QgsColorRampShader.ColorRampItem(0.05, QColor(180, 220, 255, 180), "0.05 m"),
            QgsColorRampShader.ColorRampItem(0.5,  QColor(30, 120, 220, 220),  "0.5 m"),
            QgsColorRampShader.ColorRampItem(2.0,  QColor(0, 30, 140, 255),    "2.0 m"),
        ])
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    # ---------------------------------------------------------------- layer toggles

    def _toggle_streams_layer(self, checked):
        if hasattr(self, "_stream_layer_id"):
            node = QgsProject.instance().layerTreeRoot().findLayer(self._stream_layer_id)
            if node:
                node.setItemVisibilityChecked(checked)

    def _toggle_accumulation_layer(self, checked):
        if hasattr(self, "_acc_layer_id"):
            node = QgsProject.instance().layerTreeRoot().findLayer(self._acc_layer_id)
            if node:
                node.setItemVisibilityChecked(checked)

    def _toggle_slope_arrows(self, checked):
        if checked:
            # Generate layer on first use; just show it on subsequent toggles
            existing = (self._slope_arrow_layer_id and
                        QgsProject.instance().mapLayer(self._slope_arrow_layer_id))
            if existing:
                node = QgsProject.instance().layerTreeRoot().findLayer(self._slope_arrow_layer_id)
                if node:
                    node.setItemVisibilityChecked(True)
            else:
                self._generate_slope_arrows()
        else:
            if self._slope_arrow_layer_id:
                node = QgsProject.instance().layerTreeRoot().findLayer(self._slope_arrow_layer_id)
                if node:
                    node.setItemVisibilityChecked(False)

    def _generate_slope_arrows(self):
        if not self._dem_path:
            return
        try:
            import processing
            import rasterio
            import numpy as np

            self.panel.lbl_status.setText("Generating slope direction arrows...")

            # Compute aspect (0–360, clockwise from North, direction water flows downslope)
            result = processing.run("gdal:aspect", {
                "INPUT": self._dem_path,
                "BAND": 1,
                "TRIG_ANGLE": False,
                "ZERO_FOR_FLAT": True,
                "COMPUTE_EDGES": True,
                "ZEVENBERGEN": False,
                "OUTPUT": "TEMPORARY_OUTPUT",
            })
            aspect_path = result["OUTPUT"]
            if hasattr(aspect_path, "source"):
                aspect_path = aspect_path.source()

            with rasterio.open(self._dem_path) as src:
                cell_size = abs(src.transform.a)
                transform = src.transform

            with rasterio.open(aspect_path) as src:
                aspect = src.read(1).astype("float32")
                rows, cols = aspect.shape

            # One arrow per ~50 m on the ground
            step = max(1, int(50.0 / cell_size))

            layer = QgsVectorLayer("Point", "Slope Direction", "memory")
            layer.setCrs(QgsProject.instance().crs())
            pr = layer.dataProvider()
            pr.addAttributes([QgsField("angle", QVariant.Double)])
            layer.updateFields()

            features = []
            for r in range(0, rows, step):
                for c in range(0, cols, step):
                    val = float(aspect[r, c])
                    if val < 0 or val > 360:   # nodata or flat (-9999 / 361)
                        continue
                    x = transform.c + c * transform.a + cell_size / 2
                    y = transform.f + r * transform.e + cell_size / 2
                    f = QgsFeature()
                    f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                    f.setAttributes([val])
                    features.append(f)

            pr.addFeatures(features)
            layer.updateExtents()

            # Rotated arrowhead — angle field drives rotation (0 = North, clockwise)
            symbol = QgsMarkerSymbol.createSimple({
                "name": "filled_arrowhead",
                "color": "60,60,200,160",
                "outline_color": "20,20,120,160",
                "size": "3",
                "angle": "0",
            })
            symbol.symbolLayer(0).setDataDefinedProperty(
                QgsSymbolLayer.PropertyAngle,
                QgsProperty.fromField("angle")
            )
            layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            QgsProject.instance().addMapLayer(layer)
            self._slope_arrow_layer_id = layer.id()
            self.panel.lbl_status.setText("Slope direction arrows generated.")

        except Exception as e:
            import traceback
            QMessageBox.critical(self.panel, "Slope Arrow Error", traceback.format_exc())
            self.panel.btn_toggle_slope_arrows.setChecked(False)
