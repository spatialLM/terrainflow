import os
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QGroupBox,
    QProgressBar, QSpinBox, QDoubleSpinBox,
    QComboBox, QTextEdit, QListWidget, QListWidgetItem,
    QScrollArea, QSizePolicy, QCheckBox
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel

from .processing.scs_runoff import SCSRunoff


class TerrainFlowPanel(QDockWidget):
    """Docked panel for TerrainFlow plugin."""

    def __init__(self, parent=None):
        super().__init__("TerrainFlow", parent)
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self._dem_path = None
        self._build_ui()

    def _build_ui(self):
        # Wrap everything in a scroll area so the panel handles overflow
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(8)

        # ---------------------------------------------------------------- Data
        data_group = QGroupBox("Data")
        data_layout = QVBoxLayout(data_group)

        data_layout.addWidget(QLabel("Use loaded raster layer:"))
        self.combo_dem_layer = QgsMapLayerComboBox()
        self.combo_dem_layer.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.combo_dem_layer.setAllowEmptyLayer(True)
        self.combo_dem_layer.setCurrentIndex(0)
        self.btn_use_layer = QPushButton("Use Selected Layer")
        data_layout.addWidget(self.combo_dem_layer)
        data_layout.addWidget(self.btn_use_layer)

        data_layout.addWidget(QLabel("Or load from file:"))
        self.btn_load_dem = QPushButton("Browse...")
        data_layout.addWidget(self.btn_load_dem)

        self.lbl_dem_status = QLabel("No DEM selected")
        self.lbl_dem_status.setWordWrap(True)
        data_layout.addWidget(self.lbl_dem_status)

        data_layout.addWidget(QLabel("Site boundary (polygon layer):"))
        self.combo_boundary_layer = QgsMapLayerComboBox()
        self.combo_boundary_layer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.combo_boundary_layer.setAllowEmptyLayer(True)
        self.combo_boundary_layer.setCurrentIndex(0)
        self.combo_boundary_layer.setToolTip(
            "Select a polygon layer for your site boundary.\n"
            "Exit points where water leaves the site will be detected."
        )
        data_layout.addWidget(self.combo_boundary_layer)
        layout.addWidget(data_group)

        # ------------------------------------------------------------ Rainfall
        rainfall_group = QGroupBox("Rainfall")
        rainfall_layout = QVBoxLayout(rainfall_group)

        preset_layout = QHBoxLayout()
        preset_layout.addWidget(QLabel("Storm preset:"))
        self.combo_preset = QComboBox()
        for label in SCSRunoff.STORM_PRESETS:
            self.combo_preset.addItem(label)
        self.combo_preset.currentIndexChanged.connect(self._on_preset_changed)
        preset_layout.addWidget(self.combo_preset)
        rainfall_layout.addLayout(preset_layout)

        intensity_layout = QHBoxLayout()
        intensity_layout.addWidget(QLabel("Intensity (mm/hr):"))
        self.spin_intensity = QDoubleSpinBox()
        self.spin_intensity.setRange(1, 500)
        self.spin_intensity.setValue(40)
        self.spin_intensity.setDecimals(1)
        intensity_layout.addWidget(self.spin_intensity)
        rainfall_layout.addLayout(intensity_layout)

        duration_layout = QHBoxLayout()
        duration_layout.addWidget(QLabel("Duration (hours):"))
        self.spin_duration = QDoubleSpinBox()
        self.spin_duration.setRange(0.1, 72)
        self.spin_duration.setValue(1.0)
        self.spin_duration.setDecimals(1)
        duration_layout.addWidget(self.spin_duration)
        rainfall_layout.addLayout(duration_layout)
        layout.addWidget(rainfall_group)

        # -------------------------------------------------------- Soil
        soil_group = QGroupBox("Soil Conditions")
        soil_layout = QVBoxLayout(soil_group)

        cn_layout = QHBoxLayout()
        cn_layout.addWidget(QLabel("Curve Number (CN):"))
        self.spin_cn = QSpinBox()
        self.spin_cn.setRange(1, 100)
        self.spin_cn.setValue(70)
        self.spin_cn.setToolTip(
            "SCS Curve Number — soil runoff potential.\n"
            "Higher = more runoff.\n\n"
            "Typical values (Normal moisture):\n"
            "  Sand: 39  |  Sandy loam: 49\n"
            "  Loam: 61  |  Clay loam: 74  |  Clay: 80"
        )
        cn_layout.addWidget(self.spin_cn)
        soil_layout.addLayout(cn_layout)

        moisture_layout = QHBoxLayout()
        moisture_layout.addWidget(QLabel("Moisture condition:"))
        self.combo_moisture = QComboBox()
        self.combo_moisture.addItems(["Dry", "Normal", "Wet / Saturated"])
        self.combo_moisture.setCurrentIndex(1)
        moisture_layout.addWidget(self.combo_moisture)
        soil_layout.addLayout(moisture_layout)
        layout.addWidget(soil_group)

        # ---------------------------------------------------------- Analysis
        analysis_group = QGroupBox("Baseline Analysis")
        analysis_layout = QVBoxLayout(analysis_group)

        threshold_layout = QHBoxLayout()
        threshold_layout.addWidget(QLabel("Stream threshold (cells):"))
        self.spin_threshold = QSpinBox()
        self.spin_threshold.setMinimum(10)
        self.spin_threshold.setMaximum(500000)
        self.spin_threshold.setValue(1000)
        self.spin_threshold.setSingleStep(100)
        self.spin_threshold.setToolTip(
            "Upstream cells required to classify a flow path as a stream.\n"
            "1m DEM: 500–2000  |  8m DEM: 50–300"
        )
        threshold_layout.addWidget(self.spin_threshold)
        analysis_layout.addLayout(threshold_layout)

        self.chk_catchments = QCheckBox("Delineate catchment polygons")
        self.chk_catchments.setChecked(False)
        self.chk_catchments.setToolTip(
            "Delineate and display catchment area polygons with flow direction arrows.\n"
            "Adds processing time — disable for quick scenario comparisons."
        )
        analysis_layout.addWidget(self.chk_catchments)

        self.btn_run = QPushButton("Run Baseline Analysis")
        self.btn_run.setEnabled(False)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.lbl_status = QLabel("Load a DEM to begin.")
        self.lbl_status.setWordWrap(True)
        analysis_layout.addWidget(self.btn_run)
        analysis_layout.addWidget(self.progress_bar)
        analysis_layout.addWidget(self.lbl_status)
        layout.addWidget(analysis_group)

        # --------------------------------------------------------- Earthworks
        ew_group = QGroupBox("Earthworks")
        ew_layout = QVBoxLayout(ew_group)

        # Draw tools row
        draw_row = QHBoxLayout()
        self.btn_draw_swale = QPushButton("Draw Swale")
        self.btn_draw_swale.setToolTip("Draw a swale (left-click to add vertices, right-click or double-click to finish)")
        self.btn_draw_berm = QPushButton("Draw Berm")
        self.btn_draw_berm.setToolTip("Draw a berm / levee")
        self.btn_draw_basin = QPushButton("Draw Basin")
        self.btn_draw_basin.setToolTip("Draw a detention basin polygon")
        draw_row.addWidget(self.btn_draw_swale)
        draw_row.addWidget(self.btn_draw_berm)
        draw_row.addWidget(self.btn_draw_basin)
        ew_layout.addLayout(draw_row)

        # Spillway row
        spillway_row = QHBoxLayout()
        self.btn_place_spillway = QPushButton("Place Spillway Point")
        self.btn_place_spillway.setToolTip(
            "Click on the map to place a spillway point on the selected earthwork.\n"
            "Select an earthwork in the list below first."
        )
        self.btn_place_spillway.setEnabled(False)
        spillway_row.addWidget(self.btn_place_spillway)
        ew_layout.addLayout(spillway_row)

        # Earthworks list
        ew_layout.addWidget(QLabel("Drawn earthworks (check to enable):"))
        self.list_earthworks = QListWidget()
        self.list_earthworks.setMaximumHeight(160)
        self.list_earthworks.setToolTip(
            "Check/uncheck to enable or disable features.\n"
            "Double-click to edit properties."
        )
        ew_layout.addWidget(self.list_earthworks)

        # List actions row
        list_actions = QHBoxLayout()
        self.btn_delete_earthwork = QPushButton("Delete Selected")
        self.btn_delete_earthwork.setEnabled(False)
        self.btn_edit_earthwork = QPushButton("Edit Properties")
        self.btn_edit_earthwork.setEnabled(False)
        list_actions.addWidget(self.btn_edit_earthwork)
        list_actions.addWidget(self.btn_delete_earthwork)
        ew_layout.addLayout(list_actions)

        # Re-analyse + contours row
        action_row = QHBoxLayout()
        self.btn_reanalyse = QPushButton("Re-analyse with Earthworks")
        self.btn_reanalyse.setEnabled(False)
        self.btn_reanalyse.setToolTip("Burn earthworks into DEM and re-run flow analysis")
        self.btn_contours = QPushButton("Generate Contours")
        self.btn_contours.setToolTip("Generate a contour layer from the DEM to aid swale placement")
        self.btn_contours.setEnabled(False)
        action_row.addWidget(self.btn_reanalyse)
        action_row.addWidget(self.btn_contours)
        ew_layout.addLayout(action_row)

        # Before/After toggle
        self.btn_toggle_before_after = QPushButton("Show: Baseline")
        self.btn_toggle_before_after.setCheckable(True)
        self.btn_toggle_before_after.setEnabled(False)
        self.btn_toggle_before_after.setToolTip("Toggle between baseline and post-earthwork results")
        ew_layout.addWidget(self.btn_toggle_before_after)

        layout.addWidget(ew_group)

        # ----------------------------------------------------------- Results
        results_group = QGroupBox("Results")
        results_layout = QVBoxLayout(results_group)

        self.btn_query_ponding = QPushButton("Query Ponding Area")
        self.btn_query_ponding.setEnabled(False)
        self.btn_query_ponding.setToolTip(
            "Click on a ponding cell in the 'Water Captured' layer to select\n"
            "the entire connected pooling area and see its total volume."
        )
        self.lbl_ponding_result = QLabel("")
        self.lbl_ponding_result.setWordWrap(True)
        results_layout.addWidget(self.btn_query_ponding)
        results_layout.addWidget(self.lbl_ponding_result)

        self.btn_toggle_streams = QPushButton("Show Stream Network")
        self.btn_toggle_streams.setCheckable(True)
        self.btn_toggle_streams.setEnabled(False)

        self.btn_toggle_accumulation = QPushButton("Show Flow Accumulation")
        self.btn_toggle_accumulation.setCheckable(True)
        self.btn_toggle_accumulation.setEnabled(False)

        self.btn_toggle_slope_arrows = QPushButton("Show Slope Direction")
        self.btn_toggle_slope_arrows.setCheckable(True)
        self.btn_toggle_slope_arrows.setEnabled(False)
        self.btn_toggle_slope_arrows.setToolTip(
            "Overlay arrows showing the direction of steepest downslope at regular intervals.\n"
            "Generated from the DEM aspect — arrows point in the direction water would flow."
        )

        self.txt_results = QTextEdit()
        self.txt_results.setReadOnly(True)
        self.txt_results.setMaximumHeight(160)
        self.txt_results.setPlaceholderText("Runoff summary will appear here after analysis.")

        results_layout.addWidget(self.btn_toggle_streams)
        results_layout.addWidget(self.btn_toggle_accumulation)
        results_layout.addWidget(self.btn_toggle_slope_arrows)
        results_layout.addWidget(self.txt_results)
        layout.addWidget(results_group)

        layout.addStretch()
        scroll.setWidget(container)
        self.setWidget(scroll)

    # --------------------------------------------------------- preset handler

    def _on_preset_changed(self, index):
        label = self.combo_preset.currentText()
        intensity, duration = SCSRunoff.STORM_PRESETS[label]
        if intensity is not None:
            self.spin_intensity.setValue(intensity)
            self.spin_duration.setValue(duration)
            self.spin_intensity.setEnabled(False)
            self.spin_duration.setEnabled(False)
        else:
            self.spin_intensity.setEnabled(True)
            self.spin_duration.setEnabled(True)

    # --------------------------------------------------------- public helpers

    def get_moisture_key(self):
        return {0: "dry", 1: "normal", 2: "wet"}[self.combo_moisture.currentIndex()]

    def set_dem_path(self, path):
        self._dem_path = path
        self.lbl_dem_status.setText(os.path.basename(path))
        self.btn_run.setEnabled(True)
        self.btn_contours.setEnabled(True)
        self.lbl_status.setText("Ready to run analysis.")

    def set_progress(self, value, message=""):
        self.progress_bar.setValue(value)
        if message:
            self.lbl_status.setText(message)

    def set_results_ready(self, summary_text=""):
        self.btn_toggle_streams.setEnabled(True)
        self.btn_toggle_accumulation.setEnabled(True)
        self.btn_toggle_slope_arrows.setEnabled(True)
        self.btn_reanalyse.setEnabled(True)
        self.lbl_status.setText("Analysis complete.")
        if summary_text:
            self.txt_results.setText(summary_text)

    def add_earthwork_to_list(self, index, summary):
        item = QListWidgetItem(summary)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
        item.setCheckState(Qt.Checked)
        item.setData(Qt.UserRole, index)
        self.list_earthworks.addItem(item)
        self.btn_place_spillway.setEnabled(True)
        self.btn_delete_earthwork.setEnabled(True)
        self.btn_edit_earthwork.setEnabled(True)

    def update_earthwork_in_list(self, index, summary):
        for i in range(self.list_earthworks.count()):
            item = self.list_earthworks.item(i)
            if item.data(Qt.UserRole) == index:
                item.setText(summary)
                break

    def refresh_earthwork_list(self, earthworks):
        self.list_earthworks.clear()
        for i, ew in enumerate(earthworks):
            item = QListWidgetItem(ew.summary())
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if ew.enabled else Qt.Unchecked)
            item.setData(Qt.UserRole, i)
            self.list_earthworks.addItem(item)
