import numpy as np
import rasterio
from rasterio.transform import from_bounds
from pysheds.grid import Grid


class FlowAnalysis:
    """
    Phase 1: Flow direction, accumulation, and catchment delineation using pysheds.
    """

    def __init__(self):
        self.grid = None
        self.dem = None
        self.fdir = None
        self.acc = None
        self.crs = None
        self.transform = None

    def load_dem(self, dem_path):
        """Load DEM from GeoTIFF and initialise pysheds grid."""
        self.grid = Grid.from_raster(dem_path)
        self.dem = self.grid.read_raster(dem_path)

        with rasterio.open(dem_path) as src:
            self.crs = src.crs
            self.transform = src.transform
            self.nodata = src.nodata

        return True

    def run(self):
        """
        Run the full flow analysis pipeline:
          1. Fill sinks
          2. Compute flow direction (D8)
          3. Compute flow accumulation
        Returns dict of result arrays.
        """
        if self.grid is None or self.dem is None:
            raise RuntimeError("DEM not loaded. Call load_dem() first.")

        # 1. Remove single-cell artifact pits (DEM noise, bridges, etc.)
        #    These are not real features — filling them is correct.
        pit_filled = self.grid.fill_pits(self.dem)

        # 2. Breach real depressions rather than filling them.
        #    Breaching cuts the minimum-cost exit path out of each depression,
        #    preserving the depression shape (lakes, farm dams, natural hollows)
        #    while still allowing flow to route downstream.
        #    fill_depressions would raise all depressions flat, destroying
        #    storage information that matters for TerrainFlow.
        try:
            breached = self.grid.breach_depressions(pit_filled)
        except AttributeError:
            # Fallback for pysheds versions without breach_depressions
            breached = self.grid.fill_depressions(pit_filled)

        inflated = self.grid.resolve_flats(breached)

        # 2. Flow direction (D8)
        self.fdir = self.grid.flowdir(inflated)

        # 3. Flow accumulation
        self.acc = self.grid.accumulation(self.fdir)

        return {
            "flow_direction": self.fdir,
            "flow_accumulation": self.acc,
        }

    def delineate_catchment(self, x, y):
        """
        Delineate the catchment draining to a given outlet point (x, y in CRS units).
        Returns a boolean mask array.
        """
        if self.fdir is None:
            raise RuntimeError("Run flow analysis first.")

        catch = self.grid.catchment(x=x, y=y, fdir=self.fdir, xytype="coordinate")
        return catch

    def get_stream_network(self, accumulation_threshold=1000):
        """
        Extract stream network as a boolean mask where accumulation exceeds threshold.
        Higher threshold = fewer, larger streams only.
        """
        if self.acc is None:
            raise RuntimeError("Run flow analysis first.")

        streams = self.acc > accumulation_threshold
        return streams

    def get_runoff_volume_raster(self, runoff_mm, cell_area_m2):
        """
        Build a runoff volume raster (m³) by weighting flow accumulation
        by the runoff depth and cell area.

        Each cell value = number of upstream cells × runoff depth (m) × cell area (m²)
        = volume of surface water (m³) flowing through that point during the storm.

        This changes with rainfall intensity and CN — unlike raw flow accumulation
        which is purely terrain geometry.
        """
        if self.acc is None:
            raise RuntimeError("Run flow analysis first.")

        runoff_m = runoff_mm / 1000.0
        volume = np.array(self.acc, dtype="float32") * runoff_m * cell_area_m2
        return volume

    def get_boundary_exit_points(self, boundary_path, accumulation_threshold, runoff_mm, duration_hours):
        """
        Find points where significant flow crosses the site boundary.

        Parameters
        ----------
        boundary_path : str
            Path to a polygon vector file (the site boundary).
        accumulation_threshold : int
            Minimum upstream cell count to count as a stream (same as stream threshold).
        runoff_mm : float
            Runoff depth for the current scenario (mm).
        duration_hours : float
            Storm duration in hours.

        Returns
        -------
        list of dict with keys: x, y, accumulation, volume_m3, flow_ls, label
        """
        import geopandas as gpd
        from rasterio.features import rasterize

        if self.acc is None:
            raise RuntimeError("Run flow analysis first.")

        # Load and reproject boundary to match DEM CRS
        gdf = gpd.read_file(boundary_path)
        gdf = gdf.to_crs(self.crs.to_wkt())

        # Rasterize the polygon exterior ring (the boundary line itself) directly.
        # This is more accurate than rasterizing the interior and then trying to
        # detect the edge via array shifting (which causes wraparound artefacts).
        boundary_lines = [
            geom.exterior for geom in gdf.geometry
            if geom is not None and hasattr(geom, "exterior")
        ]
        if not boundary_lines:
            return []

        boundary_mask = rasterize(
            [(line, 1) for line in boundary_lines],
            out_shape=self.grid.shape,
            transform=self.transform,
            fill=0,
            dtype="uint8"
        ).astype(bool)

        # Exit cells: on boundary AND accumulation exceeds threshold
        acc_array = np.array(self.acc)
        exit_mask = boundary_mask & (acc_array > accumulation_threshold)

        rows, cols = np.where(exit_mask)
        if len(rows) == 0:
            return []

        # Convert row/col to real-world coordinates
        cell_w = abs(self.transform.a)
        cell_h = abs(self.transform.e)
        xs = self.transform.c + cols * self.transform.a + cell_w / 2
        ys = self.transform.f + rows * self.transform.e + cell_h / 2
        accs = acc_array[rows, cols]

        # Cluster nearby exit cells — keep only the highest-accumulation cell
        # within a minimum separation distance (20 cell widths)
        min_dist = cell_w * 20
        candidates = sorted(zip(accs, xs, ys), reverse=True)
        kept = []
        for acc, x, y in candidates:
            too_close = any(
                ((x - kx) ** 2 + (y - ky) ** 2) < min_dist ** 2
                for _, kx, ky in kept
            )
            if not too_close:
                kept.append((acc, x, y))

        # Calculate volume and flow rate at each exit point
        cell_area_m2 = cell_w * cell_h
        runoff_m = runoff_mm / 1000.0
        duration_s = duration_hours * 3600.0

        results = []
        for i, (acc, x, y) in enumerate(kept):
            volume_m3 = acc * cell_area_m2 * runoff_m
            flow_ls = (volume_m3 * 1000.0 / duration_s) if duration_s > 0 else 0
            results.append({
                "x": float(x),
                "y": float(y),
                "accumulation": int(acc),
                "volume_m3": round(volume_m3, 1),
                "flow_ls": round(flow_ls, 1),
                "label": f"Exit {i + 1}: {volume_m3:,.0f} m³ | {flow_ls:,.0f} L/s",
            })

        # Sort by volume descending so Exit 1 is always the largest
        results.sort(key=lambda r: r["volume_m3"], reverse=True)
        for i, r in enumerate(results):
            r["label"] = f"Exit {i + 1}: {r['volume_m3']:,.0f} m³ | {r['flow_ls']:,.0f} L/s"

        return results

    def get_catchment_polygons(self, outlet_points=None):
        """
        Delineate catchment polygons and return them as a list of dicts.

        Parameters
        ----------
        outlet_points : list of (x, y) tuples in CRS coordinates, or None.
            If None, delineates the single overall catchment to the cell with
            the highest flow accumulation (the natural outlet of the DEM).

        Returns
        -------
        list of dicts: {id, geometry (shapely), area_m2, area_ha, label}
        """
        from rasterio.features import shapes as rasterio_shapes
        from shapely.geometry import shape as shapely_shape
        from shapely.ops import unary_union

        if self.fdir is None or self.acc is None:
            raise RuntimeError("Run flow analysis first.")

        cell_area_m2 = abs(self.transform.a * self.transform.e)

        # If no outlets provided, use the highest-accumulation cell
        if not outlet_points:
            acc_array = np.array(self.acc)
            max_idx = np.unravel_index(np.argmax(acc_array), acc_array.shape)
            row, col = max_idx
            x = self.transform.c + col * self.transform.a + abs(self.transform.a) / 2
            y = self.transform.f + row * self.transform.e + abs(self.transform.e) / 2
            outlet_points = [(x, y)]

        # D8 direction codes → compass bearing (degrees, 0=North, clockwise)
        # pysheds uses powers of 2: N=64, NE=128, E=1, SE=2, S=4, SW=8, W=16, NW=32
        d8_to_bearing = {64: 0, 128: 45, 1: 90, 2: 135, 4: 180, 8: 225, 16: 270, 32: 315}
        fdir_array = np.array(self.fdir)

        results = []
        for i, (x, y) in enumerate(outlet_points):
            try:
                catch_mask = self.grid.catchment(
                    x=x, y=y, fdir=self.fdir, xytype="coordinate"
                )
            except Exception:
                continue

            catch_array = np.where(np.array(catch_mask), 1, 0).astype("uint8")

            # Convert raster mask to vector polygons
            polys = [
                shapely_shape(geom)
                for geom, val in rasterio_shapes(catch_array, transform=self.transform)
                if val == 1
            ]
            if not polys:
                continue

            catchment_poly = unary_union(polys)
            area_m2 = catchment_poly.area
            area_ha = area_m2 / 10000

            # Calculate dominant flow direction within this catchment
            # Weight by flow accumulation so high-flow cells dominate
            acc_array = np.array(self.acc)
            catch_bool = catch_array.astype(bool)
            dominant_bearing = 0.0
            try:
                # Convert D8 codes to bearings, take accumulation-weighted mean
                bearings = np.vectorize(lambda v: d8_to_bearing.get(int(v), 0))(fdir_array)
                weights = acc_array * catch_bool
                total_weight = weights.sum()
                if total_weight > 0:
                    # Circular mean to handle 0/360 wraparound
                    sin_sum = np.sum(np.sin(np.radians(bearings)) * weights)
                    cos_sum = np.sum(np.cos(np.radians(bearings)) * weights)
                    dominant_bearing = float(np.degrees(np.arctan2(sin_sum, cos_sum)) % 360)
            except Exception:
                dominant_bearing = 0.0

            results.append({
                "id": i + 1,
                "geometry": catchment_poly,
                "area_m2": round(area_m2, 1),
                "area_ha": round(area_ha, 2),
                "flow_bearing": round(dominant_bearing, 1),
                "label": f"Catchment {i + 1}: {area_ha:.1f} ha ({area_m2:,.0f} m²)",
            })

        return results

    def get_profile(self):
        """Return rasterio profile for writing results to GeoTIFF."""
        return {
            "driver": "GTiff",
            "dtype": "float32",
            "crs": self.crs,
            "transform": self.transform,
            "width": self.grid.shape[1],
            "height": self.grid.shape[0],
            "count": 1,
        }

    def save_result(self, array, output_path, band_description=""):
        """Save a result array to GeoTIFF with an optional band description."""
        profile = self.get_profile()
        with rasterio.open(output_path, "w", **profile) as dst:
            dst.write(array.astype("float32"), 1)
            if band_description:
                dst.update_tags(1, description=band_description)
