import json
import numpy as np
import rasterio
from rasterio.features import rasterize
from shapely.geometry import shape as shapely_shape


class DEMBurner:
    """
    Applies earthwork geometries to a DEM (DEM burning).

    Each earthwork modifies the DEM elevation grid:
      Swale  → lower cells within the swale footprint
      Berm   → raise cells within the berm footprint
      Basin  → lower cells within the basin polygon
      Swale + companion berm → additionally raise the downhill side
    """

    def __init__(self, dem_path):
        with rasterio.open(dem_path) as src:
            self.original = src.read(1).astype("float32")
            self.transform = src.transform
            self.crs = src.crs
            self.nodata = src.nodata
            self.shape = self.original.shape
        self.cell_size = abs(self.transform.a)

    def burn_earthworks(self, earthworks):
        """
        Apply all enabled earthworks to a copy of the original DEM.
        Returns the modified DEM as a float32 numpy array.
        """
        modified = self.original.copy()
        for ew in earthworks:
            if not ew.enabled:
                continue
            shapely_geom = self._to_shapely(ew.geometry)
            if shapely_geom is None:
                continue
            if ew.type == "swale":
                modified = self._burn_swale(modified, shapely_geom, ew)
            elif ew.type == "berm":
                modified = self._burn_berm(modified, shapely_geom, ew)
            elif ew.type == "basin":
                modified = self._burn_basin(modified, shapely_geom, ew)
            elif ew.type == "dam":
                modified = self._burn_dam(modified, shapely_geom, ew)
        return modified

    def save(self, array, output_path):
        """Save a modified DEM array to a GeoTIFF."""
        with rasterio.open(
            output_path, "w",
            driver="GTiff",
            dtype="float32",
            crs=self.crs,
            transform=self.transform,
            width=self.shape[1],
            height=self.shape[0],
            count=1,
            nodata=self.nodata,
        ) as dst:
            dst.write(array, 1)

    # ------------------------------------------------------------------ helpers

    def _to_shapely(self, qgs_geometry):
        try:
            return shapely_shape(json.loads(qgs_geometry.asJson()))
        except Exception:
            return None

    def _rasterize(self, shapely_geom):
        return rasterize(
            [(shapely_geom, 1)],
            out_shape=self.shape,
            transform=self.transform,
            fill=0,
            dtype="uint8",
        ).astype(bool)

    # ---------------------------------------------------------------- earthwork types

    def _burn_swale(self, dem, line, ew):
        footprint = line.buffer(ew.width / 2)
        mask = self._rasterize(footprint)
        dem = dem.copy()
        dem[mask] -= ew.depth

        if ew.companion_berm:
            dem = self._add_companion_berm(dem, line, mask, ew)
        return dem

    def _add_companion_berm(self, dem, line, swale_mask, ew):
        """
        Place excavated swale material on the downhill side of the swale.
        Volume is conserved: raise_height = (swale_cells / berm_cells) * depth.
        """
        berm_width = ew.width

        try:
            left_line = line.parallel_offset(ew.width / 2 + berm_width / 2, "left")
            right_line = line.parallel_offset(ew.width / 2 + berm_width / 2, "right")
            left_zone = left_line.buffer(berm_width / 2)
            right_zone = right_line.buffer(berm_width / 2)
        except Exception:
            return dem

        left_mask = self._rasterize(left_zone)
        right_mask = self._rasterize(right_zone)

        # Downhill side = lower average elevation in original DEM
        if left_mask.any() and right_mask.any():
            left_mean = float(np.mean(self.original[left_mask]))
            right_mean = float(np.mean(self.original[right_mask]))
            berm_mask = left_mask if left_mean < right_mean else right_mask
        elif left_mask.any():
            berm_mask = left_mask
        elif right_mask.any():
            berm_mask = right_mask
        else:
            return dem

        n_swale = int(np.sum(swale_mask))
        n_berm = int(np.sum(berm_mask))
        raise_height = (n_swale / n_berm) * ew.depth if n_berm > 0 else ew.depth

        dem = dem.copy()
        dem[berm_mask] += raise_height
        return dem

    def _burn_berm(self, dem, line, ew):
        footprint = line.buffer(ew.width / 2)
        mask = self._rasterize(footprint)
        dem = dem.copy()
        dem[mask] += ew.depth
        return dem

    def _burn_basin(self, dem, polygon, ew):
        mask = self._rasterize(polygon)
        dem = dem.copy()
        dem[mask] -= ew.depth
        return dem

    def _burn_dam(self, dem, line, ew):
        """
        Raise all cells under the dam wall footprint TO the crest elevation.
        Unlike a berm (which adds a fixed delta), this sets an absolute ceiling
        so the entire wall sits at a consistent height regardless of valley shape.
        Water will pool behind the dam up to the crest elevation on re-analysis.
        """
        if ew.crest_elevation is None:
            # Fallback: treat like a normal berm if no crest elevation set
            return self._burn_berm(dem, line, ew)
        footprint = line.buffer(ew.width / 2)
        mask = self._rasterize(footprint)
        dem = dem.copy()
        dem[mask] = np.maximum(dem[mask], ew.crest_elevation)
        return dem

    def get_ponding_layer(self, modified_dem):
        """
        Calculate where water pools in the modified DEM.

        Compares the modified DEM against a depression-filled version.
        Cells where filled > modified have water sitting in them.
        Returns a float32 array of ponding depth in metres (0 where no ponding).
        """
        from pysheds.grid import Grid
        import tempfile, os

        # Write modified DEM to temp file for pysheds
        tmp = tempfile.mktemp(suffix=".tif")
        self.save(modified_dem, tmp)

        try:
            grid = Grid.from_raster(tmp)
            dem_raster = grid.read_raster(tmp)
            pit_filled = grid.fill_pits(dem_raster)
            depression_filled = grid.fill_depressions(pit_filled)

            ponding = np.array(depression_filled, dtype="float32") - modified_dem
            ponding = np.clip(ponding, 0, None)  # no negative values
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

        return ponding
