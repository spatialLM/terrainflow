from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import QgsWkbTypes, QgsGeometry, QgsPointXY


class DrawPolygonTool(QgsMapTool):
    """
    Map tool for drawing a polygon on the canvas.
    Left-click adds vertices. Right-click or double-click closes and finishes.
    Escape cancels.
    Emits polygon_drawn(QgsGeometry) on completion.
    """
    polygon_drawn = pyqtSignal(object)
    cancelled = pyqtSignal()

    def __init__(self, canvas, color=None):
        super().__init__(canvas)
        self.canvas = canvas
        self.points = []
        self._double_click_pending = False

        self.rubber_band = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        c = color or QColor(0, 180, 80, 160)
        self.rubber_band.setColor(c)
        self.rubber_band.setFillColor(QColor(0, 180, 80, 60))
        self.rubber_band.setWidth(2)

    def canvasPressEvent(self, event):
        if self._double_click_pending:
            self._double_click_pending = False
            return
        if event.button() == Qt.LeftButton:
            pt = self.toMapCoordinates(event.pos())
            self.points.append(QgsPointXY(pt))
            self.rubber_band.addPoint(pt, True)
        elif event.button() == Qt.RightButton:
            self._finish()

    def canvasDoubleClickEvent(self, event):
        self._double_click_pending = True
        if len(self.points) >= 1:
            self.points.pop()
            self.rubber_band.removeLastPoint()
        self._finish()

    def canvasMoveEvent(self, event):
        if not self.points:
            return
        pt = self.toMapCoordinates(event.pos())
        if self.rubber_band.numberOfVertices() > len(self.points):
            self.rubber_band.removeLastPoint()
        self.rubber_band.addPoint(pt, True)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self._cancel()

    def _finish(self):
        if len(self.points) >= 3:
            closed = self.points + [self.points[0]]
            geom = QgsGeometry.fromPolygonXY([closed])
            self._reset()
            self.polygon_drawn.emit(geom)
        else:
            self._cancel()

    def _cancel(self):
        self._reset()
        self.cancelled.emit()

    def _reset(self):
        self.points = []
        self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)

    def deactivate(self):
        self._reset()
        super().deactivate()
