from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import QgsWkbTypes, QgsGeometry, QgsPointXY


class DrawLineTool(QgsMapTool):
    """
    Map tool for drawing a polyline on the canvas.
    Left-click adds vertices. Right-click or double-click finishes.
    Escape cancels.
    Emits line_drawn(QgsGeometry) on completion.
    """
    line_drawn = pyqtSignal(object)
    cancelled = pyqtSignal()

    def __init__(self, canvas, color=None):
        super().__init__(canvas)
        self.canvas = canvas
        self.points = []
        self._double_click_pending = False

        self.rubber_band = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
        c = color or QColor(0, 120, 220, 200)
        self.rubber_band.setColor(c)
        self.rubber_band.setWidth(2)

    def canvasPressEvent(self, event):
        if self._double_click_pending:
            self._double_click_pending = False
            return
        if event.button() == Qt.LeftButton:
            pt = self.toMapCoordinates(event.pos())
            self.points.append(QgsPointXY(pt))
            self.rubber_band.addPoint(pt, True)
        elif event.button() == Qt.RightButton:
            self._finish()

    def canvasDoubleClickEvent(self, event):
        # Double-click fires canvasPressEvent first, so flag to skip the next press
        self._double_click_pending = True
        if len(self.points) >= 1:
            self.points.pop()
            self.rubber_band.removeLastPoint()
        self._finish()

    def canvasMoveEvent(self, event):
        if not self.points:
            return
        pt = self.toMapCoordinates(event.pos())
        # Show preview segment to cursor
        if self.rubber_band.numberOfVertices() > len(self.points):
            self.rubber_band.removeLastPoint()
        self.rubber_band.addPoint(pt, True)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self._cancel()

    def _finish(self):
        if len(self.points) >= 2:
            geom = QgsGeometry.fromPolylineXY(self.points)
            self._reset()
            self.line_drawn.emit(geom)
        else:
            self._cancel()

    def _cancel(self):
        self._reset()
        self.cancelled.emit()

    def _reset(self):
        self.points = []
        self.rubber_band.reset(QgsWkbTypes.LineGeometry)

    def deactivate(self):
        self._reset()
        super().deactivate()
