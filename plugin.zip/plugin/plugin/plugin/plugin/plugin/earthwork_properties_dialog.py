from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QSpinBox, QDoubleSpinBox, QCheckBox,
    QLabel, QPushButton, QDialogButtonBox, QGroupBox
)
from qgis.PyQt.QtCore import Qt

from .processing.earthwork import calculate_capacity, berm_height_estimate


class EarthworkPropertiesDialog(QDialog):
    """
    Popup dialog shown after an earthwork is drawn.
    Lets the user set name, depth, width, and companion berm option.
    Displays calculated capacity in real time.
    """

    def __init__(self, ew_type, geometry, parent=None, earthwork=None,
                 peak_inflow_m3=None, crest_elevation=None):
        super().__init__(parent)
        self.ew_type = ew_type
        self.geometry = geometry
        self._editing = earthwork is not None
        self._peak_inflow_m3 = peak_inflow_m3   # None for freehand swales
        self._crest_elevation = crest_elevation  # pre-sampled for dam type

        self.setWindowTitle(f"{'Edit' if self._editing else 'New'} {ew_type.capitalize()} Properties")
        self.setMinimumWidth(360)
        self._build_ui(earthwork)
        self._update_capacity()

    def _build_ui(self, ew=None):
        layout = QVBoxLayout(self)

        form = QFormLayout()

        # Name
        self.edit_name = QLineEdit(ew.name if ew else f"New {self.ew_type.capitalize()}")
        form.addRow("Name:", self.edit_name)

        # Type (read-only label)
        form.addRow("Type:", QLabel(self.ew_type.capitalize()))

        # Dam: crest elevation instead of depth
        if self.ew_type == "dam":
            self.spin_crest_elev = QDoubleSpinBox()
            self.spin_crest_elev.setRange(-500, 9000)
            self.spin_crest_elev.setDecimals(2)
            self.spin_crest_elev.setSuffix(" m")
            if ew and ew.crest_elevation is not None:
                self.spin_crest_elev.setValue(ew.crest_elevation)
            elif self._crest_elevation is not None:
                self.spin_crest_elev.setValue(self._crest_elevation)
            self.spin_crest_elev.setToolTip(
                "Absolute elevation of the dam crest (top of the wall).\n\n"
                "Pre-filled from the higher of the two drawn endpoints.\n"
                "All cells under the wall will be raised to this elevation,\n"
                "so the wall height varies with the valley shape beneath it.\n\n"
                "Water will pool behind the dam up to this level.\n"
                "Run Re-analyse with Earthworks to see retained volume."
            )
            form.addRow("Crest elevation:", self.spin_crest_elev)
            self.spin_depth = None
        else:
            self.spin_crest_elev = None
            # Depth
            self.spin_depth = QDoubleSpinBox()
            self.spin_depth.setRange(0.1, 10.0)
            self.spin_depth.setValue(ew.depth if ew else 0.5)
            self.spin_depth.setDecimals(2)
            self.spin_depth.setSuffix(" m")
            self.spin_depth.valueChanged.connect(self._update_capacity)
            form.addRow("Depth:", self.spin_depth)

        # Width
        self.spin_width = QDoubleSpinBox()
        self.spin_width.setRange(0.1, 100.0)
        self.spin_width.setValue(ew.width if ew else (2.0 if self.ew_type == "dam" else 1.0))
        self.spin_width.setDecimals(2)
        self.spin_width.setSuffix(" m")
        self.spin_width.valueChanged.connect(self._update_capacity)
        lbl_width = "Wall thickness:" if self.ew_type == "dam" else "Width:"
        form.addRow(lbl_width, self.spin_width)

        # Companion berm (swales only)
        self.chk_companion = QCheckBox("Build companion berm on downhill side")
        self.chk_companion.setChecked(ew.companion_berm if ew else False)
        self.chk_companion.setVisible(self.ew_type == "swale")
        if self.ew_type == "swale":
            self.chk_companion.setToolTip(
                "Excavated material is placed on the downhill side of the swale,\n"
                "forming a retaining berm. Volume is conserved — the berm height is\n"
                "calculated from the excavated volume at 75% compaction.\n\n"
                "The berm raises the effective water level above the original ground,\n"
                "significantly increasing total water retention capacity."
            )
            self.chk_companion.stateChanged.connect(self._update_capacity)
            form.addRow("", self.chk_companion)

        layout.addLayout(form)

        # Capacity display
        cap_group = QGroupBox("Calculated Capacity")
        cap_layout = QFormLayout(cap_group)
        self.lbl_capacity_m3 = QLabel("—")
        self.lbl_capacity_l  = QLabel("—")
        cap_layout.addRow("Volume (m³):", self.lbl_capacity_m3)
        cap_layout.addRow("Volume (L):",  self.lbl_capacity_l)
        if self.ew_type == "swale":
            self.lbl_berm_height = QLabel("")
            self.lbl_berm_height.setStyleSheet("color: #555555; font-style: italic;")
            cap_layout.addRow(self.lbl_berm_height)
        else:
            self.lbl_berm_height = None
        if self.ew_type == "berm":
            cap_layout.addRow(QLabel("Berms are barriers — no storage capacity."))
        if self.ew_type == "dam":
            lbl = QLabel(
                "Volume retained depends on valley shape.\n"
                "Run Re-analyse with Earthworks to see ponded volume."
            )
            lbl.setStyleSheet("color: #555555; font-style: italic;")
            lbl.setWordWrap(True)
            cap_layout.addRow(lbl)

        # Recommended length — only shown for contour swales where inflow is known
        if self.ew_type == "swale" and self._peak_inflow_m3 is not None:
            sep = QLabel("─" * 30)
            sep.setStyleSheet("color: #aaaaaa;")
            cap_layout.addRow(sep)

            lbl_inflow = QLabel(f"{self._peak_inflow_m3:,.1f} m³")
            lbl_inflow.setToolTip(
                "Total runoff volume flowing into this swale from the slope above\n"
                "for the current storm scenario (flow accumulation × runoff depth)."
            )
            cap_layout.addRow("Peak storm inflow:", lbl_inflow)

            self.lbl_req_length = QLabel("—")
            self.lbl_req_length.setStyleSheet("font-weight: bold; color: #003080;")
            self.lbl_req_length.setToolTip(
                "Minimum swale length needed to store the full storm inflow.\n\n"
                "Formula: inflow volume ÷ cross-section area\n"
                "Cross-section treated as rectangular (depth × width).\n\n"
                "This is a conservative estimate — a trapezoidal cross-section\n"
                "would require slightly less length. Add 10–20% safety margin\n"
                "for practical construction."
            )
            cap_layout.addRow("Recommended length:", self.lbl_req_length)

            lbl_note = QLabel("Adjust depth / width above to see how\ndimensions affect required length.")
            lbl_note.setStyleSheet("color: #555555; font-style: italic;")
            cap_layout.addRow(lbl_note)
        else:
            self.lbl_req_length = None

        layout.addWidget(cap_group)

        # Spillway section (display only in properties, placement done via map tool)
        if self.ew_type != "berm" and ew and ew.spillway_point:
            spill_group = QGroupBox("Spillway")
            spill_layout = QFormLayout(spill_group)
            spill_layout.addRow("Point:", QLabel("Placed ✓"))
            self.spin_spillway_elev = QDoubleSpinBox()
            self.spin_spillway_elev.setRange(0, 5000)
            self.spin_spillway_elev.setValue(ew.spillway_elevation or 0)
            self.spin_spillway_elev.setSuffix(" m")
            spill_layout.addRow("Overflow elevation:", self.spin_spillway_elev)
            layout.addWidget(spill_group)
        else:
            self.spin_spillway_elev = None

        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _update_capacity(self):
        if self.ew_type == "dam":
            self.lbl_capacity_m3.setText("—")
            self.lbl_capacity_l.setText("—")
            return
        depth = self.spin_depth.value()
        width = self.spin_width.value()
        companion = self.chk_companion.isChecked() if self.ew_type == "swale" else False
        m3, l = calculate_capacity(self.ew_type, self.geometry, depth, width, companion)
        self.lbl_capacity_m3.setText(f"{m3:,.2f}")
        self.lbl_capacity_l.setText(f"{l:,.0f}")

        if self.lbl_berm_height is not None:
            if companion:
                h_b = berm_height_estimate(depth, width)
                self.lbl_berm_height.setText(
                    f"Berm height ≈ {h_b:.2f} m  · capacity is an estimate — actual\n"
                    f"backwater ponding depends on local slope and terrain."
                )
            else:
                self.lbl_berm_height.setText("")

        if self.lbl_req_length is not None and self._peak_inflow_m3 is not None:
            section = depth * width   # rectangular cross-section (m²)
            if section > 0:
                req_m = self._peak_inflow_m3 / section
                self.lbl_req_length.setText(f"{req_m:.0f} m")
            else:
                self.lbl_req_length.setText("—")

    # -- Result accessors --

    def get_name(self):
        return self.edit_name.text().strip() or f"New {self.ew_type.capitalize()}"

    def get_depth(self):
        return self.spin_depth.value() if self.spin_depth is not None else 0.5

    def get_crest_elevation(self):
        return self.spin_crest_elev.value() if self.spin_crest_elev is not None else None

    def get_width(self):
        return self.spin_width.value()

    def get_companion_berm(self):
        return self.chk_companion.isChecked() if self.ew_type == "swale" else False

    def get_spillway_elevation(self):
        if self.spin_spillway_elev:
            return self.spin_spillway_elev.value()
        return None
