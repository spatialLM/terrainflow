import json
import logging
import numpy as np
import rasterio
from rasterio.features import rasterize
from shapely.geometry import shape as shapely_shape

_log = logging.getLogger(__name__)

# Maximum pixel count for full-resolution ponding analysis.  DEMs larger than
# this are downsampled before running pysheds fill_depressions to avoid
# MemoryError on the numba-backed allocation.
_MAX_PONDING_CELLS = 4_000_000  # ~2000 × 2000


class DEMBurner:
    """
    Applies earthwork geometries to a DEM (DEM burning).

    Each earthwork modifies the DEM elevation grid:
      Swale  → lower cells within the swale footprint
      Berm   → raise cells within the berm footprint
      Basin  → lower cells within the basin polygon
      Swale + companion berm → additionally raise the downhill side
    """

    def __init__(self, dem_path):
        with rasterio.open(dem_path) as src:
            self.original = src.read(1).astype("float32")
            self.transform = src.transform
            self.crs = src.crs
            self.nodata = src.nodata
            self.shape = self.original.shape
        self.cell_size = abs(self.transform.a)

    def burn_earthworks(self, earthworks):
        """
        Apply all enabled earthworks to a copy of the original DEM.
        Returns the modified DEM as a float32 numpy array.
        """
        modified = self.original.copy()
        for ew in earthworks:
            if not ew.enabled:
                continue
            shapely_geom = self._to_shapely(ew.geometry)
            if shapely_geom is None:
                continue
            if ew.type == "swale":
                modified = self._burn_swale(modified, shapely_geom, ew)
            elif ew.type == "berm":
                modified = self._burn_berm(modified, shapely_geom, ew)
            elif ew.type == "basin":
                modified = self._burn_basin(modified, shapely_geom, ew)
            elif ew.type == "dam":
                modified = self._burn_dam(modified, shapely_geom, ew)
            elif ew.type == "diversion":
                modified = self._burn_diversion(modified, shapely_geom, ew)
        return modified

    def save(self, array, output_path):
        """Save a modified DEM array to a GeoTIFF with LZW compression."""
        with rasterio.open(
            output_path, "w",
            driver="GTiff",
            dtype="float32",
            crs=self.crs,
            transform=self.transform,
            width=self.shape[1],
            height=self.shape[0],
            count=1,
            nodata=self.nodata,
            compress="lzw",
        ) as dst:
            dst.write(array, 1)

    # ------------------------------------------------------------------ helpers

    def _to_shapely(self, qgs_geometry):
        try:
            return shapely_shape(json.loads(qgs_geometry.asJson()))
        except Exception:
            return None

    def _rasterize(self, shapely_geom):
        return rasterize(
            [(shapely_geom, 1)],
            out_shape=self.shape,
            transform=self.transform,
            fill=0,
            dtype="uint8",
        ).astype(bool)

    # ---------------------------------------------------------------- earthwork types

    def _burn_swale(self, dem, line, ew):
        footprint = line.buffer(ew.width / 2)
        mask = self._rasterize(footprint)
        dem = dem.copy()
        dem[mask] -= ew.depth

        if ew.companion_berm:
            dem = self._add_companion_berm(dem, line, mask, ew)
        return dem

    def _add_companion_berm(self, dem, line, swale_mask, ew):
        """
        Place excavated swale material on the downhill side of the swale.
        Volume is conserved: raise_height = (swale_cells / berm_cells) * depth.
        """
        berm_width = ew.width

        try:
            left_line = line.parallel_offset(ew.width / 2 + berm_width / 2, "left")
            right_line = line.parallel_offset(ew.width / 2 + berm_width / 2, "right")
            left_zone = left_line.buffer(berm_width / 2)
            right_zone = right_line.buffer(berm_width / 2)
        except Exception:
            return dem

        left_mask = self._rasterize(left_zone)
        right_mask = self._rasterize(right_zone)

        # Downhill side = lower average elevation in original DEM
        if left_mask.any() and right_mask.any():
            left_mean = float(np.mean(self.original[left_mask]))
            right_mean = float(np.mean(self.original[right_mask]))
            berm_mask = left_mask if left_mean < right_mean else right_mask
        elif left_mask.any():
            berm_mask = left_mask
        elif right_mask.any():
            berm_mask = right_mask
        else:
            return dem

        n_swale = int(np.sum(swale_mask))
        n_berm = int(np.sum(berm_mask))
        raise_height = (n_swale / n_berm) * ew.depth if n_berm > 0 else ew.depth

        dem = dem.copy()
        dem[berm_mask] += raise_height
        return dem

    def _burn_berm(self, dem, line, ew):
        footprint = line.buffer(ew.width / 2)
        mask = self._rasterize(footprint)
        dem = dem.copy()
        dem[mask] += ew.depth
        return dem

    def _burn_basin(self, dem, polygon, ew):
        mask = self._rasterize(polygon)
        dem = dem.copy()
        dem[mask] -= ew.depth
        return dem

    def _burn_dam(self, dem, line, ew):
        """
        Raise all cells under the dam wall footprint TO the crest elevation.
        Unlike a berm (which adds a fixed delta), this sets an absolute ceiling
        so the entire wall sits at a consistent height regardless of valley shape.
        Water will pool behind the dam up to the crest elevation on re-analysis.
        """
        if ew.crest_elevation is None:
            # Fallback: treat like a normal berm if no crest elevation set
            return self._burn_berm(dem, line, ew)
        footprint = line.buffer(ew.width / 2)
        mask = self._rasterize(footprint)
        dem = dem.copy()
        dem[mask] = np.maximum(dem[mask], ew.crest_elevation)
        return dem

    def _burn_diversion(self, dem, line, ew):
        """
        Burn a graded diversion drain into the DEM.

        The drain runs at ew.gradient_pct (%) — elevation decreases from the
        start vertex (highest end) toward the end vertex.  Each cell along the
        channel is lowered so that the channel floor follows the designed grade,
        then deepened by ew.depth.

        Start elevation = DEM value at the first vertex.
        Target floor at any point = start_elev - (distance_along_line / 100) * gradient_pct
        Burned elevation = min(original, target_floor)
        """
        dem = dem.copy()

        # Sample total length and start elevation from the line's first coordinate
        coords = list(line.coords)
        if len(coords) < 2:
            return dem

        # Start at the higher-elevation end
        x0, y0 = coords[0]
        col0 = int((x0 - self.transform.c) / self.transform.a)
        row0 = int((y0 - self.transform.f) / self.transform.e)
        row0 = max(0, min(self.shape[0] - 1, row0))
        col0 = max(0, min(self.shape[1] - 1, col0))
        start_elev = float(dem[row0, col0])

        # Compute cumulative distance at each vertex
        cum_dist = [0.0]
        for i in range(1, len(coords)):
            dx = coords[i][0] - coords[i - 1][0]
            dy = coords[i][1] - coords[i - 1][1]
            cum_dist.append(cum_dist[-1] + (dx ** 2 + dy ** 2) ** 0.5)
        total_length = cum_dist[-1]
        if total_length == 0:
            return dem

        gradient_frac = ew.gradient_pct / 100.0

        # Process the drain in segments between consecutive vertices
        for seg_i in range(len(coords) - 1):
            x1, y1 = coords[seg_i]
            x2, y2 = coords[seg_i + 1]
            seg_dist = cum_dist[seg_i + 1] - cum_dist[seg_i]
            if seg_dist == 0:
                continue
            # Number of sample steps proportional to segment length / cell_size
            n_steps = max(2, int(seg_dist / self.cell_size * 3))
            for step in range(n_steps + 1):
                t = step / n_steps
                x = x1 + t * (x2 - x1)
                y = y1 + t * (y2 - y1)
                dist_along = cum_dist[seg_i] + t * seg_dist

                # Target floor elevation at this position
                target_floor = start_elev - dist_along * gradient_frac

                # Rasterize a small buffer at this point
                from shapely.geometry import Point
                pt_geom = Point(x, y).buffer(ew.width / 2)
                cell_mask = self._rasterize(pt_geom)
                if not cell_mask.any():
                    continue

                # Burn: take the lower of original and (target_floor - depth)
                burn_elev = target_floor - ew.depth
                dem[cell_mask] = np.minimum(dem[cell_mask], burn_elev)

        return dem

    def get_ponding_layer(self, modified_dem):
        """
        Calculate where water pools in the modified DEM.

        Compares the modified DEM against a depression-filled version.
        Cells where filled > modified have water sitting in them.
        Returns a float32 array of ponding depth in metres (0 where no ponding).

        For DEMs larger than _MAX_PONDING_CELLS pixels the analysis runs at a
        reduced resolution (to stay within pysheds/numba memory limits) and the
        result is upsampled back to the original grid before returning.
        """
        from pysheds.grid import Grid
        from rasterio.transform import Affine
        import tempfile, os

        rows, cols = modified_dem.shape
        n_cells = rows * cols
        scale = 1.0

        if n_cells > _MAX_PONDING_CELLS:
            from scipy.ndimage import zoom as _zoom
            scale = (_MAX_PONDING_CELLS / n_cells) ** 0.5
            work_dem = _zoom(modified_dem, scale, order=1).astype("float32")
            _log.warning(
                "TerrainFlow: ponding analysis downsampled to %.0f%% "
                "resolution (%d×%d → %d×%d) — DEM too large for full-resolution fill.",
                scale * 100, cols, rows, work_dem.shape[1], work_dem.shape[0],
            )
        else:
            work_dem = modified_dem

        # Write work DEM to a temp GeoTIFF with the correct (possibly scaled)
        # transform so pysheds reads the spatial metadata correctly.
        tmp = tempfile.mktemp(suffix=".tif")
        scaled_transform = Affine(
            self.transform.a / scale,
            self.transform.b,
            self.transform.c,
            self.transform.d,
            self.transform.e / scale,
            self.transform.f,
        )
        try:
            with rasterio.open(
                tmp, "w",
                driver="GTiff",
                dtype="float32",
                crs=self.crs,
                transform=scaled_transform,
                width=work_dem.shape[1],
                height=work_dem.shape[0],
                count=1,
                nodata=self.nodata,
            ) as dst:
                dst.write(work_dem, 1)

            grid = Grid.from_raster(tmp)
            dem_raster = grid.read_raster(tmp)

            # fill_pits uses a numba allocation that can exhaust memory on large
            # DEMs.  If it fails, skip it — fill_depressions handles single-cell
            # pits as part of its own algorithm.
            try:
                dem_raster = grid.fill_pits(dem_raster)
            except MemoryError:
                pass  # proceed with un-pit-filled raster

            try:
                depression_filled = grid.fill_depressions(dem_raster)
            except MemoryError:
                # DEM still too large even at reduced resolution; return empty.
                _log.error("TerrainFlow: ponding analysis failed (MemoryError) — returning empty layer.")
                return np.zeros_like(modified_dem)

            ponding = np.array(depression_filled, dtype="float32") - work_dem
            ponding = np.clip(ponding, 0, None)  # no negative values
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

        # Upsample back to original resolution when we downsampled.
        if scale < 1.0:
            from scipy.ndimage import zoom as _zoom
            ponding = _zoom(
                ponding,
                (rows / ponding.shape[0], cols / ponding.shape[1]),
                order=1,
            )
            ponding = np.clip(ponding.astype("float32"), 0, None)

        return ponding
