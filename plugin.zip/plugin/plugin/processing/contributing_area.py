import os
import logging
import tempfile

import numpy as np
import rasterio
from rasterio.transform import Affine
from rasterio.features import rasterize, shapes as rasterio_shapes
from scipy.ndimage import zoom as _zoom

_log = logging.getLogger(__name__)

# Maximum cells for the fast preview — keeps runtime under ~5 seconds
_MAX_PREVIEW_CELLS = 500_000   # ~700 × 700


def fast_contributing_area(dem_path, boundary_path, progress_callback=None):
    """
    Fast low-resolution contributing area analysis.

    Downsamples the full DEM, runs a D8 flow analysis, and delineates the
    catchment draining to the site boundary exit points.  Designed to run
    in seconds so the user can decide whether/how to clip the DEM before
    committing to the full heavy analysis.

    Parameters
    ----------
    dem_path : str
        Path to the full-resolution DEM GeoTIFF.
    boundary_path : str
        Path to a polygon vector file representing the site boundary.
    progress_callback : callable(int, str) or None
        Optional (pct, message) progress reporter.

    Returns
    -------
    dict
        catchment_polygon : shapely Polygon
            The delineated contributing area in DEM CRS units.
        clip_polygon : shapely Polygon
            Bounding box of catchment + 20 % buffer — use this to clip the DEM.
        area_ha : float
            Contributing catchment area in hectares.
        dem_area_ha : float
            Full DEM coverage area in hectares.
        coverage_pct : float
            catchment / DEM as a percentage.
        scale : float
            Downsampling factor used (1.0 = no downsampling).
        n_exit_points : int
            Number of distinct exit points found on the boundary.
    """
    def _p(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)

    from pysheds.grid import Grid
    import geopandas as gpd
    from shapely.geometry import shape as shapely_shape, box
    from shapely.ops import unary_union

    # ------------------------------------------------------------------
    # 1. Read DEM metadata + data
    # ------------------------------------------------------------------
    _p(5, "Reading DEM...")
    with rasterio.open(dem_path) as src:
        dem = src.read(1).astype("float32")
        transform = src.transform
        crs = src.crs
        nodata = src.nodata

    rows, cols = dem.shape
    n_cells = rows * cols
    cell_w = abs(transform.a)
    cell_h = abs(transform.e)
    dem_area_ha = (rows * cell_h) * (cols * cell_w) / 10_000

    # ------------------------------------------------------------------
    # 2. Downsample if DEM is large
    # ------------------------------------------------------------------
    scale = min(1.0, (_MAX_PREVIEW_CELLS / n_cells) ** 0.5)
    if scale < 1.0:
        _p(10, f"Downsampling DEM to {scale * 100:.0f}% for preview...")
        work_dem = _zoom(dem, scale, order=1).astype("float32")
        work_transform = Affine(
            transform.a / scale, transform.b, transform.c,
            transform.d, transform.e / scale, transform.f,
        )
    else:
        work_dem = dem
        work_transform = transform

    # ------------------------------------------------------------------
    # 3. Run D8 flow analysis on the downsampled grid (one temp file)
    # ------------------------------------------------------------------
    _p(15, "Running fast D8 flow analysis...")
    tmp = tempfile.mktemp(suffix=".tif")
    try:
        with rasterio.open(
            tmp, "w",
            driver="GTiff", dtype="float32",
            crs=crs, transform=work_transform,
            width=work_dem.shape[1], height=work_dem.shape[0],
            count=1, nodata=nodata,
        ) as dst:
            dst.write(work_dem, 1)

        grid = Grid.from_raster(tmp)
        dem_r = grid.read_raster(tmp)

        _p(22, "Filling pits...")
        try:
            pit_filled = grid.fill_pits(dem_r)
        except Exception:
            pit_filled = dem_r

        _p(30, "Breaching depressions...")
        try:
            breached = grid.breach_depressions(pit_filled)
        except AttributeError:
            breached = grid.fill_depressions(pit_filled)

        _p(38, "Resolving flats...")
        inflated = grid.resolve_flats(breached)

        _p(46, "Computing flow direction (D8)...")
        try:
            fdir = grid.flowdir(inflated, routing="d8")
        except TypeError:
            fdir = grid.flowdir(inflated)

        _p(55, "Computing flow accumulation...")
        try:
            acc = grid.accumulation(fdir, routing="d8")
        except TypeError:
            acc = grid.accumulation(fdir)

        acc_array = np.array(acc)

        # ------------------------------------------------------------------
        # 4. Find exit points on the boundary
        # ------------------------------------------------------------------
        _p(63, "Locating boundary exit points...")
        gdf = gpd.read_file(boundary_path)
        gdf = gdf.to_crs(crs.to_wkt())

        boundary_lines = [
            geom.exterior
            for geom in gdf.geometry
            if geom is not None and hasattr(geom, "exterior")
        ]
        if not boundary_lines:
            raise RuntimeError("Site boundary has no valid polygon geometry.")

        boundary_mask = rasterize(
            [(line, 1) for line in boundary_lines],
            out_shape=work_dem.shape,
            transform=work_transform,
            fill=0,
            dtype="uint8",
        ).astype(bool)

        boundary_accs = acc_array[boundary_mask]
        if boundary_accs.size == 0:
            raise RuntimeError(
                "Site boundary does not intersect the DEM extent. "
                "Check that both layers use the same CRS."
            )

        # Threshold: top 10 % of boundary accumulations, floored at 0.1 % of grid
        threshold = max(
            float(np.percentile(boundary_accs, 90)),
            float(acc_array.size) * 0.001,
        )
        exit_mask = boundary_mask & (acc_array > threshold)
        rows_e, cols_e = np.where(exit_mask)

        if len(rows_e) == 0:
            # Fallback: single highest-accumulation boundary cell
            all_r, all_c = np.where(boundary_mask)
            best = int(np.argmax(acc_array[boundary_mask]))
            rows_e = np.array([all_r[best]])
            cols_e = np.array([all_c[best]])

        # Convert to CRS coordinates and cluster (keep one per 15-cell radius)
        cw = abs(work_transform.a)
        xs = work_transform.c + cols_e * work_transform.a + cw / 2
        ys = work_transform.f + rows_e * work_transform.e + abs(work_transform.e) / 2
        accs_e = acc_array[rows_e, cols_e]

        min_dist = cw * 15
        candidates = sorted(zip(accs_e.tolist(), xs.tolist(), ys.tolist()), reverse=True)
        kept = []
        for a, x, y in candidates:
            if not any(
                (x - kx) ** 2 + (y - ky) ** 2 < min_dist ** 2
                for _, kx, ky in kept
            ):
                kept.append((a, x, y))
            if len(kept) >= 8:
                break

        # ------------------------------------------------------------------
        # 5. Delineate contributing catchment for each exit point
        # ------------------------------------------------------------------
        _p(72, f"Delineating catchment from {len(kept)} exit point(s)...")
        combined_mask = np.zeros(work_dem.shape, dtype=bool)
        n_success = 0
        for _, x, y in kept:
            try:
                try:
                    catch = grid.catchment(
                        x=x, y=y, fdir=fdir,
                        xytype="coordinate", routing="d8",
                    )
                except TypeError:
                    catch = grid.catchment(x=x, y=y, fdir=fdir, xytype="coordinate")
                combined_mask |= np.array(catch).astype(bool)
                n_success += 1
            except Exception as exc:
                _log.debug("TerrainFlow: catchment delineation failed for exit point: %s", exc)

    finally:
        if os.path.exists(tmp):
            os.remove(tmp)

    if not combined_mask.any():
        raise RuntimeError(
            "Could not delineate a contributing catchment. "
            "Try using a larger or more representative site boundary."
        )

    # ------------------------------------------------------------------
    # 6. Convert raster mask → shapely polygon
    # ------------------------------------------------------------------
    _p(88, "Building catchment polygon...")
    polys = [
        shapely_shape(geom)
        for geom, val in rasterio_shapes(
            combined_mask.astype("uint8"), transform=work_transform
        )
        if val == 1
    ]
    if not polys:
        raise RuntimeError("Catchment raster produced no polygon geometry.")

    catchment_poly = unary_union(polys)
    area_ha = catchment_poly.area / 10_000

    # Clip polygon: bounding box + 20 % margin on each side
    minx, miny, maxx, maxy = catchment_poly.bounds
    buf_x = (maxx - minx) * 0.20
    buf_y = (maxy - miny) * 0.20
    clip_poly = box(minx - buf_x, miny - buf_y, maxx + buf_x, maxy + buf_y)

    coverage_pct = (area_ha / dem_area_ha * 100.0) if dem_area_ha > 0 else 0.0

    _p(100, "Done.")
    return {
        "catchment_polygon": catchment_poly,
        "clip_polygon": clip_poly,
        "area_ha": round(area_ha, 1),
        "dem_area_ha": round(dem_area_ha, 1),
        "coverage_pct": round(coverage_pct, 1),
        "scale": scale,
        "n_exit_points": n_success,
    }


def clip_dem_to_polygon(dem_path, clip_polygon, output_path):
    """
    Clip a GeoTIFF to a shapely polygon and save with LZW compression.

    Parameters
    ----------
    dem_path : str
    clip_polygon : shapely geometry (in the DEM's CRS)
    output_path : str

    Returns
    -------
    output_path : str
    """
    import rasterio.mask
    from shapely.geometry import mapping

    with rasterio.open(dem_path) as src:
        out_image, out_transform = rasterio.mask.mask(
            src, [mapping(clip_polygon)], crop=True,
            nodata=src.nodata if src.nodata is not None else -9999,
        )
        out_meta = src.meta.copy()
        out_meta.update({
            "height": out_image.shape[1],
            "width": out_image.shape[2],
            "transform": out_transform,
            "compress": "lzw",
            "nodata": src.nodata if src.nodata is not None else -9999,
        })

    with rasterio.open(output_path, "w", **out_meta) as dst:
        dst.write(out_image)

    return output_path
