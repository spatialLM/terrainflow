import logging

import numpy as np
import rasterio
from rasterio.transform import Affine
from rasterio.features import rasterize, shapes as rasterio_shapes
from scipy.ndimage import zoom as _zoom

_log = logging.getLogger(__name__)

# Maximum cells for the fast preview — keeps runtime under ~5 seconds
_MAX_PREVIEW_CELLS = 500_000   # ~700 × 700


def fast_contributing_area(dem_path, boundary_path, progress_callback=None):
    """
    Fast contributing area analysis using uphill BFS flood-fill.

    Traces uphill from the site boundary: any cell connected to the boundary
    via a monotonically non-decreasing elevation path contributes runoff to
    the site.  Equivalent to a standard topographic catchment delineation
    (perpendicular-to-contour flow lines) without needing depression-filling
    or D8 routing.

    Parameters
    ----------
    dem_path : str
        Path to the full-resolution DEM GeoTIFF.
    boundary_path : str
        Path to a polygon vector file representing the site boundary.
    progress_callback : callable(int, str) or None
        Optional (pct, message) progress reporter.

    Returns
    -------
    dict
        catchment_polygon : shapely Polygon
        clip_polygon      : shapely Polygon  (catchment bbox + 20 % buffer)
        area_ha           : float
        dem_area_ha       : float
        coverage_pct      : float
        scale             : float
    """
    import heapq
    import geopandas as gpd
    from shapely.geometry import shape as shapely_shape, box
    from shapely.ops import unary_union

    def _p(pct, msg):
        if progress_callback:
            progress_callback(pct, msg)

    # ------------------------------------------------------------------
    # 1. Read DEM
    # ------------------------------------------------------------------
    _p(5, "Reading DEM...")
    with rasterio.open(dem_path) as src:
        dem = src.read(1).astype("float32")
        transform = src.transform
        crs = src.crs
        nodata = src.nodata

    rows, cols = dem.shape
    n_cells = rows * cols
    cell_w = abs(transform.a)
    cell_h = abs(transform.e)
    dem_area_ha = (rows * cell_h) * (cols * cell_w) / 10_000

    if nodata is not None:
        dem = np.where(dem == nodata, np.nan, dem)

    # ------------------------------------------------------------------
    # 2. Downsample if DEM is large
    # ------------------------------------------------------------------
    scale = min(1.0, (_MAX_PREVIEW_CELLS / n_cells) ** 0.5)
    if scale < 1.0:
        _p(10, f"Downsampling DEM to {scale * 100:.0f}% for preview...")
        work_dem = _zoom(dem, scale, order=1).astype("float32")
        work_transform = Affine(
            transform.a / scale, transform.b, transform.c,
            transform.d, transform.e / scale, transform.f,
        )
    else:
        work_dem = dem
        work_transform = transform

    nrows, ncols = work_dem.shape

    # ------------------------------------------------------------------
    # 3. Rasterize site boundary
    # ------------------------------------------------------------------
    _p(20, "Rasterizing site boundary...")
    gdf = gpd.read_file(boundary_path)
    gdf = gdf.to_crs(crs.to_wkt())
    gdf_dissolved = gdf.dissolve()

    inside_mask = rasterize(
        [(geom, 1) for geom in gdf_dissolved.geometry],
        out_shape=work_dem.shape,
        transform=work_transform,
        fill=0,
        all_touched=True,
        dtype="uint8",
    ).astype(bool)

    if not inside_mask.any():
        raise RuntimeError(
            "Site boundary does not intersect the DEM extent. "
            "Check that both layers use the same CRS."
        )

    # Rasterize exterior ring(s) as a LINE — these cells seed the BFS
    boundary_lines = [
        geom.exterior
        for geom in gdf_dissolved.geometry
        if geom is not None and hasattr(geom, "exterior")
    ]
    if not boundary_lines:
        raise RuntimeError("Site boundary has no valid polygon geometry.")

    boundary_line_mask = rasterize(
        [(line, 1) for line in boundary_lines],
        out_shape=work_dem.shape,
        transform=work_transform,
        fill=0,
        dtype="uint8",
    ).astype(bool)

    seed_rows, seed_cols = np.where(boundary_line_mask)
    if seed_rows.size == 0:
        raise RuntimeError(
            "Site boundary line did not intersect the DEM. "
            "Check that both layers use the same CRS."
        )

    # ------------------------------------------------------------------
    # 4. BFS flood-fill uphill from the site boundary
    #
    # Seed a min-heap with every boundary-line cell at its elevation.
    # Process in order of increasing elevation; for each cell expand to
    # unvisited neighbours whose elevation >= current cell's elevation
    # (uphill or flat).  The BFS stops naturally at topographic divides
    # (ridgelines where all neighbours are lower).
    # ------------------------------------------------------------------
    _p(35, "Tracing contributing catchment from slope...")
    NBRS = [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]

    # Mark interior as visited but NOT the boundary line itself — those cells
    # are the seeds and must remain unvisited so they enter the heap.
    visited = inside_mask & ~boundary_line_mask
    contributing = inside_mask.copy()

    heap = []
    for r, c in zip(seed_rows.tolist(), seed_cols.tolist()):
        if not visited[r, c]:
            elev = float(work_dem[r, c])
            if np.isfinite(elev):
                visited[r, c] = True
                heapq.heappush(heap, (elev, r, c))

    _p(50, "Expanding uphill watershed...")
    while heap:
        elev, r, c = heapq.heappop(heap)
        contributing[r, c] = True
        for dr, dc in NBRS:
            nr, nc = r + dr, c + dc
            if 0 <= nr < nrows and 0 <= nc < ncols and not visited[nr, nc]:
                next_elev = float(work_dem[nr, nc])
                if np.isfinite(next_elev) and next_elev >= elev:
                    visited[nr, nc] = True
                    heapq.heappush(heap, (next_elev, nr, nc))

    # ------------------------------------------------------------------
    # 5. Convert raster mask → shapely polygon
    # ------------------------------------------------------------------
    _p(85, "Building catchment polygon...")
    polys = [
        shapely_shape(geom)
        for geom, val in rasterio_shapes(
            contributing.astype("uint8"), transform=work_transform
        )
        if val == 1
    ]
    if not polys:
        raise RuntimeError("Catchment raster produced no polygon geometry.")

    catchment_poly = unary_union(polys)
    area_ha = catchment_poly.area / 10_000

    minx, miny, maxx, maxy = catchment_poly.bounds
    buf_x = (maxx - minx) * 0.20
    buf_y = (maxy - miny) * 0.20
    clip_poly = box(minx - buf_x, miny - buf_y, maxx + buf_x, maxy + buf_y)

    coverage_pct = (area_ha / dem_area_ha * 100.0) if dem_area_ha > 0 else 0.0

    _p(100, "Done.")
    return {
        "catchment_polygon": catchment_poly,
        "clip_polygon": clip_poly,
        "area_ha": round(area_ha, 1),
        "dem_area_ha": round(dem_area_ha, 1),
        "coverage_pct": round(coverage_pct, 1),
        "scale": scale,
    }


def clip_dem_to_polygon(dem_path, clip_polygon, output_path):
    """
    Clip a GeoTIFF to a shapely polygon and save with LZW compression.

    Parameters
    ----------
    dem_path : str
    clip_polygon : shapely geometry (in the DEM's CRS)
    output_path : str

    Returns
    -------
    output_path : str
    """
    import rasterio.mask
    from shapely.geometry import mapping

    with rasterio.open(dem_path) as src:
        out_image, out_transform = rasterio.mask.mask(
            src, [mapping(clip_polygon)], crop=True,
            nodata=src.nodata if src.nodata is not None else -9999,
        )
        out_meta = src.meta.copy()
        out_meta.update({
            "height": out_image.shape[1],
            "width": out_image.shape[2],
            "transform": out_transform,
            "compress": "lzw",
            "nodata": src.nodata if src.nodata is not None else -9999,
        })

    with rasterio.open(output_path, "w", **out_meta) as dst:
        dst.write(out_image)

    return output_path
