from qgis.PyQt.QtCore import pyqtSignal, Qt
from qgis.PyQt.QtGui import QCursor
from qgis.gui import QgsMapTool
from qgis.core import QgsFeatureRequest, QgsRectangle


class SelectContourTool(QgsMapTool):
    """
    Map tool that lets the user click on a contour line to select it.
    Emits contour_selected(QgsGeometry, float elevation) on click.
    """

    contour_selected = pyqtSignal(object, float)   # QgsGeometry, elevation
    cancelled = pyqtSignal()

    def __init__(self, canvas, contour_layer):
        super().__init__(canvas)
        self._canvas = canvas
        self._layer = contour_layer
        self.setCursor(QCursor(Qt.CrossCursor))

    def canvasPressEvent(self, event):
        if event.button() == Qt.RightButton:
            self.cancelled.emit()
            return

        point = self.toMapCoordinates(event.pos())
        # Search radius: 8 pixels in map units
        radius = self._canvas.mapUnitsPerPixel() * 8
        rect = QgsRectangle(
            point.x() - radius, point.y() - radius,
            point.x() + radius, point.y() + radius,
        )
        request = QgsFeatureRequest().setFilterRect(rect).setLimit(1)
        for feature in self._layer.getFeatures(request):
            geom = feature.geometry()
            elev = 0.0
            for fname in ("ELEV", "elev", "elevation", "Elevation", "HEIGHT", "height"):
                if fname in feature.fields().names():
                    try:
                        elev = float(feature[fname])
                    except (ValueError, TypeError):
                        pass
                    break
            self.contour_selected.emit(geom, elev)
            return

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.cancelled.emit()
