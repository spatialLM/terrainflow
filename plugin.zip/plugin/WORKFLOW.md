# TerrainFlow Plugin — Workflow Overview

## Current Workflow

### Step 1 — Load DEM
Select a raster layer from the QGIS layer combo. The DEM auto-loads and the cell size is read for threshold calculations.

### Step 2 — Set Site Boundary *(optional but unlocks a lot)*
Select a polygon layer. This:
- Masks baseline analysis to the site
- Enables the Contributing Catchment preview
- Enables "Show contributing catchments" in advanced options

### Step 3 — Preview Contributing Catchment *(optional)*
Traces uphill from the site boundary using slope to identify what external land drains onto the site. Shows area in ha. Lets you **Clip DEM** to that catchment + 20% buffer — useful before running a full analysis on a large DEM.

### Step 4 — Configure Runoff (SCS)
- Pick a storm preset (NZ-based) or set custom rainfall
- Set Curve Number (CN) — land cover/soil runoff coefficient
- Set Antecedent Moisture Condition
- This feeds the runoff volume threshold for stream network

### Step 5 — Configure Stream Network
- **Threshold mode**: Contributing area (ha) or Runoff volume (m³)
- **Routing**: D-infinity (recommended) or D8
- The live label shows contributing area + inferred channel type at the current threshold
- Optional: show catchment polygons, show contributing catchments

### Step 6 — Run Analysis *(core)*
Runs pysheds flow direction + accumulation, generates:
- **Stream network** — gradient blue ramp by accumulation
- **Sub-catchments** — non-overlapping polygons from grid outlets
- **Natural depressions** — areas that pond without intervention
- **Slope direction arrows** *(if enabled)*
- **Contours** *(if enabled)*

### Step 7 — Draw Earthworks
- **Draw Swale** — freehand line, opens properties dialog (depth, width, length recommendation based on inflow)
- **Draw Berm** — line, blocks flow
- **Draw Basin** — polygon, captures water
- **Place Spillway** — point, sets overflow elevation on a basin
- Each can be enabled/disabled individually

### Step 8 — Re-analyse with Earthworks
Burns earthworks into the DEM and reruns the full analysis. Shows:
- Modified stream network
- **Water captured** zones (where ponding occurs behind earthworks)
- Ponding volume/area via the query tool (click a blue zone)

### Step 9 — Before/After Toggle
Switch between baseline and earthworks results to compare.

### Step 10 — Advanced / Additional Tools
- **Optimal Swale Contours** — scans DEM for top N elevations by peak inflow, generates contour lines as swale candidates
- **Analyse Contour Flow** — ranks a contour layer by peak accumulation, graduated display
- **Contour Swale tool** — click a contour → properties dialog with recommended length
- **Exclusion zones** — draw or load a polygon layer; excluded from analysis
- **CN zones** — draw polygons with custom CN values
- **Volume report** — exports ponding stats

---

## Where It Gets Messy

The main sources of confusion:

1. **Too many "optional" steps before you get a result** — Contributing catchment, DEM clipping, CN zones, exclusion zones, routing choice all sit between "load DEM" and "Run Analysis." A new user doesn't know what to skip.

2. **Two separate "run" buttons** — "Run Analysis" and "Re-analyse with Earthworks" aren't clearly sequential; it's not obvious you must do one before the other.

3. **The contour tools are a parallel workflow** — Optimal Swale Contours / Contour Flow / Contour Swale tool feel like a separate feature set bolted on, not a natural continuation of the main flow.

4. **SCS runoff configuration is prominent but only affects the stream threshold** — users might expect it to directly affect the ponding/volume calculations, which it doesn't in the same obvious way.

---

## For the Presentation — Suggested Paired-Down Flow

If you want a clean demo path:

1. Load DEM → select Site Boundary
2. Run Analysis (D-inf, default threshold) — show streams + catchments
3. Draw a swale → properties dialog → note recommended length
4. Re-analyse → show water captured zones
5. Query ponding volume
6. Before/After toggle

That's the core story: *terrain reads → intervention placed → result shown*. Everything else is refinement.

---

## Comments / Notes

<!-- Add your comments below -->
